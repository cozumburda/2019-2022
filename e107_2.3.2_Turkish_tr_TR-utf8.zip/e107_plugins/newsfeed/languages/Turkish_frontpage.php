<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 09:33:33
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("NWSF_FP_1", "Haber Kaynakları");
define("NWSF_FP_2", "ana sayfa");
