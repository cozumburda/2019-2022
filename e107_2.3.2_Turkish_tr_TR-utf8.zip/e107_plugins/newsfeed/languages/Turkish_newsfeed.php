<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 09:36:35
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("NFLAN_29", "Mevcut haber beslemeleri");
define("NFLAN_31", "Haber beslemeleri listesine geri dön");
define("NFLAN_33", "Yayın tarihi:");
define("NFLAN_34", "bilinmeyen");
define("NFLAN_38", "Manşetler");
define("NFLAN_39", "Detaylar");
define("NFLAN_48", "Ham veriler veritabanına kaydedilemiyor.");
