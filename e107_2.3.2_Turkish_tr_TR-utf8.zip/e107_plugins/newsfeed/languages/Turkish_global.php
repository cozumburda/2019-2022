<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 09:34:03
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_NEWSFEEDS_NAME", "Haber Kaynakları");
define("LAN_PLUGIN_NEWSFEEDS_DESCRIPTION", "Bu eklenti, diğer web sitelerinden rss beslemelerini alacak ve bunları tercihlerinize göre gösterecektir.");
