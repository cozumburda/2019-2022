<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 09:32:41
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("NFLAN_11", "Resim yolu");
define("NFLAN_12", "Aktivasyon");
define("NFLAN_13", "Hiçbir yerde (etkin değil)");
define("NFLAN_14", "sadece menüde");
define("NFLAN_18", "Saniye cinsinden güncelleme aralığı");
define("NFLAN_19", "Örn. 3600: haber akışı her saat güncellenecek");
define("NFLAN_20", "Yalnızca haber akışı ana sayfasında");
define("NFLAN_21", "Hem menüde hem de haber akışı sayfasında");
define("NFLAN_26", "Güncelleme aralığı");
define("NFLAN_43", "Haber Kaynağı Yardımı");
define("NFLAN_42", "[h=4]Haber Kaynağı Başlığı[/h] Haber akışını doğru bir şekilde tanımlamak için bir ad girin. [h=4]RSS Akışı URL'si[/h] RSS sağlayıcı, haber akışı için size bir web adresi (URL) verecektir. [h=4]Görsel Yolu[/h] Sağlayıcı kullanılacak bir resim belirtirse, onu kullanmak için 'varsayılan' girin veya resim adresini girerek kendi resminizi kullanmayı seçin. Hiç resim kullanmamak için boş bırakın. [h=4]Açıklama[/h] Yayın için kısa bir açıklama girin veya beslemede tanımlanan açıklamayı (varsa) kullanmak için 'varsayılan' girin. [h=4]Güncelleme Aralığı[/h] Yayın güncellenmeden önceki saniye sayısını girin. Örneğin, 1800 = 30 Dakika, 3600 = 1 Saat, 86400 = 1 Gün. [h=4]Etkinleştirme[/h] Haber beslemeleri yalnızca menüde veya haber beslemesi sayfasında görüntülenebilir. Beslemelerin görüntülenmesi gereken ayrıntıları girin. e107 menülerinde haber beslemelerini görmek için [link='.e_ADMIN.'menus.php]Menü Yöneticisi[/link]'nde [b]Haber Kaynakları Menüsünü[/b] etkinleştirmeniz gerekecektir. [h=4]İpucu[/h] Web'de birçok besleme dizini vardır, [link=https://www.dmoz.org/Computers/Internet/On_the_Web/Syndication_and_Feeds/RSS/Directories/ external]dmoz[/'u deneyin. bağlantı] veya [link=http://www.feedster.com/harici]feedster.com[/link]");
define("NFLAN_45", "Menüde gösterilecek öğe sayısı");
define("NFLAN_46", "Ana sayfada gösterilecek öğe sayısı");
