<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 11:46:23
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_RSS_NAME", "-RSS-");
define("LAN_PLUGIN_RSS_DESCRIPTION", "Sitenizden RSS Beslemeleri.");
define("LAN_PLUGIN_RSS_SUBSCRIBE", "Abone");
define("LAN_PLUGIN_RSS_SUBSCRIBE_TO", "[x]'e abone ol");
