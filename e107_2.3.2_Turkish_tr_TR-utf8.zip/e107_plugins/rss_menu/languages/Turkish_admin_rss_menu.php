<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 11:45:34
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("RSS_LAN05", "Öğe sayısı (0=etkin değil)");
define("RSS_MENU_L1", "bu rss beslemeleri kullanılarak dağıtılabilir.");
define("RSS_MENU_L2", "RSS beslemeleri");
define("RSS_MENU_L3", "Haberlerimiz");
define("RSS_MENU_L4", "Yorumlarımız");
define("RSS_MENU_L5", "Forum ileti dizilerimiz");
define("RSS_MENU_L6", "Forum gönderilerimiz");
define("RSS_MENU_L7", "Sohbet kutusu gönderilerimiz");
define("RSS_MENU_L8", "Hata izleyici raporlarımız");
define("RSS_MENU_L9", "İndirmelerimiz");
define("RSS_NEWS", "Haberler");
define("RSS_COM", "Yorumlar");
define("RSS_ART", "Makaleler");
define("RSS_REV", "İncelemeler");
define("RSS_FT", "Forum İleti dizileri");
define("RSS_FP", "Forum Gönderileri");
define("RSS_FSP", "Foruma Özgü Gönderi");
define("RSS_BUG", "hata izleyici");
define("RSS_FOR", "-Forum-");
define("RSS_DL", "İndirmeler");
define("RSS_PLUGIN_LAN_6", "Besleme Bağlantıları");
define("RSS_PLUGIN_LAN_7", "Haberlerin rss beslemesi");
define("RSS_PLUGIN_LAN_8", "İndirmelerin rss beslemesi");
define("RSS_PLUGIN_LAN_9", "Yorumların rss beslemesi");
define("RSS_PLUGIN_LAN_10", "Haber kategorisinin rss beslemesi:");
define("RSS_PLUGIN_LAN_11", "İndirme kategorisinin rss beslemesi:");
define("RSS_LAN_ADMINMENU_1", "RSS Seçenekleri");
define("RSS_LAN_ADMINMENU_2", "Listeleniyor");
define("RSS_LAN_ADMINMENU_4", "İçe Al");
define("RSS_LAN_ERROR_1", "Bu geçerli bir rss beslemesi değil. [rss besleme listesine dön]");
define("RSS_LAN_ERROR_2", "e107_config.php dosyanız veya dil dosyalarınız, &lt;?'den önce boşluklar veya ï»¿﻿ karakterleri içeriyor. Geçerli bir RSS beslemesine sahip olmak istiyorsanız, bunu utf8 olmayan bir metin düzenleyiciyle düzeltmelisiniz.");
define("RSS_LAN_ERROR_3", "Henüz rss beslemesi yok[br]mevcut rss beslemelerini içe aktarmak veya manuel olarak bir rss beslemesi oluşturmak için lütfen içe aktarma özelliğini etkinleştirin.");
define("RSS_LAN_ERROR_4", "Henüz rss beslemesi yok");
define("RSS_LAN_ERROR_5", "Bu rss girişi mevcut değil");
define("RSS_LAN_ERROR_6", "İçe aktarılacak rss beslemesi yok");
define("RSS_LAN_ERROR_7", "Bazı gerekli alanlar eksik.");
define("RSS_LAN_ADMIN_1", "Mevcut RSS beslemeleri");
define("RSS_LAN_ADMIN_10", "rss besleme girişi oluştur");
define("RSS_LAN_ADMIN_11", "rss beslemesi, beslemeleri içe aktar");
define("RSS_LAN_ADMIN_12", "Konu Kimliği");
define("RSS_LAN_ADMIN_13", "Haber Kaynağına diğer haberler dahil edilsin mi?");
define("RSS_LAN_ADMIN_15", "İçe aktarma için bağlantıları işaretleyin...");
define("RSS_LAN_ADMIN_16", "içe aktarılsın mı?");
define("RSS_LAN_ADMIN_17", "işaretli bağlantıları içe aktar");
define("RSS_LAN_ADMIN_18", "rss beslemeleri içe aktarıldı.");
define("RSS_LAN_ADMIN_19", "Haber beslemelerinde açıklama olarak Haber özeti kullanılsın mı?");
define("RSS_LAN_ADMIN_21", "aktif ve rss besleme listesinde görünür");
define("RSS_LAN_ADMIN_22", "aktif ve rss besleme listesinde görünmüyor");
define("RSS_LAN_ADMIN_23", "Aktif Değil");
define("RSS_LAN_ADMIN_26", "Tümünü Seç");
define("RSS_LAN_ADMIN_27", "Tüm İşaretleri Kaldır");
define("RSS_LAN_ADMIN_31", "rss giriş limitleri güncellendi");
define("RSS_LAN_ADMIN_33", "Haber beslemelerinde resim gösterilsin mi?");
define("RSS_LAN_0", "-RSS-");
define("RSS_LAN_2", "-@nospam.com-");
define("RSS_LAN_3", "-noauthor@nospam.com-");
