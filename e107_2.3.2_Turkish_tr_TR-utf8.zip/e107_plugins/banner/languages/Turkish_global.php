<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/02 07:14:55
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_BANNER_NAME", "Bannerlar");
define("LAN_PLUGIN_BANNER_DESCRIPTION", "e107 web sitenize reklam afişleri ekleyin");
