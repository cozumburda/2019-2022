<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/02 07:13:59
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("BANNERLAN_19", "Devam etmek için lütfen müşteri oturum açma bilgilerinizi ve şifrenizi girin");
define("BANNERLAN_20", "Üzgünüz, bu ayrıntılar veritabanında bulunamadı. Ayrıntılar için lütfen site yöneticisi ile iletişime geçin.");
define("BANNERLAN_21", "Banner İstatistikleri");
define("BANNERLAN_22", "Müşteri");
define("BANNERLAN_23", "Banner Kimliği");
define("BANNERLAN_24", "Tıklamalar");
define("BANNERLAN_25", "Tıklama %");
define("BANNERLAN_26", "Gösterimler");
define("BANNERLAN_27", "Ödenen Gösterim Sayısı");
define("BANNERLAN_28", "Kalan Gösterim Sayısı");
define("BANNERLAN_30", "Sınırsız");
define("BANNERLAN_31", "Uygulanamaz");
define("BANNERLAN_35", "Tıklama yapılan IP adresleri");
define("BANNERLAN_39", "Bu başlığa resim atanmadı.");
