<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/02 07:05:03
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("BNRLAN_00", "Henüz banner oluşturulmadı.");
define("BNRLAN_01", "Banner Kimliği bulunamadı.");
define("BNRLAN_11", "Kampanya");
define("BNRLAN_12", "Müşteri girişi");
define("BNRLAN_15", "URL'yi tıklayın");
define("BNRLAN_16", "Ödenen gösterim sayısı");
define("BNRLAN_25", "Yeni ekle veya mevcut kampanyayı seç");
define("BNRLAN_28", "Yeni ekle veya mevcut müşteriyi seç");
define("BNRLAN_29", "Yeni müşteri girin");
define("BNRLAN_31", "Boş bırakıldığında sınır yoktur.");
define("BNRLAN_32", "Banner resmi seçin");
define("BNRLAN_33", "Kod");
define("BNRLAN_35", "Banner Menüsü");
define("BNRLAN_38", "Reklem");
define("BNRLAN_39", "Menüde gösterilecek kampanyalar");
define("BNRLAN_40", "Henüz kampanya yok.");
define("BNRLAN_41", "Gösterilecek banner sayısı");
define("BNRLAN_42", "Bu, yalnızca birden fazla kampanya seçildiğinde kullanılır.");
define("BNRLAN_43", "Kampanyalar nasıl gösterilirsin?");
define("BNRLAN_44", "İşleme türünü seçin...");
define("BNRLAN_45", "Bir menüde bir kampanya işle");
define("BNRLAN_46", "Seçilen tüm kampanyalar tek bir menüde işlendi");
define("BNRLAN_47", "Seçilen tüm kampanyalar ayrı menülerde işlendi");
define("BNRLAN_48", "Tüm seçili kampanyalar (kutu oluşturma yok)");
define("BNRLAN_50", "Yerel");
define("BNRLAN_51", "Uzak");
define("BNRLAN_HELP_02", "Web sitenizdeki reklamları yönetmek için bu eklentiyi kullanın.[br][br]Yeni bir banner oluştururken, müşterinizin giriş yapması ve kampanyanın ilerleyişini kontrol etmesi için bir kullanıcı adı ve şifre oluşturabilirsiniz. [br][br]Menü yöneticisini kullanarak banner menüsünü etkinleştirebilir ve oradan daha fazla yapılandırma gerçekleştirebilirsiniz.");
