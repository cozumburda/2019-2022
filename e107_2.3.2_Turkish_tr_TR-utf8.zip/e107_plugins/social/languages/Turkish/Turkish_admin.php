<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 12:04:13
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_SOCIAL_ADMIN_00", "Uygulamalar");
define("LAN_SOCIAL_ADMIN_01", "Sayfalar");
define("LAN_SOCIAL_ADMIN_02", "Yapılandırılmış Oturum Sağlayıcıları");
define("LAN_SOCIAL_ADMIN_03", "Kayıt Ol/Giriş yap");
define("LAN_SOCIAL_ADMIN_04", "Sağlayıcı");
define("LAN_SOCIAL_ADMIN_05", "Anahtar/Kimlik");
define("LAN_SOCIAL_ADMIN_06", "Gizli");
define("LAN_SOCIAL_ADMIN_07", "Kullanıcıların sosyal medya hesaplarıyla kaydolmasına/giriş yapmasına izin verir. Bu seçenek etkinleştirildiğinde, yukarıdaki temel kullanıcı kayıt sistemi devre dışı bırakılsa bile kullanıcıların kaydolmasına/oturum açmasına izin verecektir.");
define("LAN_SOCIAL_ADMIN_10", "Sağlayıcıdan bir anahtar alın");
define("LAN_SOCIAL_ADMIN_11", "Sizin");
define("LAN_SOCIAL_ADMIN_12", "sayfa");
define("LAN_SOCIAL_ADMIN_13", "Bazı temalar tarafından sitenize bir bağlantı sağlamak için kullanılır.");
define("LAN_SOCIAL_ADMIN_14", "Paylaş Düğmeleri");
define("LAN_SOCIAL_ADMIN_15", "Facebook Yorumları");
define("LAN_SOCIAL_ADMIN_16", "Facebook Menüsü");
define("LAN_SOCIAL_ADMIN_17", "Twitter Menüsü");
define("LAN_SOCIAL_ADMIN_18", "-Limit-");
define("LAN_SOCIAL_ADMIN_19", "Tema");
define("LAN_SOCIAL_ADMIN_20", "Hareket");
define("LAN_SOCIAL_ADMIN_21", "Yüklerken metin");
define("LAN_SOCIAL_ADMIN_22", "Genişlik");
define("LAN_SOCIAL_ADMIN_23", "Yükseklik");
define("LAN_SOCIAL_ADMIN_24", "Ekran modu");
define("LAN_SOCIAL_ADMIN_25", "-Normal-");
define("LAN_SOCIAL_ADMIN_26", "Açılan");
define("LAN_SOCIAL_ADMIN_27", "Devre Dışı");
define("LAN_SOCIAL_ADMIN_28", "# simgesi hariç.");
define("LAN_SOCIAL_ADMIN_29", "Görüntülenecek yorum sayısı.");
define("LAN_SOCIAL_ADMIN_30", "Yükleniyor...");
define("LAN_SOCIAL_ADMIN_31", "Piksel cinsinden genişlik");
define("LAN_SOCIAL_ADMIN_32", "Önermek");
define("LAN_SOCIAL_ADMIN_33", "Piksel cinsinden yükseklik");
define("LAN_SOCIAL_ADMIN_34", "Görüntülenecek tweet sayısı.");
define("LAN_SOCIAL_ADMIN_35", "Açık");
define("LAN_SOCIAL_ADMIN_36", "Koyu");
define("LAN_SOCIAL_ADMIN_37", "Grafik Metasını Aç");
define("LAN_SOCIAL_ADMIN_38", "Kapsam");
define("LAN_SOCIAL_ADMIN_39", "Sağlayıcılar");
define("LAN_SOCIAL_ADMIN_40", "Kullanıcı Görünen Adını Güncelle");
define("LAN_SOCIAL_ADMIN_41", "Kullanıcı Avatarını Güncelle");
define("LAN_SOCIAL_ADMIN_42", "Özel Resim");
define("LAN_SOCIAL_ADMIN_43", "Bu eklentiyi kullanmaya devam etmek için bir [veritabanı güncellemesi] gerekiyor.");
define("LAN_SOCIAL_ADMIN_44", "Yeni Sağlayıcı Ekle");
define("LAN_SOCIAL_ADMIN_45", "Bu sosyal oturum açma sağlayıcıları şu anda yapılandırılmış durumda.\nAna anahtar [b]Sosyal Kayıt/Giriş[/b] açıksa, bu tablodaki yine açık olan her sağlayıcı, kullanıcı kaydı ve oturum açma için kullanılabilir. Buradaki bir sağlayıcının alanlarını boşaltır ve kaydederseniz, [b]Yeni Sağlayıcı Ekle[/b] bölümüne taşınır.");
define("LAN_SOCIAL_ADMIN_46", "Bunlar, yapılandırılmamış mevcut sosyal oturum açma sağlayıcılarıdır. Burada bir sağlayıcıyı yapılandırıp kaydettikten sonra, [b]Yapılandırılan[/b] bölümüne taşınacaktır.");
define("LAN_SOCIAL_ADMIN_47", "Yanlış Yapılandırılmış Sağlayıcılar");
define("LAN_SOCIAL_ADMIN_48", "Bu sosyal oturum açma sağlayıcıları geçmişte yapılandırıldı, ancak artık onları destekleyebilecek bir bağdaştırıcıya sahip değiller.[br]Bunun nedeni, onların artık mevcut olmaması veya farklı bir sağlayıcı tarafından değiştirilmeleri olabilir.");
define("LAN_SOCIAL_ADMIN_49", "Test Sayfası");
define("LAN_SOCIAL_ADMIN_50", "Sosyal oturum açma test sayfasını etkinleştirin veya devre dışı bırakın");
define("LAN_SOCIAL_ADMIN_08", "Not: Çoğu durumda, sosyal oturum açma sağlayıcılarından bir uygulama kimliği ve gizli anahtar almanız gerekir.\nBir sağlayıcının adı bir bağlantıysa, bu bağlantı sizi oturum açma uygulaması yapılandırma belgelerine götürmelidir.\n\nSağlayıcınızı test edebilirsiniz [b]Test Sayfası[/b] seçeneğini etkinleştirdikten sonra aşağıdaki URL ile yapılandırma:");
define("LAN_SOCIAL_ADMIN_09", "Geri dönme URL'niz:");
define("LAN_SOCIAL_ADMIN_51", "Sosyal Giriş Sistemi");
