<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 12:09:39
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_SOCIAL_ADMIN_SUMM", "e107'ye Facebook, Twitter ve diğer sosyal medya widget'larını ekler.");
define("LAN_PLUGIN_SOCIAL_DESCR", "e107 yorum motorunu Facebook ile değiştirmek için seçenekler ekler. Sitenize Twitter beslemeleri vb. ekleyin.");
define("LAN_PLUGIN_SOCIAL_SIGNIN", "Şununla giriş yap:");
define("LAN_PLUGIN_SOCIAL_XUP_SIGNUP", "[x] hesabınızla oturum açın");
define("LAN_PLUGIN_SOCIAL_XUP_REG", "[x] hesabınızla kaydolun");
define("LAN_PLUGIN_SOCIAL_NAME", "Sosyal");
