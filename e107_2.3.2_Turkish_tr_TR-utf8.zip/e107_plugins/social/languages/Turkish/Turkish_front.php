<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 12:07:52
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_SOCIAL_000", "[x] Üzerinde Paylaş");
define("LAN_SOCIAL_001", "[x]'te beğen");
define("LAN_SOCIAL_002", "Birine e-posta gönder");
define("LAN_SOCIAL_003", "Google'da +1");
define("LAN_SOCIAL_004", "[x]'e ekle");
define("LAN_SOCIAL_005", "Bu bağlantıya göz atın:");
define("LAN_SOCIAL_100", "Yayın görüntülenemiyor. Tercihlerde Facebook Uygulama Kimliği tanımlanmamış.");
define("LAN_SOCIAL_200", "Yayın görüntülenemiyor. Twitter URL'si tercihlerde tanımlanmadı.");
define("LAN_SOCIAL_201", "Tweet'ler");
define("LAN_SOCIAL_202", "Twitter'da yayınla");
define("LAN_SOCIAL_203", "Tweet'inizi buraya yazın.");
define("LAN_SOCIAL_204", "Paylaş");
define("LAN_SOCIAL_205", "Yorumlar işlenemiyor. Facebook uygulama kimliği eksik.");
define("LAN_SOCIAL_WARNING", "Facebook yorumları, bir facebook Uygulama Kimliğinizin olmasını gerektirir. Eklemek için yönetici tercihlerindeki 'sosyal oturum açma' alanına bakın.");
