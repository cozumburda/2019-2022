<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 12:10:06
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_TAGCLOUD_NAME", "Etiket Bulutu");
define("LAN_PLUGIN_TAGCLOUD_DESCRIPTION", "e107 web siteniz için basit bir etiket bulutu menüsü.");
