<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 07:49:22
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_CONVERT_03", "Ana yönetici kullanıcı (ID=1) hariç temiz bir E107 veritabanıyla başlamalısınız.");
define("LAN_CONVERT_04", "Alan(lar) boş bırakılmıştır, lütfen geri dönün ve değerleri tekrar girin.");
define("LAN_CONVERT_05", "Bu komut dosyasını çalıştırmak, E107 tablolarınızın çoğunu boşaltabilir - Devam etmeden önce tam bir yedeğiniz olduğundan emin olun!");
define("LAN_CONVERT_06", "Veri türünü içe aktar");
define("LAN_CONVERT_07", "CSV Format Özelliği");
define("LAN_CONVERT_08", "Mevcut veritabanı");
define("LAN_CONVERT_09", "Kaynak veritabanı için bağlantı ayrıntıları");
define("LAN_CONVERT_10", "Kaynak dosyadaki parolalar şifrelenmez");
define("LAN_CONVERT_11", "Kaynak veri ayrıntıları");
define("LAN_CONVERT_12", "Temel kullanıcı adı ve şifre");
define("LAN_CONVERT_13", "CSV Dosyası");
define("LAN_CONVERT_14", "İçe aktarılacak veritabanı biçimi");
define("LAN_CONVERT_15", "İçe aktarma dönüştürücüleri yok");
define("LAN_CONVERT_16", "İlk kullanıcı sınıf(lar)ı");
define("LAN_CONVERT_17", "CSV dosyasındaki parola zaten şifrelenmemiş");
define("LAN_CONVERT_18", "(Şifre MD5 şifreleme ile saklanmalıdır)");
define("LAN_CONVERT_19", "Veritabanı Ana Bilgisayarı");
define("LAN_CONVERT_20", "Veritabanı Kullanıcı Adı");
define("LAN_CONVERT_21", "Veritabanı Şifresi");
define("LAN_CONVERT_22", "Veri tabanı adı");
define("LAN_CONVERT_23", "Veritabanı Tablosu Öneki");
define("LAN_CONVERT_24", "İçe aktarılacak alanlar");
define("LAN_CONVERT_25", "Kullanıcılar");
define("LAN_CONVERT_26", "Forum Tanımları");
define("LAN_CONVERT_27", "Anketler");
define("LAN_CONVERT_28", "Haberler");
define("LAN_CONVERT_29", "Veritabanı içe aktarma tamamlandı");
define("LAN_CONVERT_30", "Rutin Bilgileri İçe Aktar");
define("LAN_CONVERT_31", "CSV veri dosyası mevcut değil veya izinler geçersiz");
define("LAN_CONVERT_32", "CSV veri dosyası okunurken hata oluştu");
define("LAN_CONVERT_33", "CSV veri satırında hata");
define("LAN_CONVERT_34", "Hata: [x] kullanıcı veritabanına yazarken hata oluştu, satır");
define("LAN_CONVERT_35", "CSV içe aktarma işlemi tamamlandı. [x] okuma, [y] kullanıcı eklendi, [z] hata");
define("LAN_CONVERT_36", "CSV verileri için dosya adı");
define("LAN_CONVERT_37", "İçe aktarma türü için geçersiz biçim belirtildi");
define("LAN_CONVERT_38", "Mevcut verileri sil");
define("LAN_CONVERT_39", "(Bunu yapmazsanız, içe aktarılan verilerin göndericileri 'Anonim' olarak gösterilecektir)");
define("LAN_CONVERT_40", "Mevcut veriler silindi");
define("LAN_CONVERT_41", "Gerekli veritabanı erişim alanı boş");
define("LAN_CONVERT_42", "Tanım dosyasında hata - gerekli sınıf mevcut değil");
define("LAN_CONVERT_43", "Kaynak veritabanına bağlanırken hata oluştu");
define("LAN_CONVERT_44", "Şunun için sorgu kurulum hatası:");
define("LAN_CONVERT_45", "İçe aktarma kod dosyası okunamıyor");
define("LAN_CONVERT_46", "Hata: [y] veritabanına [x] yazılırken hata oluştu, satır");
define("LAN_CONVERT_47", "Toplu [w] içe aktarma tamamlandı. [x] okuma, [y] eklendi, [z] hatalar");
define("LAN_CONVERT_48", "Forum Gönderileri");
define("LAN_CONVERT_49", "-Drupal-");
define("LAN_CONVERT_50", "Temel içe aktarma");
define("LAN_CONVERT_51", "Hedeflenen Drupal sürümü.");
define("LAN_CONVERT_52", "Drupal Versiyonu");
define("LAN_CONVERT_53", "Drupal web sitesinin temel URL'si (ör. http://mydrupalsite.com).");
define("LAN_CONVERT_54", "Drupal Temel URL'si");
define("LAN_CONVERT_55", "Drupal kurulumunun (ör. /drupal/) temel URL yolu (ör. dizin).");
define("LAN_CONVERT_56", "Drupal Temel Yolu");
define("LAN_CONVERT_57", "Hata yok");
define("LAN_CONVERT_58", "Ana yönetici verileri değiştirilemiyor");
define("LAN_CONVERT_59", "geçersiz alan geçildi");
define("LAN_CONVERT_60", "Zorunlu alan ayarlanmadı");
define("LAN_CONVERT_61", "Kullanıcı zaten var");
define("LAN_CONVERT_62", "Kullanıcı veya oturum açma adında geçersiz karakterler");
define("LAN_CONVERT_63", "Genişletilmiş kullanıcı alanları kaydedilirken hata oluştu");
define("LAN_CONVERT_64", "Seç");
define("LAN_CONVERT_65", "Sayfalar");
define("LAN_CONVERT_66", "Sayfa Bölümleri");
define("LAN_CONVERT_67", "Linkler");
define("LAN_CONVERT_68", "Medya");
define("LAN_CONVERT_69", "-Forum-");
define("LAN_CONVERT_70", "Forum Konuları/İleti Dizileri");
define("LAN_CONVERT_71", "Forum Yazıları");
define("LAN_CONVERT_72", "Forum Takibi");
define("LAN_CONVERT_73", "Kullanıcı sınıfları");
define("LAN_CONVERT_74", "Haber Kategorileri");
