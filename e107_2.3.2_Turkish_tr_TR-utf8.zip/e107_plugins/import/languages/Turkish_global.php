<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 07:49:58
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_IMPORT_NAME", "e107'ye aktar");
define("LAN_PLUGIN_IMPORT_DESCRIPTION", "Wordpress, Joomla, Drupal, Blogpost, RSS ve diğer formatlardan veri aktarın.");
