<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 12:13:04
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("TMCEALAN_1", "Metni varsayılan olarak yapıştır");
define("TMCEALAN_2", "Tarayıcı yazım denetimi");
define("TMCEALAN_3", "Tarayıcının dahili yazım denetleyicisinin kullanılması gerekiyorsa bunu etkinleştirin.");
define("TMCEALAN_4", "Görsel Bloklar");
define("TMCEALAN_5", "Düzenleme sırasında html bloklarını görünür kılmak için etkinleştirin.");
define("TMCEALAN_6", "Kod-Vurgu CSS sınıfı.");
define("TMCEALAN_7", "Ön uç stilini kullan");
define("TMCEALAN_8", "Etkinleştirildiğinde, düzenleyici ön uç temasının stilini kullanır. (desteklendiğinde)");
