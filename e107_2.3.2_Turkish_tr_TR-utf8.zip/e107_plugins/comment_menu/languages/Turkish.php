<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/02 12:10:44
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("CM_L1", "Henüz yorum yok.");
define("CM_L2", "-");
define("CM_L3", "Resim Yazısı");
define("CM_L4", "Görüntülenecek yorum sayısı?");
define("CM_L5", "Görüntülenecek karakter sayısı?");
define("CM_L6", "Çok uzun yorumlar için son düzeltme?");
define("CM_L7", "Menüde gerçek haber başlığı gösterilsin mi?");
define("CM_L8", "Yeni Yorumlar Menüsü Yapılandırması");
define("CM_L11", "açık");
define("CM_L12", "Cevap:");
define("CM_L13", "tarafından gönderildi");
