<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/03 11:46:20
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("FBLAN_08", "Mesaj metni");
define("FBLAN_12", "Mod");
define("FBLAN_13", "Rastgele dönen mesajlar");
define("FBLAN_14", "Sadece bu mesajı göster");
define("FBLAN_22", "İşleme türü");
define("FBLAN_23", "Tema kutusunda");
define("FBLAN_24", "Sade");
define("FBLAN_25", "[x] şablonuna atanmış featurebox öğesi yok.");
define("FBLAN_26", "Resim/Video");
define("FBLAN_27", "Resim Linki");
define("FBLAN_28", "Featurebox Menü Kategorisi");
define("FBLAN_29", "Featurebox menüsü için kullanılacak kategori");
define("FBLAN_30", "Kategori şablonu");
define("FBLAN_31", "Rastgele");
define("FBLAN_32", "Parametreler (isteğe bağlı)");
define("FBLAN_33", "İsteğe Bağlı Javascript Parametreleri (format değişebilir)");
define("FBLAN_34", "Atanmamış");
define("FBLAN_35", "-Carousel-");
define("FBLAN_36", "Sekmeler");
