<?php
/*
* Copyright (c) e107 Inc 2009 - e107.org, Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
* $Id$
*
* Featurebox front-end language defines
*/

// define("FBLAN_01", "-Feature Box-");
// define("FBLAN_02", "daha fazla"); // Already used in admin area. 
