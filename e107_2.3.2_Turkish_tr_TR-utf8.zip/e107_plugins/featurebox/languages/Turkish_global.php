<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/03 11:47:52
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_FEATUREBOX_NAME", "-Feature Box-");
define("LAN_PLUGIN_FEATUREBOX_DESCRIPTION", "Öne çıkarmak istediğiniz haberler ve diğer içeriklerle birlikte sayfanızın üst kısmında hareketli bir alan görüntüler.");
define("LAN_PLUGIN_FEATUREBOX_BATCH", "Featurebox Öğesi Oluştur");
define("LAN_PLUGIN_FEATUREBOX_RSSFEED", "Bu, featurebox girişleri için rss beslemesidir.");
