<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 12:16:19
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_USER_NAME", "Kullanıcı");
define("LAN_PLUGIN_USER_DESC", "Kullanıcı Teması ve Dil Menüleri");
