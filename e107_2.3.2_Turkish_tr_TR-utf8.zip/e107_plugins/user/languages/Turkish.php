<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 12:15:58
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("UTHEME_MENU_L1", "Ayarla");
define("UTHEME_MENU_L2", "Dil Seç");
define("UTHEME_MENU_L3", "tablolar");
define("LAN_UMENU_THEME_1", "Tema Ayarla");
define("LAN_UMENU_THEME_2", "Tema Seç");
define("LAN_UMENU_THEME_3", "kullanıcılar:");
define("LAN_UMENU_THEME_4", "Bu temaları kullanıcıların seçebilmesi etkinleştirin");
define("LAN_UMENU_THEME_5", "Güncelle");
define("LAN_UMENU_THEME_6", "Kullanıcıların kullanabileceği temalar");
define("LAN_UMENU_THEME_7", "Tema seçebilen sınıf");
define("LAN_UMENU_THEME_8", "İzin verilen temalar:");
define("LAN_UMENU_THEME_9", "Tema seçebilen sınıf:");
