<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/03 15:05:34
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("LAN_GALLERY_ADMIN_01", "[x] etkin. [y] düğmesini kullanarak resimleri içe aktarın ve galeri kategorilerine atayın.");
define("LAN_GALLERY_ADMIN_03", "Slayt Gösterisi Menüsü");
define("LAN_GALLERY_ADMIN_04", "Resim Maks. Genişlik");
define("LAN_GALLERY_ADMIN_05", "Burada verilen genişlikten büyükse resimler otomatik olarak yeniden boyutlandırılacaktır.");
define("LAN_GALLERY_ADMIN_06", "Resim Maks. Yükseklik");
define("LAN_GALLERY_ADMIN_07", "Burada verilen yükseklikten büyükse resimler otomatik olarak yeniden boyutlandırılacaktır.");
define("LAN_GALLERY_ADMIN_08", "\'İndirme\' bağlantısını göster");
define("LAN_GALLERY_ADMIN_09", "Açılır başlığın yanında bir indirme seçeneği gösterilecektir.");
define("LAN_GALLERY_ADMIN_10", "Slayt gösteri kategorisi");
define("LAN_GALLERY_ADMIN_11", "Bu kategorideki resimler kayan menüde kullanılacaktır.");
define("LAN_GALLERY_ADMIN_12", "slayt süresi");
define("LAN_GALLERY_ADMIN_13", "Bir sonraki slayta geçme süresi (saniye olarak).");
define("LAN_GALLERY_ADMIN_14", "Slayt otomatik başlatma");
define("LAN_GALLERY_ADMIN_15", "Etkinleştirildiğinde, sayfa yüklendiğinde resim döndürme otomatik olarak başlar.");
define("LAN_GALLERY_ADMIN_16", "Slayt sıklığı");
define("LAN_GALLERY_ADMIN_17", "Otomatik başlatma etkinleştirildiğinde, bu, bir slaytın bir sonraki slayta geçmeden önce ne kadar süre yerinde kalacağını belirler.");
define("LAN_GALLERY_ADMIN_18", "Slayt efekti");
define("LAN_GALLERY_ADMIN_19", "Efekt türü.");
define("LAN_GALLERY_ADMIN_20", "Sayfa başına resim");
define("LAN_GALLERY_ADMIN_21", "Sayfa başına gösterilecek resim sayısı");
define("LAN_GALLERY_ADMIN_22", "Resimleri şuna göre sırala:");
define("LAN_GALLERY_ADMIN_23", "Medya Kimliği Artan");
define("LAN_GALLERY_ADMIN_24", "Medya Kimliği Azalan");
define("LAN_GALLERY_ADMIN_25", "Medya Adı Artan");
define("LAN_GALLERY_ADMIN_26", "Medya Adı Azalan");
define("LAN_GALLERY_ADMIN_27", "Medya Resim Yazısı Artan");
define("LAN_GALLERY_ADMIN_28", "Medya Resim Yazısı Azalan");
define("LAN_GALLERY_ADMIN_29", "sola kaydır");
define("LAN_GALLERY_ADMIN_30", "aşağıya kaydır");
define("LAN_GALLERY_ADMIN_31", "solarak");
define("LAN_GALLERY_ADMIN_32", "prettyPhoto ayarları");
define("LAN_GALLERY_ADMIN_33", "Animasyon hızı");
define("LAN_GALLERY_ADMIN_34", "Slayt gösterisi: Aralık süresi");
define("LAN_GALLERY_ADMIN_35", "Slayt gösterisi: Otomatik oynatma");
define("LAN_GALLERY_ADMIN_36", "Donukluk");
define("LAN_GALLERY_ADMIN_37", "0 ile 1 arasında değer.");
define("LAN_GALLERY_ADMIN_38", "Başlığı Göster");
define("LAN_GALLERY_ADMIN_39", "Yeniden boyutlandırmaya izin ver");
define("LAN_GALLERY_ADMIN_40", "Görüntü alanından daha büyük fotoğrafları yeniden boyutlandırın.");
define("LAN_GALLERY_ADMIN_41", "Varsayılan genişlik");
define("LAN_GALLERY_ADMIN_42", "Varsayılan yükseklik");
define("LAN_GALLERY_ADMIN_43", "Sayaç ayırıcı etiket");
define("LAN_GALLERY_ADMIN_44", "Galeri sayacı için 2 \'den\' 1 ayırıcı");
define("LAN_GALLERY_ADMIN_46", "Yatay dolgu");
define("LAN_GALLERY_ADMIN_47", "Resmin her iki tarafındaki dolgu.");
define("LAN_GALLERY_ADMIN_48", "Flash'ı Gizle");
define("LAN_GALLERY_ADMIN_49", "Bir sayfadaki tüm flaş nesnesini gizler, eğer flash PrettyPhoto'nun üzerinde görünürse DOĞRU olarak ayarlanır.");
define("LAN_GALLERY_ADMIN_50", "Wmod");
define("LAN_GALLERY_ADMIN_51", "Flash wmode özniteliğini ayarlayın.");
define("LAN_GALLERY_ADMIN_52", "Videoları otomatik oynatma");
define("LAN_GALLERY_ADMIN_53", "Modal kapat");
define("LAN_GALLERY_ADMIN_54", "Doğru olarak ayarlanırsa, yalnızca kapat düğmesi pencereyi kapatır.");
define("LAN_GALLERY_ADMIN_55", "Derin bağlantı");
define("LAN_GALLERY_ADMIN_56", "PrettyPhoto'nun derin bağlantıyı etkinleştirmek için url'yi güncellemesine izin verin.");
define("LAN_GALLERY_ADMIN_57", "Galeriyi Kapla");
define("LAN_GALLERY_ADMIN_58", "Doğru olarak ayarlanırsa, fareyle üzerine gelindiğinde galeri tam ekranı kaplar.");
define("LAN_GALLERY_ADMIN_59", "Klavye kısayolları");
define("LAN_GALLERY_ADMIN_60", "PrettyPhoto içindeki formları açarsanız yanlış olarak ayarlayın.");
define("LAN_GALLERY_ADMIN_61", "IE6 yedeği");
define("LAN_GALLERY_ADMIN_62", "hızlı");
define("LAN_GALLERY_ADMIN_63", "yavaş");
define("LAN_GALLERY_ADMIN_64", "-normal-");
define("LAN_GALLERY_ADMIN_65", "hafif yuvarlak");
define("LAN_GALLERY_ADMIN_66", "keskin yuvarlak");
define("LAN_GALLERY_ADMIN_67", "hafif kare");
define("LAN_GALLERY_ADMIN_68", "keskin kare");
define("LAN_GALLERY_ADMIN_69", "-Facebook-");
define("LAN_GALLERY_ADMIN_70", "PrettyPhoto'yu herkese açık yükle");
define("LAN_GALLERY_ADMIN_71", "prettyPhoto özelliği (kanca)");
