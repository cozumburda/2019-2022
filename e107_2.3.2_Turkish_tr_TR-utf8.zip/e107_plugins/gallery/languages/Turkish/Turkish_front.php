<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 07:10:00
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_GALLERY_FRONT_01", "Sağ tıklayın > Bağlantıyı Farklı Kaydet");
define("LAN_GALLERY_FRONT_02", "Resmi genişlet");
