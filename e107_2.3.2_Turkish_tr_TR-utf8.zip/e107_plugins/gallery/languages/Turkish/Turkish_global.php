<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 07:11:20
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_GALLERY_TITLE", "Galeri");
define("LAN_PLUGIN_GALLERY_DIZ", "Basit bir resim galerisi");
define("LAN_PLUGIN_GALLERY_SEF_01", "Galeri SEF");
define("LAN_PLUGIN_GALLERY_SEF_02", "SEF URL'leri etkinleştirildi.");
define("LAN_PLUGIN_GALLERY_SEF_03", "SEF URL'leri devre dışı bırakıldı.");
define("LAN_PLUGIN_GALLERY_SEF_04", "Galeri varsayılanı");
