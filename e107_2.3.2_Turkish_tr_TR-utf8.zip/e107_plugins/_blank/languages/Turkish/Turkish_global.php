<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/01 21:26:18
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN__BLANK_NAME", "Boş Eklenti");
define("LAN_PLUGIN__BLANK_DIZ", "Eklenti geliştirmeye başlamanıza yardımcı olacak bir Boş Eklenti. Daha fazla ayrıntı buraya eklenebilir.");
define("LAN_PLUGIN__BLANK_LINK", "Boş Link");
