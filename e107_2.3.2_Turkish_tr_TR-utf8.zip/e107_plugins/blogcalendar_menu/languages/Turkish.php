<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/02 07:17:05
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("BLOGCAL_L1", "Aya Göre Haberler");
define("BLOGCAL_L2", "Arşiv");
define("BLOGCAL_1", "Haber Öğeleri");
define("BLOGCAL_CONF1", "Ay/Sıra");
define("BLOGCAL_CONF2", "Hücre dolgusu");
define("BLOGCAL_CONF4", "BlogCal Menü Yapılandırması");
define("BLOGCAL_ARCHIV1", "Arşivi Seç");
