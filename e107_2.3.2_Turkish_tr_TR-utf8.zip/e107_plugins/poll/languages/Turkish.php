<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 11:29:24
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("POLLAN_3", "Anket Sorusu");
define("POLLAN_4", "Anket Cevapları");
define("POLLAN_12", "Sonuçları göster");
define("POLLAN_13", "oylamadan sonra");
define("POLLAN_14", "sonuçları görüntüle bağlantısına tıklayarak - bu seçeneği kullanmak için yorumlar açık olmalıdır");
define("POLLAN_15", "Bu ankette oy kullanılmasına izin ver");
define("POLLAN_16", "Oy depolama yöntemi");
define("POLLAN_17", "Çerez");
define("POLLAN_19", "Kullanıcı Kimliği (sadece üyeler oy kullanabilir)");
define("POLLAN_28", "Tüm Önceki Anketler");
define("POLLAN_31", "Oylar");
define("POLLAN_40", "Sonuçları görmek için buraya tıklayın");
define("POLLAN_41", "Bu anket sadece üyelerle açıktır");
define("POLLAN_42", "Bu anket yalnızca yöneticilere açıktır");
define("POLLAN_43", "Bu ankette oy kullanmak için gerekli izinlere sahip değilsiniz");
define("POLLAN_50", "[x] ile [y] arasında aktif");
define("LAN_FORUM_3029", "Konunuza bir anket eklemek istemiyorsanız, alanları boş bırakın.");
