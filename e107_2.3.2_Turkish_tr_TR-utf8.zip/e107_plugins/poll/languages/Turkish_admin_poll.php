<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 11:30:26
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("POLL_ADLAN04", "Anket eklentisi başarıyla yüklendi. Anket eklemek için, yönetici giriş sayfanızın eklenti bölümündeki Anketler simgesine tıklayın ve menüler sayfanızdan menü öğesini etkinleştirmeyi unutmayın.");
define("LAN_AL_POLL_02", "Anket güncellendi");
define("LAN_AL_POLL_03", "Anket eklendi");
