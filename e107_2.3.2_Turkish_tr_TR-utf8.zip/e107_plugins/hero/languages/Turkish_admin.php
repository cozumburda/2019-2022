<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 07:27:37
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("LAN_HERO_ADMIN_001", "Varsayılan slaytlar içe aktarıldı.");
define("LAN_HERO_ADMIN_002", "Varsayılan slaytlar içe aktarılamadı.");
define("LAN_HERO_ADMIN_003", "Arka plan");
define("LAN_HERO_ADMIN_004", "Resim/Video");
define("LAN_HERO_ADMIN_005", "Medya");
define("LAN_HERO_ADMIN_006", "Etiket");
define("LAN_HERO_ADMIN_007", "[Menu Manager] Menü Yöneticisini kullanarak ana sayfanızda ana menüyü etkinleştirdiğinizden emin olun.");
define("LAN_HERO_ADMIN_009", "Simge paketi");
define("LAN_HERO_ADMIN_010", "Simge stili");
define("LAN_HERO_ADMIN_011", "Otomatik slayt aralığı");
define("LAN_HERO_ADMIN_012", "Metin");
define("LAN_HERO_ADMIN_013", "Animasyon");
define("LAN_HERO_ADMIN_014", "Gecikme (sn)");
define("LAN_HERO_ADMIN_015", "Buton");
define("LAN_HERO_ADMIN_016", "[x] saniye");
