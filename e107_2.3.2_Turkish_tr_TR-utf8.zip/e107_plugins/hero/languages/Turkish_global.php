<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 07:29:11
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_HERO_NAME", "-Hero-");
define("LAN_PLUGIN_HERO_SUMMARY", "Ana sayfa 'Hero' alan yönetimi");
define("LAN_PLUGIN_HERO_DESCRIPTION", "Ana sayfanızın Hero alanı için animasyonlu madde işaretlerine sahip bir resim ve metin kaydırıcısı.");
