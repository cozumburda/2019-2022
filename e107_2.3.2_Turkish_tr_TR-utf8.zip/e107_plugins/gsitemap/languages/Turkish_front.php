<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 07:22:55
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("GSLAN_Name", "-Sitemap-");
