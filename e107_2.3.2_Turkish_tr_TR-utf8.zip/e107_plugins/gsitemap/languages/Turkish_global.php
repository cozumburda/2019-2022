<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 07:23:54
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_GSITEMAP_NAME", "-Google Sitemap-");
define("LAN_PLUGIN_GSITEMAP_DESCRIPTION", "Bir Google Sitemap oluştur");
