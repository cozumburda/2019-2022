<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 07:24:54
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_AL_GSMAP_01", "Site linklerini içe aktar");
define("LAN_AL_GSMAP_02", "Sitemap linki silindi");
define("LAN_AL_GSMAP_03", "Sitemap linki eklendi");
define("LAN_AL_GSMAP_04", "Sitemap linki güncellendi");
