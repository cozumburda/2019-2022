<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 07:22:36
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("GSLAN_1", "Site Bağlantısı");
define("GSLAN_2", "İçe Aktar?");
define("GSLAN_7", "Linkleri İçe Aktar");
define("GSLAN_8", "İle içe aktar:");
define("GSLAN_9", "Öncelik");
define("GSLAN_10", "Sıklık");
define("GSLAN_11", "her zaman");
define("GSLAN_12", "saatlik");
define("GSLAN_13", "günlük");
define("GSLAN_14", "haftalık");
define("GSLAN_15", "aylık");
define("GSLAN_16", "yıllık");
define("GSLAN_18", "İşaretli linkleri içe aktar");
define("GSLAN_20", "Listeleniyor");
define("GSLAN_21", "Talimatlar");
define("GSLAN_22", "Yeni Giriş Oluştur");
define("GSLAN_23", "İçe Al");
define("GSLAN_24", "Google Sitemap Girişleri");
define("GSLAN_27", "Son mod");
define("GSLAN_28", "sıklık");
define("GSLAN_29", "Google Sitemap Yapılandırması");
define("GSLAN_32", "Google Sitemapler nasıl kullanılır?");
define("GSLAN_33", "GSitemap Talimatları");
define("GSLAN_34", "Öncelikle, site haritanızda listelenmesini istediğiniz bağlantıları oluşturun. Sağdaki 'İçe Aktar' düğmesini tıklayarak bağlantılarınızın çoğunu içe aktarabilirsiniz.");
define("GSLAN_35", "Bağlantılarınızı içe aktarmayı seçtiyseniz, 'İçe Aktar'ı tıklayın ve ardından içe aktarmak istediğiniz linkleri kontrol edin.");
define("GSLAN_36", "Ayrıca, 'Yeni Giriş Oluştur'u tıklayarak linkleri manuel olarak da girebilirsiniz.");
define("GSLAN_38", "Google Sitemap protokolü hakkında daha fazla bilgi için [URL] adresine gidin.");
define("GSLAN_39", "Site haritasında bağlantı yok - site linkleri içe aktarılsın mı?");
define("GSLAN_50", "Herkese görünür");
define("GSLAN_51", "[x] kaynağından otomatik oluşturuldu");
define("GSLAN_52", "Bazı girişleriniz olduğunda, [URL]'ye gidin ve Site Haritaları bölümüne aşağıdaki URL'lerden birini girin.[SITEMAP_URLS] (Bu URL'lerden herhangi biri size yanlış görünüyorsa, lütfen [preferences] seçeneklerde site url'nizin doğru olduğundan emin olun.");
