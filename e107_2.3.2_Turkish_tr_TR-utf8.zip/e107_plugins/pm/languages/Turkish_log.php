<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 11:24:06
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_AL_PM_ADM_01", "ÖM: Varsayılan tercihler kullanıldı");
define("LAN_AL_PM_ADM_02", "ÖM: Tercihler güncellendi");
define("LAN_AL_PM_ADM_03", "ÖM: VT Bakımı tamamlandı");
define("LAN_AL_PM_ADM_04", "ÖM: VT Bakımı başladı");
define("LAN_AL_PM_ADM_05", "ÖM: Limit eklendi");
define("LAN_AL_PM_ADM_06", "ÖM: Limit egüncellendi");
define("LAN_AL_PM_ADM_07", "ÖM: Limit silindi");
define("LAN_AL_PM_ADM_08", "ÖM: Limit verileri oluşturulurken hata oluştu");
define("LAN_AL_PM_ADM_09", "ÖM: Limit verileri güncellenirken hata oluştu");
define("LAN_AL_PM_ADM_10", "ÖM: Limit verileri silinirken hata oluştu");
