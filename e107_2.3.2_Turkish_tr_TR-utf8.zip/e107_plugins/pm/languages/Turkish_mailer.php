<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 11:25:14
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_EC_PM_01", "-");
define("LAN_EC_PM_02", "-");
define("LAN_EC_PM_03", "-");
define("LAN_EC_PM_04", "ÖM İşleyici");
define("LAN_EC_PM_05", "Büyük ÖM gönderimlerini işleyin");
define("LAN_EC_PM_06", "[y] alıcı için toplu ÖM işlemeyi başlat");
define("LAN_EC_PM_07", "-");
