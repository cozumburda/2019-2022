<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 10:11:30
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("LAN_PM", "Özel Mesaj");
define("LAN_PM_1", "Özel Mesaj Gönder");
define("LAN_PM_2", "Kime");
define("LAN_PM_3", "Önizleme");
define("LAN_PM_4", "Kullanıcı Sınıfı");
define("LAN_PM_5", "Konu");
define("LAN_PM_6", "Mesaj");
define("LAN_PM_7", "İfadeler");
define("LAN_PM_8", "Ekler");
define("LAN_PM_9", "Okundu bilgisi");
define("LAN_PM_10", "Bu ÖM okunduğunda bana bir e-posta gönder");
define("LAN_PM_11", "yeni yükleme ekle");
define("LAN_PM_12", "ÖM sistemini kullanma yetkiniz yok");
define("LAN_PM_13", "Giden kutunuz şu anda %{PERCENT} dolu, bazılarını silmeden özel mesaj gönderemezsiniz.");
define("LAN_PM_14", "HATA: Yinelenen gönderi olabilir, ÖM gönderilemedi");
define("LAN_PM_15", "Bu kullanıcı sınıfına göndermenize izin verilmiyor");
define("LAN_PM_16", "Bir sınıfın üyesi olmalı");
define("LAN_PM_17", "Kullanıcı bulunamadı");
define("LAN_PM_18", "Şuraya ÖM göndermenize izin verilmiyor:");
define("LAN_PM_19", "Giden kutunuz dolu, özel mesaj gönderemezsiniz.");
define("LAN_PM_21", "Bu ÖM'yi eklemek, maksimum giden kutu boyutunuzu aşacak, ÖM gönderilmeyecek");
define("LAN_PM_22", "Dosya yükleme başarısız oldu");
define("LAN_PM_23", "Ek göndermenize izin verilmiyor");
define("LAN_PM_24", "ÖM Siliniyor");
define("LAN_PM_27", "Okunmamış");
define("LAN_PM_28", "Boş");
define("LAN_PM_29", "Mesajı Gönderildi");
define("LAN_PM_30", "Mesajı Okundu");
define("LAN_PM_31", "Kimden");
define("LAN_PM_32", "Kabul edilmiş");
define("LAN_PM_33", "Gönderildi");
define("LAN_PM_34", "Mesaj Yok");
define("LAN_PM_35", "Yeni mesaj gönder");
define("LAN_PM_36", "toplam");
define("LAN_PM_37", "okunmamış");
define("LAN_PM_38", "Kullanıcı sınıfına ÖM gönderildi");
define("LAN_PM_39", "Şuraya ÖM gönderilemedi:");
define("LAN_PM_40", "Kullanıcıya ÖM Gönderildi");
define("LAN_PM_41", "Giden Kutunuza ÖM gönderilemedi");
define("LAN_PM_42", "ÖM gelen kutusundan silindi");
define("LAN_PM_43", "ÖM giden kutusundan silindi");
define("LAN_PM_44", "Engelleme kaldırıldı: {UNAME} artık size ÖM gönderebilir");
define("LAN_PM_45", "HATA: Engelleme kaldırılmadı, bilinmeyen hata");
define("LAN_PM_46", "{UNAME} için engelleme yerinde değil");
define("LAN_PM_47", "Engelleme eklendi: {UNAME} artık size özel mesaj gönderemez");
define("LAN_PM_48", "HATA: Engelleme eklenemedi, bilinmeyen hata");
define("LAN_PM_49", "HATA: {UNAME} için engelleme zaten mevcut");
define("LAN_PM_50", "Kullanıcıyı Engelle");
define("LAN_PM_51", "Kullanıcı Engelini Kaldır");
define("LAN_PM_53", "Seçili olanı Sil");
define("LAN_PM_54", "Orijinal Alıntı");
define("LAN_PM_55", "Cevap Gönder");
define("LAN_PM_56", "Bu mesajı yanıtlama yetkiniz yok");
define("LAN_PM_57", "Mesaj Bulunamadı");
define("LAN_PM_58", "Cevap:");
define("LAN_PM_59", "Sayfaya git:");
define("LAN_PM_60", "Bu mesajı görme izniniz yok");
define("LAN_PM_61", "Konu Yok");
define("LAN_PM_62", "Dosya: [{FILENAME}] boyut sınırını aşıyor - eklenmemiş");
define("LAN_PM_63", "sınıf:");
define("LAN_PM_64", "HATA: Site yöneticilerinden gelen mesajları engelleme izniniz yok");
define("LAN_PM_65", "HATA: Gönderilecek bir şey yok");
define("LAN_PM_66", "Engellenen Gönderenler");
define("LAN_PM_67", "Engellenen kullanıcı yok");
define("LAN_PM_68", "Kullanıcı Adı");
define("LAN_PM_69", "Engellenme tarihi");
define("LAN_PM_70", "Kullanıcı üzerindeki engelleme siliniyor");
define("LAN_PM_71", "[x] ek silindi. [y] başarısız");
define("LAN_PM_100", "Yeni ÖM");
define("LAN_PM_101", "Şu kişiden yeni bir Özel Mesaj aldınız:");
define("LAN_PM_102", "Gönderilen mesaj:");
define("LAN_PM_103", "Mesaj Konusu:");
define("LAN_PM_104", "Ek sayısı:");
define("LAN_PM_105", "ÖM'ı şu adresten görüntüleyebilirsiniz:");
define("LAN_PM_106", "ÖM'ı okuyan");
define("LAN_PM_107", "{UNAME} adlı kişiye gönderdiğiniz Özel Mesaj şu tarihte okunmuştur:");
define("LAN_PM_108", "Gönderilen mesaj:");
define("LAN_PM_109", "Yeni Mesaj(lar)");
define("LAN_PM_111", "Oku");
define("LAN_PM_112", "Kullanıcı(lar)");
define("LAN_PM_113", "Mesajı Oku");
define("LAN_PM_114", "Bu kullanıcıya mesaj göndermek için erişiminiz yok.");
define("LAN_PM_115", "Kullanıcı bulunamadı");
