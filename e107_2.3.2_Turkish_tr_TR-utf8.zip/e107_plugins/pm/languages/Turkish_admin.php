<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 11:19:23
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("ADLAN_PM_1", "Etkinleştirmek için lütfen menüler ekranınıza gidin ve menü alanlarınızdan private_msg'yi seçin. <br /><br />Önceki bir sürümdeki mesajları dönüştürmeniz gerekiyorsa, lütfen bu eklenti için ana yapılandırma sayfasına gidin ve 'dönüştür' bağlantısını seçin.");
define("ADLAN_PM_3", "ÖM ayarları bulunamadı, varsayılan değerler ayarlandı");
define("ADLAN_PM_4", "Seçenekler Güncellendi");
define("ADLAN_PM_5", "Seçilen kullanıcı sınıfı için limit zaten var");
define("ADLAN_PM_6", "Limit başarıyla eklendi");
define("ADLAN_PM_7", "Limit eklenmedi/güncellenmedi - bilinmeyen hata");
define("ADLAN_PM_8", "Limit durumu güncellendi");
define("ADLAN_PM_9", "- Limit başarıyla kaldırıldı");
define("ADLAN_PM_10", "- Limit kaldırılmadı - bilinmeyen hata");
define("ADLAN_PM_11", "- Limit başarıyla güncellendi");
define("ADLAN_PM_12", "ÖM Seçenekleri");
define("ADLAN_PM_13", "ÖM Dönüşümü");
define("ADLAN_PM_14", "ÖM Limitleri");
define("ADLAN_PM_15", "ÖM Limiti Ekle");
define("ADLAN_PM_16", "Eklenti Başlığı");
define("ADLAN_PM_17", "Yeni ÖM animasyonunu göster");
define("ADLAN_PM_18", "Kullanıcı açılır listesini göster");
define("ADLAN_PM_19", "Okunmuş Mesaj zaman aşımı (gün)");
define("ADLAN_PM_20", "Okunmamış mesaj zaman aşımı (gün)");
define("ADLAN_PM_21", "Yeni ÖM'ı açılır bildirim olarak göster");
define("ADLAN_PM_22", "Açılır pencere görünme süresi");
define("ADLAN_PM_23", "ÖM kullanımını şununla sınırla:");
define("ADLAN_PM_24", "Sayfa başına gösterilecek ÖM sayısı");
define("ADLAN_PM_25", "ÖM e-posta bildirimlerini etkinleştir");
define("ADLAN_PM_26", "Kullanıcının okundu bilgisi e-posta bildirimi istemesine izin ver");
define("ADLAN_PM_27", "Ek ekleyebilen kullanıcı sınıfı");
define("ADLAN_PM_28", "Maksimum ek boyutu");
define("ADLAN_PM_29", "Tüm üyelere ÖM göndermeye izin ver");
define("ADLAN_PM_30", "Aynı anda birden fazla kullanıcıya ÖM gönderebilen kullanıcı sınıfı");
define("ADLAN_PM_31", "Tüm kullanıcı sınıflarına ÖM gönderilebilecek kullanıcı sınıfı");
define("ADLAN_PM_33", "Etkin değil (sınır yok)");
define("ADLAN_PM_34", "ÖM sayıları");
define("ADLAN_PM_35", "ÖM kutu boyutları");
define("ADLAN_PM_37", "Limitlerin sayısı");
define("ADLAN_PM_38", "Boyut sınırları (KB olarak)");
define("ADLAN_PM_41", "Şu anda belirlenmiş bir sınır yok.");
define("ADLAN_PM_44", "saniye");
define("ADLAN_PM_45", "ÖM tarafından Sınırlandı:");
define("ADLAN_PM_54", "Ana ayarlar");
define("ADLAN_PM_55", "Limitler");
define("ADLAN_PM_59", "Bakım");
define("ADLAN_PM_60", "ÖM Bakımı");
define("ADLAN_PM_62", "Bu seçenekler, ÖM veritabanı tablolarından silinen kullanıcılarla ilgili işlemleri kaldırır.");
define("ADLAN_PM_63", "Mesajlar gönderildi");
define("ADLAN_PM_64", "Mesajlar alındı");
define("ADLAN_PM_65", "Kullanıcı Engelleri");
define("ADLAN_PM_66", "Bakım görevi belirtilmedi");
define("ADLAN_PM_67", "ÖM VT bakımı başladı");
define("ADLAN_PM_68", "Silinmiş kullanıcılara yönelik [x] engelleme kaldırıldı");
define("ADLAN_PM_69", "Silinen kullanıcılardan [x] engelleme kaldırıldı");
define("ADLAN_PM_70", "Veritabanı hatası [y]: [z] kullanıcı engellerini kaldırıyor");
define("ADLAN_PM_71", "Süresi dolmuş mesajlar");
define("ADLAN_PM_72", "ÖM zaman aşımı ayarlanmadı");
define("ADLAN_PM_73", "[x] süresi dolmuş ÖM'lar silindi");
define("ADLAN_PM_74", "Silinen kullanıcılar tarafından gönderilen [x] mesaj kaldırıldı");
define("ADLAN_PM_75", "Silinen kullanıcılar tarafından alınan [x] mesaj kaldırıldı");
define("ADLAN_PM_77", "(Tüm alanları boşaltın ve bir limiti silmek için Güncelleyin)");
define("ADLAN_PM_78", "Ekleri kontrol et");
define("ADLAN_PM_79", "[x] kullanılmayan ekler silindi. [y] eksik ekler not edildi");
define("ADLAN_PM_80", "Tercih biçimleri güncellendi");
define("ADLAN_PM_81", "Hemen gönderilecek maksimum ÖM sayısı");
define("ADLAN_PM_82", "Bu sayıdan daha fazlası gönderiliyorsa, bunlar bir kuyruğa eklenir ve cron görevi kullanılarak gönderilir.");
define("ADLAN_PM_83", "Kullanıcılar yalnızca bu sınıftaki kullanıcılara mesaj gönderebilir");
define("ADLAN_PM_84", "Maksimum mesaj uzunluğu");
define("ADLAN_PM_85", "0 = sınırsız");
define("ADLAN_PM_86", "VIP Sınıfı");
define("ADLAN_PM_87", "Bu sınıftaki kullanıcılar yalnızca bu sınıftaki diğer kullanıcılardan mesaj alabilir. Yukarıdaki tercihi geçersiz kılar.");
define("ADLAN_PM_88", "Kullanıcı şu kullanıcılara ÖM gönderebilir:");
define("ADLAN_PM_89", "(Aynı sınıfa sahip herhangi bir kullanıcı)");
define("ADLAN_PM_90", "Lütfen 'Kime' alanına bir alıcı girin.");
define("ADLAN_PM_91", "-Test-");
define("ADLAN_PM_92", "Test E-postası Gönderildi!");
define("ADLAN_PM_93", "Test E-postası Gönderilemedi!");
