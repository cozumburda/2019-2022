<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 11:21:11
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_PM_NAME", "Özel Messenger");
define("LAN_PLUGIN_PM_DESCRIPTION", "Bu eklenti, tam özellikli bir Özel Mesajlaşma sistemidir.");
define("LAN_PLUGIN_PM_URL_DEFAULT_LABEL", "Varsayılan");
define("LAN_PLUGIN_PM_URL_DEFAULT_DESCR", "Varsayılan");
define("LAN_PLUGIN_PM_INBOX", "Gelen Kutusu");
define("LAN_PLUGIN_PM_OUTBOX", "Giden Kutusu");
define("LAN_PLUGIN_PM_NEW", "Yeni Mesaj Gönder");
define("LAN_PLUGIN_PM_TO", "Kime");
define("LAN_PLUGIN_PM_FROM", "Kimden");
define("LAN_PLUGIN_PM_SUB", "Konu");
define("LAN_PLUGIN_PM_MESS", "Mesaj");
define("LAN_PLUGIN_PM_READ", "Oku");
define("LAN_PLUGIN_PM_DEL", "ÖM'yi Sil");
define("LAN_PLUGIN_PM_ATTACHMENT", "Ek");
define("LAN_PLUGIN_PM_SIZE", "Boyut");
