<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 09:09:37
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_NEWS_ADMIN_00", "Son Haber Öğeleri");
define("LAN_NEWS_ADMIN_01", "Sabit Haber Öğeleri");
define("LAN_NEWS_ADMIN_02", "Atanan Haber öğeleri");
define("LAN_NEWS_ADMIN_03", "Haber öğelerini belirli bir kategoriyle sınırlayın");
define("LAN_NEWS_ADMIN_04", "Atanan öğeler, 'Haber Tablosu Menüsüne' atanmış bir şablona sahip olanlardır.");
define("LAN_NEWS_ADMIN_05", "Görüntülenecek Öğe Sayısı");
define("LAN_NEWS_ADMIN_06", "Başlık Karakter Sınırı");
define("LAN_NEWS_ADMIN_07", "Özet Karakter Sınırı");
define("LAN_NEWS_ADMIN_08", "Arşiv Bağlantısını Görüntüle");
define("LAN_NEWS_ADMIN_09", "Sınırlar");
define("LAN_NEWS_ADMIN_10", "Özellik Öğesi Sayısı");
define("LAN_NEWS_ADMIN_11", "Atanan öğeler, 'Haber Döngüsüne' atanmış bir şablona sahip olanlardır.");
