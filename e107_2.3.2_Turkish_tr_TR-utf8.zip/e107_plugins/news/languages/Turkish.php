<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 09:06:11
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("TD_MENU_L1", "Diğer Haberler");
define("TD_MENU_L2", "Diğer Haberler");
define("LAN_NEWSCAT_MENU_TITLE", "Haber Kategorileri");
define("LAN_NEWSLATEST_MENU_TITLE", "Son Haberler");
define("LAN_NEWSARCHIVE_MENU_TITLE", "Haber Arşivi");
