<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 08:56:37
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_LIST_NEW_NAME", "Yeni Liste Öğeleri");
define("LAN_PLUGIN_LIST_NEW_DESCRIPTION", "Bu eklenti, tüm e107 kategorilerinde son eklenenlerin bir listesini ve/veya menüsünü görüntülemenizi sağlar. Son ziyaretinizden bu yana verileri içeren listeyi görüntüleyebilir veya genel bir en son eklenenler listesini görüntüleyebilirsiniz.");
