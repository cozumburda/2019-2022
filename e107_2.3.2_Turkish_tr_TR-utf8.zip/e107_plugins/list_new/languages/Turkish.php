<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 08:27:55
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LIST_MENU_1", "son eklemeler");
define("LIST_MENU_2", "tarafından");
define("LIST_MENU_3", "-on-");
define("LIST_MENU_4", "-in-");
define("LIST_MENU_5", "gün");
define("LIST_MENU_6", "içeriği kaç gün boyunca görüntüleyebilirsiniz?");
define("LIST_MENU_7", "-");
define("LIST_MENU_8", "-");
define("LIST_MENU_9", "-");
define("LIST_MENU_10", "-");
define("LIST_MENU_11", "-");
define("LIST_MENU_12", "-");
define("LIST_MENU_13", "-");
define("LIST_MENU_14", "-");
define("LIST_MENU_15", "-");
define("LIST_MENU_16", "-");
define("LIST_MENU_17", "-");
define("LIST_MENU_18", "-");
define("LIST_MENU_19", "-");
define("LIST_NEWS_1", "haberler");
define("LIST_NEWS_2", "haber öğesi yok");
define("LIST_COMMENT_1", "yorumlar");
define("LIST_COMMENT_2", "yorum yok");
define("LIST_COMMENT_3", "haberler");
define("LIST_COMMENT_4", "sss");
define("LIST_COMMENT_5", "anket");
define("LIST_COMMENT_6", "dökümanlar");
define("LIST_COMMENT_7", "hata izleme");
define("LIST_COMMENT_8", "içerik");
define("LIST_COMMENT_9", "-");
define("LIST_COMMENT_10", "düşünceler");
define("LIST_MEMBER_1", "üyeler");
define("LIST_MEMBER_2", "üye yok");
define("LIST_CONTENT_1", "içerik");
define("LIST_CONTENT_2", "içerik yok");
define("LIST_CONTENT_3", "geçerli içerik kategorisi yok");
define("LIST_CHATBOX_1", "mesaj kutusu");
define("LIST_CHATBOX_2", "mesaj kutusunda gönderi yok");
define("LIST_CALENDAR_1", "takvim");
define("LIST_CALENDAR_2", "takvim etkinliği yok");
define("LIST_LINKS_1", "linkler");
define("LIST_LINKS_2", "link yok");
define("LIST_FORUM_1", "-forum-");
define("LIST_FORUM_2", "forum gönderisi yok");
define("LIST_FORUM_3", "görüntülemeler:");
define("LIST_FORUM_4", "cevaplar:");
define("LIST_FORUM_5", "son gönderi:");
define("LIST_FORUM_6", "açık:");
define("LIST_LAN_1", "öğe yok");
define("LIST_DOWNLOAD_1", "indirmeler");
define("LIST_DOWNLOAD_2", "indirme yok");
