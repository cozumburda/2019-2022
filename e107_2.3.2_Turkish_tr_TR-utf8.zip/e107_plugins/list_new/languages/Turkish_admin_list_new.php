<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 08:55:33
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LIST_PLUGIN_3", "Ana Menüyü Yapılandır");
define("LIST_PLUGIN_4", "List_new eklentisi artık kullanıma hazır.");
define("LIST_PLUGIN_6", "Bu eklenti kurulu değil.");
define("LIST_ADMIN_1", "son");
define("LIST_ADMIN_2", "ayarları güncelle");
define("LIST_ADMIN_3", "ayarlar güncellendi");
define("LIST_ADMIN_4", "bölüm");
define("LIST_ADMIN_5", "menü");
define("LIST_ADMIN_6", "sayfa");
define("LIST_ADMIN_7", "etkin");
define("LIST_ADMIN_8", "devre dışı");
define("LIST_ADMIN_9", "açık");
define("LIST_ADMIN_10", "kapalı");
define("LIST_ADMIN_11", "güncelle");
define("LIST_ADMIN_12", "seç");
define("LIST_ADMIN_13", "'.SITENAME.' sitesinin son sayfasına hoş geldiniz! Bu sayfa, bu sitenin en yaygın bölümleri için, bu bölümlerdeki en son eklenenlerin bir listesini gösterir.");
define("LIST_ADMIN_14", "son eklemeler");
define("LIST_ADMIN_15", "son ziyaretinizden beri yeni");
define("LIST_ADMIN_16", "'.SITENAME.' in yeni sayfasına hoş geldiniz! Bu sayfa, bu sitenin en sık kullanılan bölümleri için, son ziyaretinizden bu yana bu bölümlere yapılan eklemelerin bir listesini gösterir.");
define("LIST_ADMIN_17", "Hiçbir şey değişmedi - güncellenmedi");
define("LIST_ADMIN_SECT_1", "bölümler");
define("LIST_ADMIN_SECT_2", "hangi bölümlerin gösterileceğini seçin");
define("LIST_ADMIN_SECT_3", "-");
define("LIST_ADMIN_SECT_4", "ekran stili");
define("LIST_ADMIN_SECT_5", "varsayılan olarak hangi bölümlerin açılacağını seçin");
define("LIST_ADMIN_SECT_6", "-");
define("LIST_ADMIN_SECT_7", "yazar");
define("LIST_ADMIN_SECT_8", "yazarın görüntülenip görüntülenmeyeceğini seçin");
define("LIST_ADMIN_SECT_9", "-");
define("LIST_ADMIN_SECT_10", "kategori");
define("LIST_ADMIN_SECT_11", "kategorinin görüntülenip görüntülenmeyeceğini seçin");
define("LIST_ADMIN_SECT_12", "-");
define("LIST_ADMIN_SECT_13", "tarih");
define("LIST_ADMIN_SECT_14", "tarihin görüntülenip görüntülenmeyeceğini seçin");
define("LIST_ADMIN_SECT_15", "-");
define("LIST_ADMIN_SECT_16", "öğelerin miktarı");
define("LIST_ADMIN_SECT_17", "her bölüm için kaç öğenin görüntülenmesi gerektiğini seçin");
define("LIST_ADMIN_SECT_18", "-");
define("LIST_ADMIN_SECT_19", "öğelerin sırası");
define("LIST_ADMIN_SECT_20", "bölümlerin görüntülenmesi gereken sırayı seçin");
define("LIST_ADMIN_SECT_21", "-");
define("LIST_ADMIN_SECT_22", "simge");
define("LIST_ADMIN_SECT_23", "her bölüm için bir simge seçin");
define("LIST_ADMIN_SECT_24", "-");
define("LIST_ADMIN_SECT_25", "başlık");
define("LIST_ADMIN_SECT_26", "her bölüm için bir başlık tanımlayın");
define("LIST_ADMIN_SECT_27", "-");
define("LIST_ADMIN_OPT_1", "genel");
define("LIST_ADMIN_OPT_2", "son sayfa");
define("LIST_ADMIN_OPT_3", "son menü");
define("LIST_ADMIN_OPT_4", "yeni sayfa");
define("LIST_ADMIN_OPT_5", "yeni menü");
define("LIST_ADMIN_OPT_6", "seçenekler");
define("LIST_ADMIN_MENU_2", "simge: varsayılan");
define("LIST_ADMIN_MENU_3", "simge yoksa veya simge kullanımı devre dışıysa varsayılan tema madde işaretini kullan");
define("LIST_ADMIN_LAN_2", "başlık");
define("LIST_ADMIN_LAN_3", "bir başlık tanımlayın");
define("LIST_ADMIN_LAN_5", "simge: kullan");
define("LIST_ADMIN_LAN_6", "her bölümdeki simgeyi kullan");
define("LIST_ADMIN_LAN_8", "karakter");
define("LIST_ADMIN_LAN_9", "başlığın kaç karakterinin gösterileceğini seçin");
define("LIST_ADMIN_LAN_10", "tam başlığı göstermek için boş bırakın");
define("LIST_ADMIN_LAN_11", "sonek");
define("LIST_ADMIN_LAN_12", "başlık verilen karakter miktarından daha büyükse bir son ek seçin");
define("LIST_ADMIN_LAN_13", "sonek göstermemek için boş bırakın");
define("LIST_ADMIN_LAN_14", "tarih");
define("LIST_ADMIN_LAN_15", "bir tarih stili seçin");
define("LIST_ADMIN_LAN_16", "Tarih biçimleri hakkında daha fazla bilgi için php.net'teki <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>strftime fonksiyon sayfasına</a> bakın.");
define("LIST_ADMIN_LAN_17", "bugünün tarihi");
define("LIST_ADMIN_LAN_18", "tarih bugün ise bir tarih stili seçin");
define("LIST_ADMIN_LAN_19", "Tarih biçimleri hakkında daha fazla bilgi için php.net'teki <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>strftime fonksiyon sayfasına</a> bakın.");
define("LIST_ADMIN_LAN_20", "kolonlar");
define("LIST_ADMIN_LAN_21", "bir kaç sütun seçin");
define("LIST_ADMIN_LAN_22", "kaç sütun kullanmak istediğinizi tanımlayın. belirttiğiniz sayı, sayfayı eşit sayıda sütuna ayırır");
define("LIST_ADMIN_LAN_23", "karşılama metni");
define("LIST_ADMIN_LAN_24", "sayfanın üst kısmında işlenecek bir karşılama metni tanımlayın");
define("LIST_ADMIN_LAN_26", "boş göster");
define("LIST_ADMIN_LAN_27", "bölümlerde sonuç olmadığında bir mesajın gösterilmesi gerekip gerekmediğini tanımlayın");
define("LIST_ADMIN_LAN_28", "-");
define("LIST_ADMIN_LAN_29", "simge: varsayılan");
define("LIST_ADMIN_LAN_30", "simge yoksa veya simge kullanımı devre dışıysa varsayılan tema madde işaretini kullan");
define("LIST_ADMIN_LAN_32", "hızlandırılmış:gün");
define("LIST_ADMIN_LAN_33", "kullanıcıların geriye bakabileceği maksimum gün sayısı");
define("LIST_ADMIN_LAN_35", "gün");
define("LIST_ADMIN_LAN_36", "hızlandırılmış");
define("LIST_ADMIN_LAN_37", "geriye bakılacak gün sayısını içeren bir seçim kutusu gösterilsin mi?");
define("LIST_ADMIN_LAN_39", "kayıt varsa aç");
define("LIST_ADMIN_LAN_40", "Kayıt içeren bölümler varsayılan olarak açılsın mı?");
define("LAN_AL_LISTNEW_01", "Listenin yeni tercihleri güncellendi");
