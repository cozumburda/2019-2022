<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 09:59:09
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_PAGE_BOCHAP", "Kitapta/Bölümde Ara");
define("LAN_PLUGIN_PAGE_NAME", "Sayfalar");
