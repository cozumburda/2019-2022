<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/03 11:39:00
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("LAN_PLUGIN_DOWNLOAD_NAME", "İndirmeler");
define("LAN_PLUGIN_DOWNLOAD_DIZ", "Bu eklenti, tam özellikli bir Dosya indirme sistemidir.");
define("LAN_DL_NT_01", "Bozuk indirme rapor edildi");
define("LAN_DL_NT_02", "Aşağıdaki indirmenin bozuk olduğu rapor edildi:");
define("LAN_DL_NT_03", "[x] tarafından aşağıdaki yorumlarla rapor edildi:");
define("LAN_DL_NT_04", "Bozuk indirme raporlarını görüntülemek için  [here] buraya tıklayın.");
define("LAN_DL_LATEST_01", "Rapor edilen bozuk indirmeler");
