<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/03 11:36:35
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("LAN_dl_1", "(Sınırlı)");
define("LAN_dl_4", "Mevcut dosyalar:");
define("LAN_dl_5", "Dosyaların toplam boyutu:");
define("LAN_dl_6", "İndirilen dosyalar:");
define("LAN_dl_8", "Al (Get)");
define("LAN_dl_9", "Kategori Listesine Dön");
define("LAN_dl_13", "Değerlendirilmemiş");
define("LAN_dl_14", "Bu indirmeyi değerlendirin");
define("LAN_dl_16", "indirme(ler)");
define("LAN_dl_29", "İndirmeler");
define("LAN_dl_30", "E-mail Yazarı");
define("LAN_dl_31", "Web Site Yazarı");
define("LAN_dl_36", "Yeni İndirmeler");
define("LAN_dl_40", "Ekran görüntüsü için buraya tıklayın");
define("LAN_dl_43", "oy");
define("LAN_dl_44", "oylar");
define("LAN_dl_45", "Bozuk indirmeyi raporla");
define("LAN_dl_46", "indirmek için buraya tıkla");
define("LAN_dl_47", "Gönderi rapor edildi");
define("LAN_dl_48", "İndirme yöneticiye rapor edildi. Teşekkürler.");
define("LAN_dl_49", "İndirmelere geri dönmek için buraya tıklayın");
define("LAN_dl_53", "İndirmeyi görüntülemek için tıklayın");
define("LAN_dl_54", "Bir yönetici bu indirmeden haberdar edilecek, gerekli olduğunu düşünüyorsanız lütfen bir mesaj bırakın.");
define("LAN_dl_55", "Farklı herhangi bir nedenle yöneticiyle iletişim kurmak için bu formu kullanmayın.");
define("LAN_dl_62", "Bu dosyayı indirmeniz engellendi; indirme kotanızı aştınız");
define("LAN_dl_63", "Bu dosyayı indirmek için gerekli izinlere sahip değilsiniz.");
define("LAN_dl_66", "İndirme kaynağı seç");
define("LAN_dl_67", "Kaynak Seçiliyor ...");
define("LAN_dl_68", "Kaynak Sunucu");
define("LAN_dl_72", "Dosya isteniyor:");
define("LAN_dl_73", "Bu kaynaktaki indirmeler:");
define("LAN_dl_74", "Bu kaynaktan toplam indirme sayısı:");
define("LAN_dl_75", "resim yok");
define("LAN_dl_77", "İndirmeler");
define("LAN_dl_78", "Bu indirme devre dışı bırakıldı veya durduruldu. Daha yeni bir sürüm için lütfen [downloads area] indirilenler alanına bakın.");
define("LAN_dl_79", "Bu indirilen öğeyi bozuk olarak bildirmek için gerekli izinlere sahip değilsiniz.");
