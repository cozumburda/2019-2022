<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/03 11:41:14
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("LAN_AL_DOWNL_01", "İndirilenler - indirme seçenekleri değişti");
define("LAN_AL_DOWNL_02", "İndirilenler - yükleme seçenekleri değiştirildi");
define("LAN_AL_DOWNL_03", "İndirilenler - limit eklendi");
define("LAN_AL_DOWNL_04", "İndirilenler - günlük 04");
define("LAN_AL_DOWNL_05", "İndirilenler - günlük 05");
define("LAN_AL_DOWNL_06", "İndirilenler - günlük 06");
define("LAN_AL_DOWNL_07", "İndirilenler - günlük 07");
define("LAN_AL_DOWNL_08", "İndirilenler - günlük 08");
define("LAN_AL_DOWNL_09", "İndirilenler - günlük 09");
define("LAN_AL_DOWNL_10", "İndirilenler - limit güncellendi");
define("LAN_AL_DOWNL_11", "İndirilenler - limit kaldırıldı");
