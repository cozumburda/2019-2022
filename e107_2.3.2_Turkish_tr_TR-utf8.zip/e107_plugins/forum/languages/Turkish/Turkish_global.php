<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/03 14:20:55
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_FORUM_NAME", "-Forum-");
define("LAN_PLUGIN_FORUM_DESC", "Bu eklenti tam özellikli bir forum sistemidir.");
define("LAN_PLUGIN_FORUM_POSTS", "Forum gönderileri");
define("LAN_PLUGIN_FORUM_ALLFORUMS", "Tüm Forumlar");
define("LAN_PLUGIN_FORUM_LATESTPOSTS", "Son Gönderiler");
define("FORUM_LAN_URL_DEFAULT_LABEL", "Varsayılan Forum URL'leri");
define("FORUM_LAN_URL_DEFAULT_DESCR", "Tek bir giriş noktası olmayan 'GET tipi' URL'ler. Örnekler:<br />http://yoursite.com/e107_plugins/forum/forum.php (forum dizini)<br />http://yoursite.com/e107_plugins/forum/forum_viewtopic.php?id=2 (İleti Dizisi Görünümü)");
define("FORUM_LAN_URL_REWRITE_LABEL", "SEF Forum URL'leri (GELİŞTİRME AŞAMASINDA)");
define("FORUM_LAN_URL_REWRITE_DESCR", "Örnekler:<br />GELİŞTİRME AŞAMASINDA");
