<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/03 14:32:27
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_FORUM_MENU_001", "tarafından gönderildi");
define("LAN_FORUM_MENU_002", "Henüz gönderi yok");
define("LAN_FORUM_MENU_003", "Yeni Forum Gönderi menü yapılandırması kaydedildi");
define("LAN_FORUM_MENU_004", "Resim Yazısı");
define("LAN_FORUM_MENU_005", "Görüntülenecek gönderi sayısı?");
define("LAN_FORUM_MENU_006", "Görüntülenecek karakter sayısı?");
define("LAN_FORUM_MENU_007", "Çok uzun gönderiler için son düzeltme?");
define("LAN_FORUM_MENU_008", "Orijinal konular menüde gösterilsin mi?");
define("LAN_FORUM_MENU_009", "Menü Ayarlarını Güncelle");
define("LAN_FORUM_MENU_012", "Görüntülenen gönderilerin maksimum yaşı");
define("LAN_FORUM_MENU_013", "Sakin bir sitede sıfır kullanın; gün cinsinden bir değer ayarlamak, yoğun bir sitede veritabanı süresini azaltır");
define("LAN_FORUM_MENU_014", "Kaydırma katmanı yüksekliği (piksel olarak)");
define("LAN_FORUM_MENU_015", "Kaydırma olmaması için boş bırakın");
define("LAN_FORUM_MENU_016", "Henüz forum kategorisi oluşturulmadı!");
