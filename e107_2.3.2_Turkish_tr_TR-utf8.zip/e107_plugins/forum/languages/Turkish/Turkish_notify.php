<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/03 14:51:15
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_FORUM_NT_7", "Forum - Yeni kullanıcı tarafından oluşturulan İleti Dizisi");
define("LAN_FORUM_NT_8", "Forum - İleti Dizisi silindi");
define("LAN_FORUM_NT_9", "Forum - İleti Dizisi Ayrıldı");
define("LAN_FORUM_NT_10", "Forum - Gönderi silindi");
define("LAN_FORUM_NT_11", "Forum - Gönderi raporlandı");
define("LAN_FORUM_NT_12", "Forum - İleti Dizisi güncellendi");
define("LAN_FORUM_NT_13", "Forum - İleti Dizisi taşındı");
define("LAN_FORUM_NT_14", "Forum - Gönderi oluşturuldu");
define("LAN_FORUM_NT_15", "Forum - Gönderi güncellendi");
define("LAN_FORUM_NT_NEWTOPIC", "Yeni konu oluşturuldu");
define("LAN_FORUM_NT_NEWTOPIC_PROB", "Deneme süresindeki üye tarafından oluşturulan yeni konu");
define("LAN_FORUM_NT_TOPIC_SPLIT", "Konu ayrıldı");
define("LAN_FORUM_NT_TOPIC_UPDATED", "Konu güncellendi");
define("LAN_FORUM_NT_TOPIC_DELETED", "Konu silindi");
define("LAN_FORUM_NT_TOPIC_MOVED", "Konu taşındı");
define("LAN_FORUM_NT_POST_CREATED", "Gönderi oluşturuldu");
define("LAN_FORUM_NT_POST_UPDATED", "Gönderi güncellendi");
define("LAN_FORUM_NT_POST_DELETED", "Gönderi silindi");
define("LAN_FORUM_NT_POST_REPORTED", "Gönderi raporlandı");
define("LAN_FORUM_NT_NEWTOPIC_MSG", "[forum] forumunda yeni ileti dizisini oluşturan: [user]\nKonu: [thread]\n\n Mesaj:\n[post]");
define("LAN_FORUM_NT_NEWTOPIC_PROB_MSG", "[forum] forumunda yeni kullanıcı tarafından oluşturulan yeni ileti dizisi: [user]\nKonu: [thread]\n\nMesaj:\n[post]");
define("LAN_FORUM_NT_TOPIC_UPDATED_MSG", "İleti dizisi [thread] (Forum adı: [forum]) tarafından güncellendi: [user]");
define("LAN_FORUM_NT_TOPIC_DELETED_MSG", "Forum [forum]'daki [thread] ileti dizisi, [user] tarafından silindi");
define("LAN_FORUM_NT_TOPIC_MOVED_MSG", "İleti dizisi [threadi], [forum]'dan [forum2] forumuna şu kişi tarafından taşındı: [user]");
define("LAN_FORUM_NT_POST_CREATED_MSG", "[thread] ileti dizisindeki yeni mesaj (Forum adı: [forum]) tarafından oluşturuldu: [user]\nMesaj:\n[post]");
define("LAN_FORUM_NT_POST_UPDATED_MSG", "[thread] ileti dizisindeki mesaj (Forum adı: [forum]) güncellendi: [user]\nMesaj:\n[post]");
define("LAN_FORUM_NT_POST_DELETED_MSG", "Forum [forum]'daki [thread] ileti dizisinin #[postid] iletisi: [user]\n\nMesaj:\n[post] tarafından silindi");
