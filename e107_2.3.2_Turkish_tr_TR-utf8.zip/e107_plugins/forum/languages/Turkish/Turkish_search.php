<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/03 14:52:10
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("FOR_SCH_LAN_2", "Forum seç");
define("FOR_SCH_LAN_4", "Tüm gönderiler");
define("FOR_SCH_LAN_5", "İleti dizisinin bir parçası olarak");
