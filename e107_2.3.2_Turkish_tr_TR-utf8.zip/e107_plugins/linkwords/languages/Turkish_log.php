<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 08:22:25
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_AL_LINKWD_00", "Linkword ile ilgili mesaj");
define("LAN_AL_LINKWD_01", "Linkword Eklendi");
define("LAN_AL_LINKWD_02", "Linkword Düzenlendi");
define("LAN_AL_LINKWD_03", "Linkword Silindi");
define("LAN_AL_LINKWD_04", "Linkword seçenekleri güncellendi");
define("LAN_AL_LINKWD_05", "Linkword sürümü güncelle");
