<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 08:21:15
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_LINKWORDS_NAME", "Linkwordler");
define("LAN_PLUGIN_LINKWORDS_DESCRIPTION", "Bu eklenti, belirtilen kelimeleri tanımlanmış bir bağlantı ve/veya araç ipucu ile bağlayacaktır.");
