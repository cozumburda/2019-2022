<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 08:20:12
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LWLAN_4", "Henüz linkwords tanımlanmadı.");
define("LWLAN_5", "Kelimeler");
define("LWLAN_6", "Bağlantı");
define("LWLAN_7", "Etkin mi?");
define("LWLAN_21", "Word'den otomatik bağlantıya (veya virgülle ayrılmış sözcük listesine)");
define("LWLAN_26", "Linkwords'ün etkinleştirileceği alanlar");
define("LWLAN_28", "Linkwords'ün devre dışı bırakılacağı sayfalar");
define("LWLAN_33", "Başlık alanları");
define("LWLAN_34", "Öğe özetleri");
define("LWLAN_35", "Gövde metni");
define("LWLAN_36", "Açıklamalar (bağlantılar vb.)");
define("LWLAN_40", "Kullanıcı tarafından girilen başlıklar (ör. forum)");
define("LWLAN_41", "Kullanıcı tarafından girilen gövde metni (ör. forum)");
define("LWLAN_50", "İpucu");
define("LWLAN_52", "Sadece Linkword");
define("LWLAN_53", "Sadece ipucu");
define("LWLAN_54", "Linkword ve İpucu");
define("LWLAN_55", "Bağlantıyı yeni pencerede aç");
define("LWLAN_58", "0.8 biçimine dönüştürülen Hook tercihleri");
define("LWLAN_59", "Ajax işlevselliğini etkinleştir");
define("LWLAN_64", "Geçerli sayfadaki bağlantıyı gizle");
define("LWLAN_66", "Özel CSS sınıfı");
define("LWLAN_67", "bağlantılar/ipuçları");
define("LAN_LW_HELP_01", "Birçok metin alanının ilişkilendirilmiş bir 'bağlam' vardır ve bağlantı sözcükleri yalnızca bu bağlamla eşleşen alanlarda görüntülenecektir.");
define("LAN_LW_HELP_02", "Araç ipuçları, görüntüleme için bilgi almak üzere Ajax'ı kullanabilir. Bu genellikle bazı özel kodlamalar gerektirir.");
define("LAN_LW_HELP_03", "Kullanıcı zaten bağlantı verdiği sayfadaysa, kullanıcının bir bağlantıya tıklayabilmesi genellikle anlamsızdır. Bu seçenek AÇIK konuma getirildiğinde, bu durumda bağlantı sözcükleri tetiklenmez.");
define("LAN_LW_HELP_04", "Linkwords, belirli sayfalarda veya bir kalıpla eşleşen sayfalarda devre dışı bırakılabilir. Bunları buraya girin (menü görünürlüğü ile aynı sözdizimi), her satıra bir model. Kalıp '!' ile bitiyorsa, bu 'sorgu sonuna' karşılık gelir ve genellikle tam bir eşleşmedir. Aksi takdirde, belirtilen dizeyi içeren herhangi bir URL eşleşir.");
define("LAN_LW_HELP_05", "Oluşturulan tüm bağlantılara bu sınıfı ekleyecektir.");
define("LAN_LW_HELP_10", "Burada, tıklanabilir bağlantı haline gelen veya fareyle üzerine gelindiğinde metni görüntüleyen sözcükleri tanımlayabilirsiniz.");
define("LAN_LW_HELP_11", "Bu, büyük/küçük harfe duyarsızdır. Aynı bağlantılara ve araç ipuçlarına eşlenen birden fazla kelime için bunları virgülle ayırın (boşluk yok)");
define("LAN_LW_HELP_12", "Burada tıklanabilir bir bağlantı tanımlayın. Harici bir bağlantı ise, 'http(s)://' ile başlaması ZORUNLUDUR. Bu site içindeki bir bağlantı ise, normal {e_XXX} sabitleri kullanılabilir.");
define("LAN_LW_HELP_13", "Hangi seçeneklerin etkin olduğunu tanımlar.");
define("LAN_LW_HELP_14", "Bu, kullanıcının faresi kelimenin üzerine geldiğinde görüntülenecek metni tanımlar.");
define("LAN_LW_HELP_15", "Aynı  linkword'ün maksimum miktarı. Pozitif sayı olmalıdır. Aynı kelime bir metin parçasında birden çok kez bulunduğunda kullanılır.");
define("LAN_LW_HELP_16", "Bu, Ajax işleme ile kullanılacak isteğe bağlı bir sayısal kimliği tanımlar. Pozitif bir sayı olmalıdır. Boşsa, veritabanı kayıt numarası kullanılır");
define("LAN_LW_HELP_17", "Açıldığında, bağlantı yeni tarayıcı sekmesinde/penceresinde açılır");
