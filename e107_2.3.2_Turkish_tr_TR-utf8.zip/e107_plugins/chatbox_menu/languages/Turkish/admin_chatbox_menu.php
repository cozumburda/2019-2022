<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/02 07:35:23
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("CHBLAN_11", "Görüntülenecek sohbet kutusu gönderileri");
define("CHBLAN_12", "Sohbet kutusunda görüntülenen gönderi miktarı");
define("CHBLAN_20", "Sohbet Kutusu Ayarları");
define("CHBLAN_22", "Belirli bir süreden daha eski gönderileri silin");
define("CHBLAN_23", "Şu tarihten daha eski gönderileri sil");
define("CHBLAN_24", "Bir gün");
define("CHBLAN_25", "Bir hafta");
define("CHBLAN_26", "Bir Ay");
define("CHBLAN_27", "- Tüm gönderileri sil -");
define("CHBLAN_29", "[x] yüksekliğinde kayan katmanda sohbet kutusunu görüntüle");
define("CHBLAN_31", "İfadeleri göster");
define("CHBLAN_32", "Moderatör kullanıcı sınıfı");
define("CHBLAN_33", "Kullanıcı sayıları yeniden hesaplandı");
define("CHBLAN_34", "Kullanıcı gönderi sayılarını yeniden hesapla");
define("CHBLAN_35", "Yeniden Hesapla");
define("CHBLAN_36", "Sohbet Kutusu Görüntüleme Seçenekleri");
define("CHBLAN_37", "Normal sohbet kutusu");
define("CHBLAN_38", "Gönderileri dinamik olarak güncellemek için javascript kodunu kullanın (AJAX)");
define("CHBLAN_42", "Kullanıcı profilindeki gönderi miktarını göster");
