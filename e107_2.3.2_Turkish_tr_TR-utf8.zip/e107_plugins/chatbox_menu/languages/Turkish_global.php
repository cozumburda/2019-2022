<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/02 07:30:20
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_CHATBOX_MENU_NAME", "Mesaj Kutusu");
define("LAN_PLUGIN_CHATBOX_MENU_DESCRIPTION", "Mesaj Kutusu Menüsü");
define("LAN_PLUGIN_CHATBOX_MENU_POSTS", "Mesaj Kutusu Gönderileri");
define("LAN_AL_CHBLAN_01", "Sohbet kutusu ayarları güncellendi");
define("LAN_AL_CHBLAN_02", "Sohbet kutusu budandı");
define("LAN_AL_CHBLAN_03", "Sohbet kutusu gönderileri yeniden hesaplandı");
define("LAN_AL_CHBLAN_04", "-");
define("LAN_AL_CHBLAN_05", "-");
define("NT_LAN_CB_1", "Sohbet Kutusu Etkinlikleri");
define("NT_LAN_CB_2", "Mesaj gönderildi");
define("NT_LAN_CB_3", "tarafından Gönderildi");
define("NT_LAN_CB_5", "Mesaj");
define("NT_LAN_CB_6", "Sohbet Kutusu Mesajı Gönderildi");
