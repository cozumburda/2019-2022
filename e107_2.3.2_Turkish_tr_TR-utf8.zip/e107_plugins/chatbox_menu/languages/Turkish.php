<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/02 07:26:27
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("CHATBOX_L1", "Bu kullanıcı adı kayıtlı olduğu için gönderi kabul edilemiyor - bu sizin kullanıcı adınızsa, lütfen gönderi göndermek için giriş yapın.");
define("CHATBOX_L3", "Bu siteye yorum göndermek için giriş yapmalısınız - lütfen Giriş bölümünden veya [here] buradan giriş yapın.");
define("CHATBOX_L3b", "Kayıtlı değilseniz kaydolmak için  [here] buraya tıklayın.");
define("CHATBOX_L4", "Yeni mesaj gönder");
define("CHATBOX_L5", "Sıfırla");
define("CHATBOX_L6", "[blocked by admin] yönetici tarafından engellendi");
define("CHATBOX_L7", "Engeli Kaldır");
define("CHATBOX_L8", "Bilgi");
define("CHATBOX_L9", "Engelle");
define("CHATBOX_L11", "Henüz mesaj yok.");
define("CHATBOX_L12", "Tüm gönderileri görüntüle");
define("CHATBOX_L13", "Sohbet kutusunu yönet");
define("CHATBOX_L14", "İfadeler");
define("CHATBOX_L15", "Gönderi çok uzun veya boş gönderildi");
define("CHATBOX_L17", "Yinelenen gönderi");
define("CHATBOX_L18", "Sohbet kutusu mesajları yönetildi");
define("CHATBOX_L19", "Her [x] saniyede yalnızca bir gönderi paylaşabilirsiniz");
define("CHATBOX_L20", "Sohbet kutusu (tüm gönderiler)");
define("CHATBOX_L22", "açık");
define("CHATBOX_L24", "Bu sayfayı görüntülemek için doğru izinlere sahip değilsiniz.");
define("CHATBOX_L25", "[ this post has been blocked by admin ] bu gönderi yönetici tarafından engellendi");
define("LAN_CHATBOX_100", "Mesajınızı buraya yazın.");
