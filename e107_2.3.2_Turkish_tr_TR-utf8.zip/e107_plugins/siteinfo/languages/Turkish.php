<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 11:49:45
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("COMPLIANCE_L1", "W3C Uyumluluğu");
define("SITEBUTTON_MENU_L1", "Linkimiz");
define("POWEREDBY_L1", "Tarafından desteklenmektedir");
define("COUNTER_L1", "Yönetici ziyaretleri sayılmıyor.");
define("COUNTER_L2", "Bu sayfa bugün...");
define("COUNTER_L3", "toplam");
define("COUNTER_L4", "Bu sayfa hiç...");
define("COUNTER_L5", "tekil");
define("COUNTER_L6", "-Site ...-");
define("COUNTER_L7", "Sayaç");
define("COUNTER_L8", "Yönetici mesajı: <b>İstatistik günlüğü devre dışı bırakıldı.</b><br />Etkinleştirmek için, İstatistik Günlüğü eklentisini <a href=''.e_ADMIN.'plugin.php'>eklenti yöneticinizden yüklemeniz gerekir.</a>, ardından <a href=''.e_PLUGIN.'log/admin_config.php'>yapılandırma ekranından</a> etkinleştirin.");
