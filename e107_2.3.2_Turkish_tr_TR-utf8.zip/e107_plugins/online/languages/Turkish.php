<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 09:58:41
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_LASTSEEN_1", "Son Görülenler Menüsü");
define("LAN_ONLINE_TRACKING_MESSAGE", "Çevrimiçi kullanıcı takibi şu anda devre dışı, lütfen [buradan] etkinleştirin");
define("LAN_ONLINE_1", "Misafirler:");
define("LAN_ONLINE_2", "Üyeler:");
define("LAN_ONLINE_3", "Bu sayfada");
define("LAN_ONLINE_4", "Çevrimiçi");
define("LAN_ONLINE_5", "-");
define("LAN_ONLINE_6", "En yeni Üye:");
define("LAN_ONLINE_7", "görüntüleniyor");
define("LAN_ONLINE_8", "Şimdiye kadar en çok çevrimiçi olan:");
define("LAN_ONLINE_9", "açık");
define("LAN_ONLINE_10", "Çevrimiçi Menü");
define("LAN_ONLINE_11", "Toplam kayıtlı üye sayısı:");
define("LAN_ONLINE_ADMIN_1", "son görülme menüsü");
define("LAN_ONLINE_ADMIN_2", "Son görülme menüsü başlığı");
define("LAN_ONLINE_ADMIN_3", "Görüntülenecek kayıt sayısı");
define("LAN_ONLINE_ADMIN_4", "çevrimiçi menü");
define("LAN_ONLINE_ADMIN_5", "çevrimiçi menü başlığı");
define("LAN_ONLINE_ADMIN_6", "Çevrimiçi üye listesi gösterilsin mi?");
define("LAN_ONLINE_ADMIN_7", "Genişletilmiş çevrimiçi üye listesi gösterilsin mi?");
define("LAN_ONLINE_ADMIN_8", "Virgülle ayrılmış bir üye listesi görüntüler.");
define("LAN_ONLINE_ADMIN_9", "Bir sayfayı görüntüleyen üyelerin listesini görüntüler.");
define("LAN_ONLINE_ADMIN_10", "Çevrimiçi olan misafirleri görüntüle.");
