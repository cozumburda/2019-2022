<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/08/04 09:05:19
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/

define("LAN_LOGINMENU_1", "Kullanıcı Adı:");
define("LAN_LOGINMENU_2", "Şifre:");
define("LAN_LOGINMENU_3", "Üye ol");
define("LAN_LOGINMENU_4", "Şifrenizi mi unuttunuz?");
define("LAN_LOGINMENU_5", "Hoşgeldin");
define("LAN_LOGINMENU_6", "Beni hatırla");
define("LAN_LOGINMENU_7", "Benzersiz kullanıcı kimliği tanınmadı (muhtemelen bozuk çerez). Çerezi yok etmek için lütfen aşağıdaki çıkış bağlantısını tıklayın.");
define("LAN_LOGINMENU_9", "Sisteme giriş hatası");
define("LAN_LOGINMENU_10", "Bakım bayrağı açıktır - bu, normal ziyaretçilerin sitedown.php'ye yönlendirildiği anlamına gelir. Bayrağı sıfırlamak için yönetici/bakım bölümüne gidin.");
define("LAN_LOGINMENU_11", "Yönetici Alanı");
define("LAN_LOGINMENU_13", "Profil");
define("LAN_LOGINMENU_14", "haber öğesi");
define("LAN_LOGINMENU_15", "haber öğeleri");
define("LAN_LOGINMENU_16", "sohbet kutusu gönderisi");
define("LAN_LOGINMENU_17", "sohbet kutusu gönderileri");
define("LAN_LOGINMENU_18", "yorum");
define("LAN_LOGINMENU_19", "yorumlar");
define("LAN_LOGINMENU_20", "forum gönderisi");
define("LAN_LOGINMENU_21", "forum gönderileri");
define("LAN_LOGINMENU_22", "yeni site üyesi");
define("LAN_LOGINMENU_23", "yeni site üyeleri");
define("LAN_LOGINMENU_24", "Yeni öğelerin listesini görmek için buraya tıklayın");
define("LAN_LOGINMENU_25", "Son ziyaretinizden bu yana");
define("LAN_LOGINMENU_26", "-no-");
define("LAN_LOGINMENU_27", "ve");
define("LAN_LOGINMENU_31", "Yeni Haber Gönderilerini Göster");
define("LAN_LOGINMENU_34", "Yeni Yorum Gönderilerini Göster");
define("LAN_LOGINMENU_36", "Yeni Üyeleri Göster");
define("LAN_LOGINMENU_39", "Yöneticiden Ayrıl");
define("LAN_LOGINMENU_40", "Aktivasyon mailini yeniden gönder");
define("LAN_LOGINMENU_41", "Giriş Menüsü Ayarları");
define("LAN_LOGINMENU_37", "Göster");
define("LAN_LOGINMENU_38", "Giriş menüsü - Ek Bağlantılar");
define("LAN_LOGINMENU_42", "Oturum açma menüsü - Son temel eklemeler");
define("LAN_LOGINMENU_43", "Konum");
define("LAN_LOGINMENU_44", "eksik bağlantı başlığı");
define("LAN_LOGINMENU_45", "bağlantı(lar) -");
define("LAN_LOGINMENU_45a", "-");
define("LAN_LOGINMENU_45b", "eklenti");
define("LAN_LOGINMENU_46", "son öğeler -");
define("LAN_LOGINMENU_47", "Oturum açma menüsü - Son eklenti eklemeleri");
define("LAN_LOGINMENU_48", "Menü Yapılandırması");
define("LAN_LOGINMENU_49", "E-mail:");
define("LAN_LOGINMENU_50", "Kullanıcı adı ya da E-mail:");
define("LAN_LOGINMENU_51", "Giriş yap");
