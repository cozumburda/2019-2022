<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_userinfo.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
|	 		$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Gönderenin IP adresi bulunamıyor - mümkün bilgi yok.");
define("USFLAN_3", "Mesajlar şu IP adresinden gönderildi");
define("USFLAN_4", "Sunucu");
define("USFLAN_5", "Ip adreslerini Yönetici Yasak listesine taşımak için tıkla");
define("USFLAN_6", "Kullanıcı ID");
define("USFLAN_7", "Kullanıcı Bilgisi");


?>