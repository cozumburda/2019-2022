<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_notify.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/05/29 18:19:25 $
|     $Author: sweetas $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("NA_LAN_1", "Yönetici parolasını günceller");
define("NA_LAN_2", "Yönetici yeni bir kullanıcı oluşturur");
define("NA_LAN_3", "Yönetici yeni bir kullanıcıyı etkinleştirir");
define("NT_LAN_1", "Bildiri");
define("NT_LAN_2", "Eposta uyarısı alma açık");
define("NU_LAN_1", "Kullanıcı Etkinlikleri");
define("NU_LAN_2", "Kullanıcı Girişi");
define("NU_LAN_3", "Kullanıcı Hesap Doğrulama");
define("NU_LAN_4", "Kullanıcı Girişi");
define("NU_LAN_5", "Kullanıcı Çıkışı");
define("NU_LAN_6", "Kullanıcı sosyal oturum açma");
define("NU_LAN_7", "Kullanıcı sosyal kayıt");
define("NU_LAN_8", "Kullanıcı Profili Görüntüler");
define("NU_LAN_9", "Kullanıcı profili düzenler");
define("NS_LAN_1", "Güvenlik Etkinlikleri");
define("NS_LAN_2", "Siteye Flood yapıldığı için IP yasaklandı");
define("NS_LAN_3", "Birden çok başarısız oturum açma girişimi nedeniyle yasaklı IP");
define("NN_LAN_1", "Haber Etkinlikleri");
define("NN_LAN_2", "Kullanıcı tarafından gönderilen haber öğeleri");
define("NN_LAN_3", "Yönetici tarafından gönderilen haber öğeleri");
define("NN_LAN_4", "Yönetici tarafından düzenlenen haber öğeleri");
define("NN_LAN_5", "Yönetici tarafından silinen haber öğeleri");
define("NN_LAN_6", "Haber bildirimi tetiklendi");
define("NM_LAN_1", "Posta Etkinlikleri");
define("NM_LAN_2", "Toplu e-posta gönderimi tamamlandı");
define("NM_LAN_3", "E-posta adresi =>");
define("NF_LAN_1", "Dosya Etkinlikleri");
define("NF_LAN_2", "Kullanıcı tarafından yüklenen dosya");
define("LAN_NOTIFY_01", "Etkinlikler");
