<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_theme.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/03/15 12:09:30 $
|     $Author: stevedunstan $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("TPVLAN_1", "<b>{PREVIEWTHEMENAME}</b> temasının önizlemesine bakıyorsunuz. Siteniz için ana tema olarak ayarlanmadı, temanın nasıl göründüğüne dair bir önizleme sağlamak için etkinleştirildi.<br />Bu temayı site temanız olarak ayarlamak için <a href='{e_ADMIN}theme.php?choose'>tema yöneticinize dönün</a> ve 'Site Teması Olarak Ayarla'yı seçin.<br />Daha fazla temayı önizlemek için lütfen <a href='{e_ADMIN}theme.php'>burayı tıklayın</a>");
define("TPVLAN_2", "Tema Önizlemesi");
define("TPVLAN_3", "Site teması değişti.");
define("TPVLAN_5", "Web Sitesi");
define("TPVLAN_6", "Çıkış Tarihi");
define("TPVLAN_7", "Bilgi");
define("TPVLAN_9", "Temayı Önizle");
define("TPVLAN_10", "Site Teması Olarak Ayarla");
define("TPVLAN_11", "Sürüm");
define("TPVLAN_12", "Önizleme mevcut değil");
define("TPVLAN_13", "Tema Yükle (.zip yada .tar.gz biçiminde)");
define("TPVLAN_14", "Tema Yükle");
define("TPVLAN_15", "Dosya '.e_THEME.' olarak yüklenemedi. klasör doğru izinlere sahip değil - lütfen CHMOD'u 777'ye getirin ve dosyayı yeniden yükleyin.");
define("TPVLAN_16", "Yönetici Mesajı");
define("TPVLAN_17", "Bu dosya geçerli bir .zip veya .tar arşivi gibi görünmüyor.");
define("TPVLAN_18", "Bir hata oluştu, dosya arşivden çıkarılamıyor");
define("TPVLAN_19", "Temanız yüklendi ve açıldı.");
define("TPVLAN_20", "Temalar klasörünüz doğru izinlere sahip olmadığından otomatik tema yükleme ve çıkarma devre dışı bırakıldı - lütfen e107_themes klasörünüzün CHMOD'unu 777'ye getirin.");
define("TPVLAN_21", "Bu, şu anda seçili olan site temasıdır");
define("TPVLAN_22", "Stil sayfaları");
define("TPVLAN_23", "varsayılan Stil sayfaları");
define("TPVLAN_24", "bilgi yok");
define("TPVLAN_26", "Tema Yöneticisi");
define("TPVLAN_27", "Lütfen kullanılacak Stil sayfalarını seçin");
define("TPVLAN_28", "açık");
define("TPVLAN_29", "kapalı");
define("TPVLAN_30", "Tema Resimlerini Önceden Yükle:");
define("TPVLAN_31", "Bu şu an seçilmiş olan yönetici teması");
define("TPVLAN_32", "Yönetici Teması olarak ayarla");
define("TPVLAN_33", "Site Teması");
define("TPVLAN_34", "Yönetici Teması");
define("TPVLAN_35", "Seçenekleri Kaydet");
define("TPVLAN_36", "Yönetici Mesajı");
define("TPVLAN_37", "Tema Seçenekleri Kaydedildi");
define("TPVLAN_38", "Tema Yükle");
define("TPVLAN_39", "Kullanılabilen Temalar");
define("TPVLAN_40", "Yönetici Temasını şuna ayarla:");
define("TPVLAN_41", "Lütfen kullanılacak yönetici düzeni stilini seçin");
define("TPVLAN_42", "Yönetici Seçeneklerini Kaydet");
define("TPVLAN_43", "Yönetici Seçenekleri Kaydedildi");
define("TPVLAN_46", "PCLZIP açma hatası:");
define("TPVLAN_47", "PCLTAR açma hatası:");
define("TPVLAN_48", "kod:");
define("TPVLAN_49", "Uyma");
define("TPVLAN_50", "Düzenler");
define("TPVLAN_51", "Tema Değiştir");
define("TPVLAN_52", "Ad");
define("TPVLAN_53", "Önerilen eklentiler");
define("TPVLAN_54", "Menü Ön Ayarları");
define("TPVLAN_55", "Varsayılan");
define("TPVLAN_56", "Görünürlük filtresi");
define("TPVLAN_57", "Uyumluluk");
define("TPVLAN_58", "Bu tema, web sitenizde kullanılabilecek önceden yüklenmiş örnek içerikle (sayfalar ve menüler gibi) gelir.");
define("TPVLAN_59", "Lütfen örnek içeriğin aşağıdaki mevcut içeriğinizin [b]üzerine yazılacağını[/b] unutmayın");
define("TPVLAN_60", "[y] tablonuzdaki [x] kayıt(lar)");
define("TPVLAN_61", "Mevcut içeriğinizi tema tarafından sağlanan varsayılan örnek içerikle [b]değiştirmek[/b] ister misiniz?");
define("TPVLAN_62", "Tema bul");
define("TPVLAN_63", "Dönüştür");
define("TPVLAN_64", "Bu Sihirbaz, temanız için bir theme.xml meta dosyası oluşturacaktır.");
define("TPVLAN_65", "Başlamadan önce:");
define("TPVLAN_66", "Temanızın dizininin yazılabilir olduğundan emin olun");
define("TPVLAN_67", "Başlamak için temanızın klasörünü seçin.");
define("TPVLAN_68", "Temanızın klasörünü seçin");
define("TPVLAN_69", "İndirilebilir");
define("TPVLAN_70", "Önizleme/Canlı demo :");
define("TPVLAN_71", "Belirtilmemiş");
define("TPVLAN_72", "Bu düzeni otomatik olarak kullanması gereken sayfaları ayarlayın. Her satıra bir tane.");
define("TPVLAN_73", "Menüleri Etkinleştir");
define("TPVLAN_74", "Belirtileni Etkinleştir:");
define("TPVLAN_75", "Fiyat");
define("TPVLAN_76", "Ücretsiz");
define("TPVLAN_77", "Tavsiye Edilen!");
define("TPVLAN_78", "Gereksinimler");
define("TPVLAN_79", "Bu özelliği kullanmak için şu anda cURL gereklidir. cURL'yi etkinleştirmek için web sağlayıcınızla iletişime geçin");
define("TPVLAN_80", "Arama kriterlerinize uyan Tema bulunamadı");
define("TPVLAN_CONV_1", "Adım 1");
define("TPVLAN_CONV_2", "Adım 2");
define("TPVLAN_CONV_3", "Temanızın adı. (İngilizce yazılmalıdır)");
define("TPVLAN_CONV_4", "Bir dil dosyanız varsa, temanın adı için LAN_XXX değerini girin.");
define("TPVLAN_CONV_5", "Temanızın sürümü. Biçim: x.x");
define("TPVLAN_CONV_6", "Temanızı oluşturma tarihi");
define("TPVLAN_CONV_7", "e107'nin bu sürümüyle uyumlu");
define("TPVLAN_CONV_8", "Yazar adı");
define("TPVLAN_CONV_9", "Yazarın Web sitesi Url'si");
define("TPVLAN_CONV_10", "Eklentinin tek satırlık kısa açıklaması. (!@#$%^&* karakterlerine izin verilmez)(İngilizce yazılmalıdır)");
define("TPVLAN_CONV_11", "Bu tema için Anahtar Kelime/Etiket (İngilizce yazılmalıdır)");
define("TPVLAN_CONV_12", "Temanın tam açıklaması (İngilizce yazılmalıdır)");
define("TPVLAN_CONV_13", "Bu temanın kategorisi nedir?");
define("TPVLAN_CONV_14", "Bu stil sayfasını Tema Yöneticisi'nde seçilebilir bir seçenek olarak etkinleştirin.");
define("TPVLAN_CONV_15", "Bu stil sayfasına bir ad verin");
define("TPVLAN_CONV_16", "Bu temanın demosunun URL'si.");
define("TPVLAN_83", "Otomatik yükleme mümkün değil!");
define("TPVLAN_84", "Lütfen Manuel Olarak İndirin [Please Download Manually]");
define("TPVLAN_85", "Bağlanıyor...");
define("TPVLAN_86", "Site teması değiştirilemedi.");
define("TPVLAN_88", "Dönüştürücü");
define("TPVLAN_89", "Pano tercihlerini tüm yöneticilere uygula");
define("TPVLAN_91", "Şunu temel alarak yeni bir tema oluşturun:");
define("TPVLAN_92", "Yeni Tema Klasörü");
define("TPVLAN_93", "Seçim");
define("TPVLAN_94", "Site teması [x] olarak değiştirildi.");
define("TPVLAN_95", "Kaplama");
define("TPVLAN_96", "Bu düzeni otomatik olarak kullanması gereken URL'leri/script yollarını ayarlayın. Her satıra bir tane.");
define("TPVLANHELP_01", "Tema yöneticisi, sitenizin genel temasını ve yönetici alanlarınızın temasını belirlemenizi sağlar.");
define("TPVLANHELP_02", "Daha fazla ayrıntı için araç ipuçlarına (varsa) bakın.");
define("TPVLANHELP_03", "Varsayılan olarak, görünürlük filtresi, kısmi bir URL eşleşmesine göre temanın düzenini değiştirir.");
define("TPVLANHELP_04", "URL'nin sonuyla tam olarak eşleşmesi için satırları bir [b]![/b] ile bitirin.");
define("TPVLANHELP_05", "Kod yolunun sonuyla tam olarak eşleşmesi için satırları bir [b]$[/b] ile bitirin.");
define("TPVLANHELP_06", "e107::route() ile kısmen veya tamamen eşleştirmek için satırları [b]:[/b] ile başlatın");
define("TPVLAN_97", "Bu tema, e107'nin daha yeni bir sürümünü gerektirir.");
