<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_ugflag.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:55 $
|     $Author: e107coders $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("UGFLAN_2", "Bakım bayrağını etkinleştir");
define("UGFLAN_4", "Bakım Ayarları");
define("UGFLAN_5", "Site kapalı olduğunda gösterilecek metin");
define("UGFLAN_6", "Varsayılan mesajın gösterilmesi için boş bırakın");
define("UGFLAN_8", "Erişimi yalnızca Yöneticilerle sınırlandırın");
define("UGFLAN_9", "Erişimi yalnızca Ana Yöneticilerle sınırlandırın");
