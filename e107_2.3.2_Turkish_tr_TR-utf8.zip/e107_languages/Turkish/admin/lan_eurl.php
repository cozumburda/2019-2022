<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/07/25 12:15:52
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("LAN_EURL_NAME", "Site URL'lerini Yönet");
define("LAN_EURL_NAME_CONFIG", "Profiller");
define("LAN_EURL_NAME_ALIASES", "Takma İsimler");
define("LAN_EURL_NAME_SETTINGS", "Genel Ayarlar");
define("LAN_EURL_NAME_HELP", "Yardım");
define("LAN_EURL_EMPTY", "Bu Liste boş");
define("LAN_EURL_LEGEND_CONFIG", "Her site alanı için URL profili seçin");
define("LAN_EURL_LEGEND_ALIASES", "Her URL profili için Temel URL takma adlarını ayarla");
define("LAN_EURL_DEFAULT", "Varsayılan");
define("LAN_EURL_PROFILE", "Profil");
define("LAN_EURL_INFOALT", "Bilgi");
define("LAN_EURL_PROFILE_INFO", "Profil bilgisi etkin değil");
define("LAN_EURL_LOCATION", "Profil Konumu");
define("LAN_EURL_LOCATION_NONE", "Ayar Dosyası etkin değil");
define("LAN_EURL_FORM_HELP_DEFAULT", "Varsayılan dilde takma adlar");
define("LAN_EURL_FORM_HELP_ALIAS_0", "Varsayılan değerdir");
define("LAN_EURL_FORM_HELP_ALIAS_1", "Takma Adlar dır");
define("LAN_EURL_FORM_HELP_EXAMPLE", "Temel URL");
define("LAN_EURL_ERR_ALIAS_MODULE", "Takma adlar kaydedilemiyor &quot;%1\$s&quot; - Aynı isimde bir sistem URL profili var. Lütfen sistem URL profiliniz için farklı bir takma isim seçin &quot;%2\$s&quot;");
define("LAN_EURL_SURL_UPD", "&nbsp; SEF URL'leri güncellendi.");
define("LAN_EURL_SURL_NUPD", "&nbsp; SEF URL'leri güncellenmedi.");
define("LAN_EURL_SETTINGS_PATHINFO", "URL'den dosya ismini sil");
define("LAN_EURL_SETTINGS_MAINMODULE", "Ortak Kök İsim alanı");
define("LAN_EURL_SETTINGS_MAINMODULE_HELP", "Temel site URL'niz ile bağlanacak site alanınızı seçin. Örnek: Kök isim alanınızdaki haberler https://yoursite.com/News-Item-Title ortak (aynı zamanda) olarak anasayfa ve haberler altında gösterilecek.");
define("LAN_EURL_SETTINGS_REDIRECT", "Sayfa bulunamadığında sistemi yönlendir.");
define("LAN_EURL_SETTINGS_REDIRECT_HELP", "Yanlış olarak ayarlanırsa, Sayfa bulunamadı işleme alınacak (web tarayıcı yönlendirilmeden)");
define("LAN_EURL_SETTINGS_SEFTRANSLATE", "Otomatik SEF metni oluşturma türü");
define("LAN_EURL_SETTINGS_SEFTRANSLATE_HELP", "SEF metninin otomatik olarak oluşturulmasında nasıl üretileceğini seçin (mesela; haberlerden, özel sayfalardan, vb. bir başlık değeri)");
define("LAN_EURL_SETTINGS_SEFTRTYPE_NONE", "Sadece koru");
define("LAN_EURL_SETTINGS_SEFTRTYPE_DASHL", "Küçük-Harflere-Dönüştür");
define("LAN_EURL_SETTINGS_SEFTRTYPE_DASHC", "İlk-Harfleri-Büyük-Harfe-Dönüştür");
define("LAN_EURL_SETTINGS_SEFTRTYPE_DASH", "Dönüştürme-Yapma");
define("LAN_EURL_SETTINGS_SEFTRTYPE_UNDERSCOREL", "Küçük_Harfleri_Vurgula");
define("LAN_EURL_SETTINGS_SEFTRTYPE_UNDERSCOREC", "İlk_Harfi_Büyük_Harf_olanları_Vurgula");
define("LAN_EURL_SETTINGS_SEFTRTYPE_UNDERSCORE", "Dönüştürme_Yapılmayanları_Vurgula");
define("LAN_EURL_SETTINGS_SEFTRTYPE_PLUSL", "artı+ayraç+den+küçük+harf");
define("LAN_EURL_SETTINGS_SEFTRTYPE_PLUSC", "artı+ayraç+den+ilk+harf+büyük");
define("LAN_EURL_SETTINGS_SEFTRTYPE_PLUS", "artı+ayraç+den+dönüşüm+yapılmadı");
define("LAN_EURL_MODREWR_DESCR", "URL'lerinizden giriş betik dosya ismi silindi (index.php/). Sunucunuzda (Apache Web Server) mod_rewrite 'ın kurulup çalıştırılmasını gerektirir. Bu ayarları etkinleştirdikten sonra sitenizin kök klasörüne gidin htaccess.txt dosyasının ismini .htaccess olarak değiştirin ve gerekli ise <em>&quot;RewriteBase&quot;</em> şeklinde modifiye edin.");
define("LAN_EURL_MENU", "Site URL'leri");
define("LAN_EURL_MENU_CONFIG", "Yapılandırma");
define("LAN_EURL_MENU_ALIASES", "Profil Takma Adları");
define("LAN_EURL_MENU_SETTINGS", "Ayarlar");
define("LAN_EURL_MENU_HELP", "Yardım");
define("LAN_EURL_MENU_PROFILES", "Profiller");
define("LAN_EURL_UC", "Hazırlık Aşamasında / Bakımda");
define("LAN_EURL_CORE_MAIN", "Kök Site İsim Alanı - Takma Adlar Kullanımda Değil");
define("LAN_EURL_FRIENDLY", "Dost");
define("LAN_EURL_LEGACY", "Mevcut direk URL'ler");
define("LAN_EURL_REWRITE_LABEL", "Dost URL'ler");
define("LAN_EURL_REWRITE_DESCR", "Arama motoru ve kullanıcı dostu URL'leri");
define("LAN_EURL_CORE_NEWS", "Haberler");
define("LAN_EURL_NEWS_REWRITEF_LABEL", "Tam Dost URL'ler (Performans dışı ve en yakın)");
define("LAN_EURL_NEWS_REWRITEF_DESCR", "-");
define("LAN_EURL_NEWS_REWRITE_LABEL", "Kimliği olmayan dost URL'ler (Performans dışı ve daha dost)");
define("LAN_EURL_NEWS_REWRITE_DESCR", "El ile bağlantı ayrıştırma ve işlemeyi temsil eder.");
define("LAN_EURL_NEWS_REWRITEX_LABEL", "Kimliği olan dost URL'ler (Akıllı Performans)");
define("LAN_EURL_NEWS_REWRITEX_DESCR", "Ön tanımlı gezinme kuralları kullanılarak otomatik bağlantı ayrıştırma ve işlemeyi temsil eder.");
define("LAN_EURL_CORE_USER", "Kullanıcılar");
define("LAN_EURL_USER_REWRITE_LABEL", "Dost URL'ler");
define("LAN_EURL_USER_REWRITE_DESCR", "Arama motoru ve kullanıcı dostu URL'ler");
define("LAN_EURL_CORE_PAGE", "Özel Sayfalar");
define("LAN_EURL_PAGE_SEF_LABEL", "Kimliği olan dost URL'ler (Performans)");
define("LAN_EURL_PAGE_SEF_DESCR", "Arama motoru ve kullanıcı dostu URL'ler");
define("LAN_EURL_PAGE_SEFNOID_LABEL", "Kimliği olmayan dost URL'ler (Performans dışı ve daha dost)");
define("LAN_EURL_PAGE_SEFNOID_DESCR", "Arama motoru ve kullanıcı dostu URL'ler");
define("LAN_EURL_CORE_SEARCH", "Arama");
define("LAN_EURL_SEARCH_DEFAULT_LABEL", "Varsayılan Arama URL'si");
define("LAN_EURL_SEARCH_DEFAULT_DESCR", "Mevcut direk URL.");
define("LAN_EURL_SEARCH_REWRITE_LABEL", "Dost URL");
define("LAN_EURL_SEARCH_REWRITE_DESCR", "-");
define("LAN_EURL_CORE_SYSTEM", "Sistem");
define("LAN_EURL_SYSTEM_DEFAULT_LABEL", "Varsayılan Sistem URL'si");
define("LAN_EURL_SYSTEM_DEFAULT_DESCR", "Bulunamadı, Erişim engellendi vb. gibi sayfalar için URL'ler");
define("LAN_EURL_SYSTEM_REWRITE_LABEL", "Dost Sistem URL'si");
define("LAN_EURL_SYSTEM_REWRITE_DESCR", "Bulunamadı, Erişim engellendi vb. gibi sayfalar için URL'ler");
define("LAN_EURL_CORE_INDEX", "Giriş Sayfası");
define("LAN_EURL_CORE_INDEX_INFO", "Giriş Sayfasının takma adı olamaz");
define("LAN_EURL_REBUILD", "Tekrar Üret");
define("LAN_EURL_REGULAR_EXPRESSION", "Düzenli İfade");
define("LAN_EURL_KEY", "Anahtar");
define("LAN_EURL_TABLE", "Tablo");
