<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_filemanager.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/06/14 23:35:15 $
|     $Author: e107coders $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("FMLAN_12", "dosya");
define("FMLAN_13", "dosyalar");
define("FMLAN_14", "dizin");
define("FMLAN_15", "dizinler");
define("FMLAN_16", "Kök Dizin");
define("FMLAN_18", "Boyut");
define("FMLAN_19", "Son Değiştirilme");
define("FMLAN_21", "Dosyayı bu dizine yükle");
define("FMLAN_22", "Yükle");
define("FMLAN_29", "Yol");
define("FMLAN_30", "Üst Seviye");
define("FMLAN_31", "Klasör");
define("FMLAN_32", "Dizin Seç");
define("FMLAN_34", "Dizin Seçimi");
define("FMLAN_35", "Dosya Dizini");
define("FMLAN_38", "Dosya başarıyla şu dizine taşındı");
define("FMLAN_39", "Dosya şu dizine taşınamadı:");
define("FMLAN_40", "Haber gönderileri-Resimler Dizini");
define("FMLAN_43", "Seçili Dosyaları Sil");
define("FMLAN_46", "Lütfen seçili dosyaları silmek istediğinizi onaylayın.");
define("FMLAN_47", "Kullanıcı Yüklemeleri");
define("FMLAN_48", "Seçiliyi Olanı Şuraya Taşı");
define("FMLAN_49", "Seçili dosyaların taşınmasını onaylayın.");
define("FMLAN_50", "Taşı");
define("FMLAN_51", "tanımlanamayan hata");
