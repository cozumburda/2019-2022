<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_links.php,v $
|     $Revision: 1.13 $
|     $Date: 2005/11/23 18:08:28 $
|     $Author: mcfly_e107 $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LCLAN_19", "Link Açılış Türü");
define("LCLAN_20", "Aynı Sayfa İçinde");
define("LCLAN_23", "Yeni Pencerede");
define("LCLAN_24", "600x400 mini pencerede");
define("LCLAN_78", "Açıklamayı Ekran İpucu Olarak Göster");
define("LCLAN_79", "Açıklama, fare link üstüne gittiğinde gösterilecektir");
define("LCLAN_80", "Açılan Alt Menüleri Etkinleştir");
define("LCLAN_81", "Alt menüler sadece ana linke tıklandığında gösterilir. (ana link devre dışı ise)");
define("LCLAN_105", "Fonksiyon");
define("LCLAN_106", "Tarafından sahip olunan");
define("LCLAN_107", "Dinamik olarak oluşturulmuş Arama Motoru Dostu bir URL ile URL'yi geçersiz kılmak için etkinleştirir");
define("LCLAN_108", "Bazı seçimler ihmal edildi - Bağlantıyı Alt Bağlantısının Alt Bağlantısı olarak ayarlayamazsınız.");
define("LCLAN_109", "Lütfen bir üst seçin");
define("LCLAN_110", "Lütfen bir oluşturma modülü seçin");
define("LCLAN_111", "Geçerli bir oluşturma modülü değil");
define("LCLAN_112", "1 - Ana");
define("LCLAN_113", "2 - Kenar Çubuğu");
define("LCLAN_114", "3 - Alt Bilgi");
define("LCLAN_115", "Alternatif");
define("LCLAN_116", "(Atanmamış)");
define("LINKLAN_1", "800x600 pencerede aç");
define("LINKLAN_4", "Alt link oluşturucu");
define("LINKLAN_5", "Alt link oluştur");
define("LINKLAN_6", "Şuradan alt linkler oluştur");
define("LINKLAN_7", "alt linkler hangi linkler altında oluşturulsun?");
define("LINKLAN_8", "Haber Kategorileri");
define("LINKLAN_9", "İndirme Kategorileri");
define("LINKLAN_10", "Tema Kısa Kodları");
