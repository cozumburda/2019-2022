<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_db_verify.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/04/02 18:29:48 $
|     $Author: e107coders $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("DBVLAN_1", "Sql veri dosyası okunamıyor<br><br>Lütfen dosya <b>core_sql.php</b> <b>/e107_core/sql</b> Dizinin varolduğundan emin olun.");
define("DBVLAN_4", "Tablo");
define("DBVLAN_5", "Alan");
define("DBVLAN_6", "Durum");
define("DBVLAN_7", "Notlar");
define("DBVLAN_8", "Uyuşmazlık");
define("DBVLAN_9", "Şu anda");
define("DBVLAN_10", "olmalı");
define("DBVLAN_11", "Alan eksik!");
define("DBVLAN_12", "Fazladan alan!");
define("DBVLAN_13", "Tablo eksik!");
define("DBVLAN_14", "Doğrulamak için tabloları seçin");
define("DBVLAN_15", "Doğrulamayı Başlat");
define("DBVLAN_16", "SQL doğrulaması");
define("DBVLAN_19", "Düzeltme girişimi");
define("DBVLAN_21", "Seçili öğeleri düzelt");
define("DBVLAN_22", "[x] okunabilir değil");
define("DBVLAN_23", "Veritabanı yardımcı uygulamaları");
define("DBVLAN_24", "Lütfen eylem seçin.");
define("DBVLAN_25", "Dizin eksik!");
define("DBVLAN_26", "[x] tablo(lar) sorunlu.");
