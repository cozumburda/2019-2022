<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_message.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/08 21:33:07 $
|     $Author: stevedunstan $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Alınan Mesajlar");
define("MESSLAN_2", "Mesajı Sil");
define("MESSLAN_3", "Mesaj Silindi.");
define("MESSLAN_4", "Tüm Mesajları Sil");
define("MESSLAN_5", "Doğrula");
define("MESSLAN_6", "Tüm Mesajlar Silindi.");
define("MESSLAN_7", "Mesaj Yok.");
define("MESSLAN_8", "Mesaj Tipi");
define("MESSLAN_9", "Repor tarihi");
define("MESSLAN_10", "Gönderen:");
define("MESSLAN_11", "Yeni Pencerede Aç");
define("MESSLAN_12", "Mesaj");
define("MESSLAN_13", "Bağlantı");


