<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/07/25 17:45:39
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("LAN_VALIDATE_0", "Bilinmeyen hata");
define("LAN_VALIDATE_101", "Eksik değer");
define("LAN_VALIDATE_102", "Beklenmeyen değer türü");
define("LAN_VALIDATE_103", "Geçersiz karakterler bulundu");
define("LAN_VALIDATE_104", "Geçerli olmayan e-posta adresi");
define("LAN_VALIDATE_105", "Alanlar uyuşmuyor");
define("LAN_VALIDATE_131", "Dize çok kısa");
define("LAN_VALIDATE_132", "Dize çok uzun");
define("LAN_VALIDATE_133", "Sayı çok düşük");
define("LAN_VALIDATE_134", "Sayı çok yüksek");
define("LAN_VALIDATE_135", "Dizi sayısı çok düşük");
define("LAN_VALIDATE_136", "Dizi sayısı çok yüksek");
define("LAN_VALIDATE_151", "Sayının türü tamsayı olmalı");
define("LAN_VALIDATE_152", "Sayının türü ondalıklı olmalı");
define("LAN_VALIDATE_153", "Beklenen örnek türü");
define("LAN_VALIDATE_154", "Dizi olmalı");
define("LAN_VALIDATE_191", "Boş değer");
define("LAN_VALIDATE_201", "Dosya mevcut değil");
define("LAN_VALIDATE_202", "Dosya yazılabilir değil");
define("LAN_VALIDATE_203", "Dosya, izin verilen dosya boyutunu aşıyor");
define("LAN_VALIDATE_204", "Dosya boyutu, izin verilen minimum dosya boyutundan daha düşük");
define("LAN_VALIDATE_FAILMSG", "[x] doğrulama hatası: [y] [z].");
