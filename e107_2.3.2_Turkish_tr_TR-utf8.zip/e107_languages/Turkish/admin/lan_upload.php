<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_upload.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/12/21 17:03:51 $
|     $Author: sweetas $
|	 		$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("UPLLAN_1", "Yükleme listeden kaldırıldı.");
define("UPLLAN_2", "Ayarlar veritabanına kaydedildi");
define("UPLLAN_4", "Hiçbir şey değişmedi - güncelleştirilmedi");
define("UPLLAN_5", "Gönderen");
define("UPLLAN_7", "Web Sitesi");
define("UPLLAN_14", "-Demo-");
define("UPLLAN_16", "haber gönderisine kopyala");
define("UPLLAN_17", "listeden yüklemeyi kaldır");
define("UPLLAN_18", "detayları gör");
define("UPLLAN_19", "Denetlenmemiş genel yükleme yok");
define("UPLLAN_20", "Orada");
define("UPLLAN_21", "denetlenmemiş genel yükleme");
define("UPLLAN_24", "Dosya Tipi");
define("UPLLAN_25", "Dosya Yüklemelerine İzin Ver");
define("UPLLAN_26", "Devre dışı bırakılırsa herkese açık yüklemelere izin verilmez");
define("UPLLAN_27", "denetlenmemiş genel yüklemeler");
define("UPLLAN_33", "Maksimum Dosya Boyutu");
define("UPLLAN_34", "Bayt cinsinden mutlak maksimum yükleme boyutu. php.ini'deki ayarlarla ve filetypes.xml'deki ayarlarla da sınırlıdır");
define("UPLLAN_37", "İzin");
define("UPLLAN_38", "Yalnızca belirli kullanıcıların yüklemesine izin vermek için seçin");
define("UPLLAN_41", "Lütfen unutmayın - php.ini'nizden dosya yükleme devre dışıdır, siz Açık olarak ayarlayana kadar dosya yüklemek mümkün olmayacaktır.");
define("UPLLAN_45", "Aşağıdaki dosyayı silmek istediğinizden emin misiniz...");
define("UPLAN_COPYTODLM", "indirme yöneticisine kopyala");
define("UPLAN_IS", "dir");
define("UPLAN_ARE", "dirler");
define("UPLAN_COPYTODLS", "İndirilenlere Kopyala");
define("UPLLAN_51", "Yüklemeleri Listele");
define("UPLLAN_52", "Bu sayfa, dosya yükleme izinlerini yönetmek için bir dosya oluşturmanıza yardımcı olur. Dosya [x] olarak kaydedilir ve etkili olabilmesi için [y]'ye kopyalanması gerekir.");
define("UPLLAN_54", "Dosya uzantıları");
define("UPLLAN_55", "Maksimum yükleme boyutu");
define("UPLLAN_56", "Dosya Oluştur");
define("UPLLAN_57", "Değerler için kaynak:");
define("UPLLAN_59", "Yazılan ayarlar");
define("UPLLAN_60", "Şimdi bu dosyayı şuraya taşı:");
define("UPLLAN_61", "Dosya yazılırken hata oluştu:");
define("UPLLAN_62", "İndirme eklentisi kurulu değil - etkinleştirme mümkün değil.");
define("UPLLAN_63", "Kayıt, İndirilenler'e taşındı. [x]");
define("UPLLAN_64", "İndirmeyi Yönet");
define("UPLLAN_66", "İndirme yolu hatası");
define("UPLLAN_68", "SQL hatası:");
define("UPLLAN_69", "İçe Alındı");
define("UPLLAN_70", "[x]'e gönder");
