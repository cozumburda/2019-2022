<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_header.php,v $
|     $Revision: 1.3 $
|     $Date: 2004/10/25 16:11:40 $
|     $Author: loloirie $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LAN_HEADER_01", "Yönetici Navigasyonu");
define("LAN_HEADER_02", "Sunucunuz HTTP dosya yüklemelerine izin vermiyor, bu nedenle kullanıcılarınız avatarları/dosyaları vb. yükleyemez. Bunu düzeltmek için php.ini dosyanızda file_uploads öğesini Açık olarak ayarlayın ve sunucunuzu yeniden başlatın. Eğer php.ini dosyanıza erişiminiz yoksa sunucu firmanız ile görüşün.");
define("LAN_HEADER_03", "Sunucunuz, geçerli bir dosya okuma kısıtlaması ile çalışıyor. Bu, ana dizininizin dışında herhangi bir dosyanın kullanılmasına izin vermez ve bu nedenle, dosya yöneticisi gibi belirli komut dosyaları çalışmayabilir.");
define("LAN_HEADER_04", "Yönetici alanı");
define("LAN_HEADER_05", "yönetici alanında görüntülenen dil");
define("LAN_HEADER_06", "Eklenti bilgisi");
