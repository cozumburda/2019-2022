<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_e107_update.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/11/21 16:15:28 $
|     $Author: sweetas $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "Eylem");
define("LAN_UPDATE_3", "Gerekli değil");
define("LAN_UPDATE_4", "[x]'ten [y]'yi Güncelle");
define("LAN_UPDATE_5", "Çekirdek veritabanı yapısını Güncelle");
define("LAN_UPDATE_7", "[x] Çalıştırıldı");
define("LAN_UPDATE_12", "Tablolarınızdan biri mükerrer girdiler içeriyor.");
define("LAN_UPDATE_13", "Yeni Ekle veya eksik çekirdek ayarları");
define("LAN_UPDATE_14", "Başlangıç sürümü:");
define("LAN_UPDATE_20", "Tercihler güncelleştiriliyor:");
define("LAN_UPDATE_21", "Tablo yapısı güncelleştiriliyor:");
define("LAN_UPDATE_22", "Tercihler dizi olarak dönüştürülüyor:");
define("LAN_UPDATE_23", "Menü yolu güncelleştiriliyor:");
define("LAN_UPDATE_24", "Kaldırılan tablo alanını sil:");
define("LAN_UPDATE_25", "Eski tablo sil:");
define("LAN_UPDATE_26", "IP adres alanı genişletme:");
define("LAN_UPDATE_27", "Tablo ekleme:");
define("LAN_UPDATE_28", "[x] kaydedilen e-postalar taşındı.");
define("LAN_UPDATE_29", "Yapılandırmanıza bağlı olarak, yükseltme işlemini birkaç kez çalıştırmanız gerekebilir.");
define("LAN_UPDATE_37", "[y] tablosuna [x] indeksini ekle");
define("LAN_UPDATE_38", "Giriş sayfası ayarlarını güncelleştir");
define("LAN_UPDATE_40", "Haber kaynakları tablosunu güncelleştir");
define("LAN_UPDATE_41", "Kullanıcı zaman dilimi alanı işleniyor");
define("LAN_UPDATE_42", "Kullanıcı zaman dilimi verisi aktarma hatası - iptal edildi");
define("LAN_UPDATE_43", "DBLog tablosunu yeniden adlandır");
define("LAN_UPDATE_44", "Çalışan günlük tabloyu yeniden adlandır");
define("LAN_UPDATE_45", "Veritabanına Yeni Tablo Ekleme:");
define("LAN_UPDATE_46", "Tablo tanımı okunurken hata oluştu:");
define("LAN_UPDATE_50", "Eski tercihler silindi:");
define("LAN_UPDATE_51", "Eklenti tablo tanımını güncelleştir:");
define("LAN_UPDATE_52", " İndirilenler Tablosunu güncelle");
define("LAN_UPDATE_53", "Farklı kaynaktan İndirilen Tabloyu güncelle");
define("LAN_UPDATE_54", "[y] tablosu eksik  - [x] indeksi eklenemez");
define("LAN_UPDATE_55", "Tanımlama");
define("LAN_UPDATE_56", "Sistem Güncelleştirmesi");
define("LAN_UPDATE_57", "Devam etmeden önce, lütfen zamanı geçmiş olarak görünen klasörleri sisteminizden el ile silin:");
define("LAN_UPDATE_CAPTION_PLUGIN", "Eklenti güncelleştirmeleri");
define("LAN_UPDATE_CAPTION_CORE", "Çekirdek güncellemeleri");
define("LAN_UPDATE_58", "Tüm güncellemeler tamamlandıktan sonra kullanılmayan silinmesi gerekli dosyaları tespit etmek için [File Inspector] 'ü çalıştırmanız kuvvetle önerilir.");
