<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_db.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/24 16:29:02 $
|     $Author: streaky $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Çekirdek ayarları veritabanında yedeklendi.");
define("DBLAN_4", "e107 veritabanınızın geçerliliğini kontrol etmek için burayı seçin");
define("DBLAN_5", "Veritabanı geçerliliğini kontrol et");
define("DBLAN_6", "e107 veritabanınızı optimize etmek için burayı seçin");
define("DBLAN_7", "SQL veritabanını optimize et");
define("DBLAN_8", "Çekirdek ayarlarınızı yedeklemek için buraya tıklayın");
define("DBLAN_9", "Çekirdeği Yedekle");
define("DBLAN_10", "Veritabanı Yardımcı Uygulamaları");
define("DBLAN_11", "MySQL veritabanı [x] optimize edildi");
define("DBLAN_15", "Herhangi bir veritabanı güncellemesini kontrol etmek için buraya tıklayın");
define("DBLAN_16", "Güncellemeleri Kontrol Et");
define("DBLAN_17", "Tercih Adı");
define("DBLAN_18", "Tercih Değeri");
define("DBLAN_19", "Tercih düzenleyicisini açmak için seçin (yalnızca ileri düzey kullanıcılar için)");
define("DBLAN_20", "Tercih Düzenleyicisi");
define("DBLAN_22", "Eklenti Görüntüleme ve Tarama");
define("DBLAN_23", "Tarama Tamamlandı");
define("DBLAN_25", "Dizin");
define("DBLAN_26", "Dahil edilen eklentiler");
define("DBLAN_27", "Kurulu");
define("DBLAN_28", "Eklenti dizinindeki değişiklikleri taramak için seçin");
define("DBLAN_29", "Eklenti dizinlerini tara");
define("DBLAN_30", "Eklenti bir hata gösteriyorsa, PHP açılış/kapanış etiketlerinin dışındaki karakterleri kontrol edin.");
define("DBLAN_31", "Geçti");
define("DBLAN_33", "Erişilemez");
define("DBLAN_34", "Seçilmedi");
define("DBLAN_35", "e107 veritabanı kayıtlarının geçerliliğini kontrol etmek için seçin");
define("DBLAN_36", "Veritabanı kaydının geçerliliğini kontrol edin");
define("DBLAN_37", "Doğrulamak için tablo(ları) seçin");
define("DBLAN_38", "Doğrulamayı Başlat");
define("DBLAN_39", "Veritabanı kayıt doğrulaması");
define("DBLAN_40", "Kayıt Doğrulama :");
define("DBLAN_41", "Tablo");
define("DBLAN_43", "Açıklama");
define("DBLAN_45", "Kimlik Bulunamadı!");
define("DBLAN_46", "Tablo bulunamadı!");
define("DBLAN_49", "Tabloda kayıt yok, dolayısıyla doğrulanacak bir şey yok");
define("DBLAN_50", "SQL Kayıt doğrulama");
define("DBLAN_51", "Seçileni Yürüt");
define("DBLAN_52", "Yinelenenleri sil");
define("DBLAN_53", "Lütfen eylem seçin.");
define("DBLAN_54", "Doğrulama hatası bulunamadı.");
define("DBLAN_55", "Kısa kodu taramak/yeni kısa kodların dizinini göz ardı etmek için seçin");
define("DBLAN_56", "Göz ardı edilmiş dizini tara");
define("DBLAN_57", "Kısa Kod göz ardı etme listesi şu şekilde ayarlandı:");
define("DBLAN_58", "Site verilerini dışa aktar");
define("DBLAN_59", "Site verilerini içe aktar");
define("DBLAN_60", "Dosya yedekleme tamamlandı!");
define("DBLAN_61", "Veritabanı yedekleme başlatılıyor...");
define("DBLAN_62", "Veritabanı yedekleme tamamlandı!");
define("DBLAN_63", "Tam site yedekleme tamamlandı.");
define("DBLAN_64", "Veritabanı Karakter Kümesini kontrol et");
define("DBLAN_65", "Karakter Kümesini Kontrol Et");
define("DBLAN_66", "Dosya ve Dizin izinlerini Doğrula");
define("DBLAN_67", "İzinleri Doğrula");
define("DBLAN_68", "Veritabanı, dosya ve klasörleri yedekle");
define("DBLAN_69", "Siteyi Yedekle");
define("DBLAN_70", "Bu, bir veritabanı dökümü ve temel olmayan tüm eklentilerin, site temanızın, medya dosyalarınızın ve sistem günlüklerinizin sıkıştırılmış bir yedeğini oluşturacaktır.");
define("DBLAN_71", "Lütfen bekleyin...");
define("DBLAN_72", "Klasör ve dosya izinleri güncellendi");
define("DBLAN_73", "Dosya ve dizin izinleri düzeltiliyor");
define("DBLAN_74", "Sunucuya bağlanıyor");
define("DBLAN_75", "Veritabanı oluştur");
define("DBLAN_76", "Veritabanı seç");
define("DBLAN_77", "Çekirdek sql dosyası okunamıyor");
define("DBLAN_78", "Tablo");
define("DBLAN_79", "Motor");
define("DBLAN_80", "Harmanlama");
define("DBLAN_81", "Durum");
define("DBLAN_82", "Bu işlev, veritabanınızdaki tüm tabloları kalıcı olarak değiştirecektir. ([database])");
define("DBLAN_83", "Önce veritabanınızı yedeklemeniz ve sitenizi bakım moduna geçirmeniz [b]KESİNLİKLE[/b] önerilir.");
define("DBLAN_84", "Lütfen not edin:");
define("DBLAN_85", "Dönüştürme işlemi, veritabanınızın boyutuna bağlı olarak bir dakika veya daha uzun sürebilir.");
define("DBLAN_86", "Dönüşüm indekslenmiş dizilerde çalışmaz.");
define("DBLAN_87", "Öncelikle yükseltme işleminin tüm adımlarını uyguladığınızdan emin olun.");
define("DBLAN_88", "Çekirdek tercihler, bozulma olasılığı nedeniyle dönüştürme işlemi sırasında göz ardı edilir.");
define("DBLAN_89", "Veritabanını dönüştür");
define("DBLAN_90", "UTF8 olmayan tabloları Dönüştür");
define("DBLAN_91", "Lütfen bekleyin...");
define("DBLAN_92", "Tablolarınızın doğru karakter kümesini kullanmaktadır.");
define("DBLAN_93", "Veritabanı Başarıyla UTF-8'e Dönüştürüldü.");
define("DBLAN_94", "Lütfen e107_config.php dosyanızda aşağıdaki satırın bulunduğundan emin olun:");
define("DBLAN_95", "Dışa aktarma seçenekleri");
define("DBLAN_97", "Tablolar");
define("DBLAN_98", "Satırlar");
define("DBLAN_99", "Tablo verileri:");
define("DBLAN_100", "Yolları ve paket görüntülerini ve xml'yi şuna dönüştürün:");
define("DBLAN_101", "Dışa aktarma dosyası");
define("DBLAN_102", "Dışa aktarma seçenekleri");
define("DBLAN_103", "Eklendi");
define("DBLAN_104", "Ekleme başarısız oldu");
define("DBLAN_105", "Toplu kısa kodlar:");
define("DBLAN_106", "(boş)");
define("DBLAN_107", "[folder] yazılabilir değil");
define("DBLAN_108", "Oluşturuldu:");
define("DBLAN_109", "Kopyalandı:");
define("DBLAN_110", "Kopyalanamadı:");
define("DBLAN_111", "Tabloları iyi görünüyor!");
define("DBLAN_112", "Github ile senkronize et");
define("DBLAN_113", "Dosyaların üzerine yaz");
define("DBLAN_114", " Yalnızca Geliştirici Modu");
define("DBLAN_115", "Github'taki en son dosyaları yerel dosyaların üzerine yazın.");
define("DBLAN_116", "Bu, en son .zip dosyasını github'dan şuraya indirecek:");
define("DBLAN_117", "ve ardından sunucunuzda bulunan mevcut dosyaların üzerine yazarak sıkıştırılmış dosyayı açın. e107_config.php içinde ayarlamış olabileceğiniz tüm özel klasörler dahil edilecektir.");
define("DBLAN_118", ".Zip dosyası indirilemedi");
define("DBLAN_119", "Yedekle");
define("DBLAN_120", "Yedekleme başlatılıyor...");
define("DBLAN_121", "[x] [y]'ye taşınıyor.");
