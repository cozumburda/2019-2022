<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/03 15:57:25 $
|     $Author: mcfly_e107 $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Hatırlatma E-postası gönderilen kişi:");
define("UCSLAN_2", "Güncellenen Ayrıcalıklar");
define("UCSLAN_3", "Sn.");
define("UCSLAN_4", "Ayrıcalıklarınız güncellendi:");
define("UCSLAN_5", "Artık şu bölgelerde gezinme hakkınız mevcut");
define("UCSLAN_6", "Kullanıcı için Sınıf Ayarla");
define("UCSLAN_7", "Sınıfları Ayarla");
define("UCSLAN_8", "Kullanıcıyı Haberdar Et");
define("UCSLAN_9", "Sınıflar Güncellendi.");
define("UCSLAN_10", "Saygılarımızla,");
define("UCSLAN_12", "Sadece ayrıcalıklı üyeler");


?>