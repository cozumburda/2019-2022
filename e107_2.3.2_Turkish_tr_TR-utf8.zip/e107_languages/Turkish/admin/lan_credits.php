<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_credits.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/10 15:40:55 $
|     $Author: stevedunstan $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "e107 Ekibi");
define("CRELAN_1", "Hazırlayanlar");
define("CRELAN_2", "e107 içinde kullanılan 3.parti yazılım ve kaynak listesi burada mevcut. e107 geliştirme grubu bireysel olarak aşağıdaki geliştiricilere kodlarını e107 ile yeniden dağıtmalarını izin verdikleri ve yazılımlarını GPL lisanslama sistemine göre dağıttıkları için teşekkürü borç bilir.");
define("CRELAN_3", "tüm hakları saklıdır");
define("CRELAN_4", "e107 Geliştirme Takımını Göster");
define("CRELAN_5", "Üçüncü parti kodları göster");
define("CRELAN_6", "e107 v0.7 was brought to you by ...");
define("CRELAN_7", "Sürüm");
define("CRELAN_8", "izin verilenler");
define("CRELAN_9", "Lisans");
define("CRELAN_10", "MagpieRSS PHP de XML-tabanlı RSS ayrıştırma işlemini sağlar.");
define("CRELAN_11", "PclZip kütüphaneleri Zip formatlı arşiv dosyaları için (Winzip, PKZIP) sıkıştırma ve açma fonksiyonlarını verir.");
define("CRELAN_12", "PclTar sıkıştırılmış ya da sıkıştırılmamış dizinlerdeki dosyaları listeleme yeteneğine sahiptir. PclTar tarafından oluşturulan bu arşivler çoğu gzip/tar uygulamaları ve Windows Winzip uygulamasıyla okunabilir.");
define("CRELAN_13", "TinyMCE bağımsız web tabanlı Javascript HTML WYSIWYG düzenleyici platformudur ve LGPL altında Moxiecode Systems AB tarafından yayımlanır. Bu düzenleyici HTML YAZI ALANLARINI veya diğer HTML elemanlarını çevirebilen bir düzenleyicidir.");
define("CRELAN_14", "e107 de kullanılan simge");
define("CRELAN_15", "PHP için eposta aktarımının tam şekli");
define("CRELAN_16", "Menü sisteminde kullanılan Jayya teması");
define("CRELAN_17", "Açılır pencereli takvim aracı");
define("CRELAN_18", "PDF desteği");
define("CRELAN_19", "UTF-8 PDF desteği");
define("CRELAN_20", "");
define("CRELAN_21", "Her zaman bize sıkıntı veren..aarr...keyif veren!");
define("CRELAN_22", " 	\"MTVhNjMyZDgxN2QwM2Q3ZTI<br />5ODM2NDU3YWI0ZjM1NGILJT<br />yarrrrrr! wtf samimi!\"");
define("CRELAN_23", "");
define("CRELAN_24", "");
define("CRELAN_25", "");
define("CRELAN_26", "");
define("CRELAN_27", "\"Ne? Çay yok mu?? 0_0\"");
define("CRELAN_28", "");
define("CRELAN_29", "Up and forward!");
define("CRELAN_30", "");


?>