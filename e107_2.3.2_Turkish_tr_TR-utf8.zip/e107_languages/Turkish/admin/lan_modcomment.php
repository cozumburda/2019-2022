<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_modcomment.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/30 14:18:21 $
|     $Author: lisa_ $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Yönetilmiş.");
define("MDCLAN_2", "Bu nesne için yorum yok");
define("MDCLAN_3", "Üye");
define("MDCLAN_4", "Misafir");
define("MDCLAN_5", "Engeli Kaldır");
define("MDCLAN_6", "Engelle");
define("MDCLAN_8", "Yorumları Yönet");
define("MDCLAN_9", "Uyarı! ana yorumları silerek alt yorumları da silmiş olacaksınız!");
define("MDCLAN_10", "seçenekler");
define("MDCLAN_11", "yorum");
define("MDCLAN_12", "yorum");
define("MDCLAN_13", "bloke");
define("MDCLAN_14", "yorumları kilitle");
define("MDCLAN_15", "aç");
define("MDCLAN_16", "kilitlendi");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>