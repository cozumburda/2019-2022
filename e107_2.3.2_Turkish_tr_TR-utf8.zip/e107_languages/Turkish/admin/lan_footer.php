<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_footer.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/11/24 16:29:02 $
|     $Author: streaky $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "-Site-");
define("FOOTLAN_2", "Ana Yönetici");
define("FOOTLAN_3", "Sürüm");
define("FOOTLAN_4", "Mimari");
define("FOOTLAN_5", "Yönetici Teması");
define("FOOTLAN_6", "tarafından");
define("FOOTLAN_7", "Bilgi");
define("FOOTLAN_8", "Tarihi Kur");
define("FOOTLAN_9", "Sunucu");
define("FOOTLAN_10", "Sağlayıcı");
define("FOOTLAN_11", "PHP sürümü");
define("FOOTLAN_12", "-MySQL-");
define("FOOTLAN_13", "Site Bilgisi");
define("FOOTLAN_14", "Belgeleri Göster");
define("FOOTLAN_15", "Belgeleme");
define("FOOTLAN_16", "Veritabanı");
define("FOOTLAN_17", "Karakter seti");
define("FOOTLAN_18", "Site Teması");
define("FOOTLAN_19", "Sunucu Zamanı");
define("FOOTLAN_20", "Güvenlik Düzeyi");
