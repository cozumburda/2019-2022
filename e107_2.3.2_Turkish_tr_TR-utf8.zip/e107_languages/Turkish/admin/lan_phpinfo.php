<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/07/25 17:45:31
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("PHP_LAN_1", "Curl özelliğini etkinleştirdiyseniz, bu özelliği devre dışı bırakmayı düşünmelisiniz.");
define("PHP_LAN_2", "Bu bir güvenlik riskidir ve e107 tarafında gerekli değildir.");
define("PHP_LAN_3", "Bir üretim sunucusunda, tarayıcıda hataların görüntülenmesini devre dışı bırakmak daha iyidir.");
define("PHP_LAN_4", "Bunu devre dışı bırakmak, PHP sürümünüzü tarayıcılardan gizleyecektir.");
define("PHP_LAN_5", "Bu bir güvenlik riskidir ve devre dışı bırakılmalıdır.");
define("PHP_LAN_6", "[b]session.save_path[/b] yazılabilir değil! Bu, sitenizle ilgili büyük sorunlara neden olabilir.");
define("PHP_LAN_7", "Bulunan PHP Yapılandırma Sorunu/Sorunları:");
define("PHP_LAN_8", "[x] eksik ve yüklenmesi gerekiyor.");
