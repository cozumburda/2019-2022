<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_meta.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/09/06 19:34:04 $
|     $Author: e107coders $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("METLAN_00", "Meta ve Özel Etiketler");
define("METLAN_1", "İlave meta etiketler");
define("METLAN_2", "örn. < meta name='revisit-after' content='30 days' />");
define("METLAN_3", "Haber sayfalarında meta-açıklama olarak haber başlığını ve özetini kullanın.");
define("METLAN_4", "Özel etiketler ([x] etiketlerin içinde)");
define("METLAN_5", "Özel etiketler ([x]'ten sonra)");
define("METLAN_6", "Özel etiketler ([x]'ten önce)");
define("METLAN_7", "Buraya girilen herhangi bir meta veri veya özel HTML etiketi (<script> etiketleri veya Google analytics kodu gibi), web sitesinin her sayfasında belirlenen alanlara dahil edilecektir.");
