<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_administrator.php,v $
|     $Revision: 1.12 $
|     $Date: 2005/09/09 20:32:06 $
|     $Author: e107coders $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com)$
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("ADMSLAN_6", "ana site yöneticisidir ve silinemez.");
define("ADMSLAN_13", "Mevcut Yöneticiler");
define("ADMSLAN_16", "Yönetici Adı");
define("ADMSLAN_18", "İzinler");
define("ADMSLAN_21", "Yönetici İzinlerini Düzenle");
define("ADMSLAN_25", "Dosyaları Yükle/Yönet");
define("ADMSLAN_27", "Bağlantı Kategorilerini Gözden Geçir");
define("ADMSLAN_41", "Özel Menü Oluştur/Düzenle");
define("ADMSLAN_42", "Gönderiyi Gözden Geçir");
define("ADMSLAN_52", "Yönetici Güncelle");
define("ADMSLAN_56", "Site Yöneticisi");
define("ADMSLAN_58", "Ana Site Yöneticisi");
define("ADMSLAN_59", "Yönetici Yetkisini Kaldır");
define("ADMSLAN_61", "Yönetici Silindi");
define("ADMSLAN_62", "Eklenti Yönetimi");
define("ADMSLAN_71", "Ayrıcalıkları Görmek için buraya tıklayın");
define("ADMSLAN_72", "Yönetici Kimliği: [x] adı: [y] yeni izinler:");
define("ADMSLAN_73", "Yönetici Kimliği: [x] adı: [y]");
