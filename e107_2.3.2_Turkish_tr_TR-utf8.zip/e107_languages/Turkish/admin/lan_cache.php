<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_cache.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com)$
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Önbellek Sistem Durumu");
define("CACLAN_2", "Önbellek Durumunu Ayarla");
define("CACLAN_3", "Önbellek Yönetimi");
define("CACLAN_5", "Önbelleği Boşalt");
define("CACLAN_6", "Önbellek Boşaltıldı");
define("CACLAN_10", "Önbellek dizini yazılabilir değil. Lütfen bu dizinin CHMOD 0777 olarak ayarlandığından emin olun");
define("CACLAN_11", "İçerik önbelleği");
define("CACLAN_12", "Sistem önbelleği");
define("CACLAN_13", "İçerik önbelleği, sayfada işlenmiş içeriği ifade eder. Bu, sitenizde gördüğünüz tüm içeriği (html) ifade eder.");
define("CACLAN_14", "Sistem önbelleği, sistem yapılandırma bilgilerini içerir. Buna site tercihi, şu anda etkin olan menüler vb. dahildir. Burada hiçbir gerçek içerik yer almayacaktır.");
define("CACLAN_16", "Sistem önbelleğini boşalt");
define("CACLAN_17", "Şu andaki içerikler");
define("CACLAN_18", "dosya");
define("CACLAN_19", "dosyalar");
define("CACLAN_20", "VT yapısı önbelleği");
define("CACLAN_21", "Veritabanı Yapısı önbelleği, çeşitli temel rutinler tarafından ihtiyaç duyulan veritabanı tablolarının yapısı hakkında sistem bilgilerini içerir. Burada hiçbir gerçek içerik bulunmayacaktır.");
define("CACLAN_22", "Küçük resim önbelleği");
define("CACLAN_23", "Küçük resim önbellek dosyaları, ikili görüntü verilerini içerir. Sunucunun çok fazla CPU çalışmasından tasarruf etmek için vardırlar.");
define("CACLAN_24", "VT yapı önbelleğini boşalt");
define("CACLAN_25", "Küçük Resim Önbelleğini Boşalt");
define("CACLAN_26", "Tüm önbelleği boşalt");
define("CACLAN_27", "Tarayıcı önbelleğini boşalt");
define("CACLAN_28", "JS/CSS önbelleği");
define("CACLAN_29", "Javascript dosyalarını ve CSS sayfasının dosyalarını birleştirin ve önbelleğe alın.");
define("CACLAN_30", "JS/CSS önbelleği boşalt");
