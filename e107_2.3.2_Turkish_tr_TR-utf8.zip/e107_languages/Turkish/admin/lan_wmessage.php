<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_wmessage.php,v $
|     $Revision: 1.9 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
|	 		$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("WMLAN_00", "Karşılama Mesajları");
define("WMLAN_05", "Ekle");
define("WMLAN_06", "Seçiliyse, mesaj kutu içinde gösterilir");
define("WMLAN_07", "kısakodunu {WMESSAGE} kullanmak için standart sistemin üstüne yaz:");
define("WMLAN_11", "Carousel ile kapalı");
define("WMLAN_12", "Karşılama mesajı yardım");
define("WMLAN_13", "Bu sayfa, etkinleştirildiğinde ön sayfanızın üst kısmında her zaman görünecek bir mesaj ayarlamanıza olanak tanır. Misafirler, kayıtlı/oturum açmış üyeler ve yöneticiler için farklı bir mesaj belirleyebilirsiniz.");
