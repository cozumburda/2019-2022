<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_userclass2.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("UCSLAN_30", "Seçicilerde görüntülenen kısa ad");
define("UCSLAN_31", "Sınıfın uygulanabilirliği hakkında bilgi");
define("UCSLAN_32", "Bu sınıftaki kullanıcılar, düzenledikleri sınıfa kendilerini ekleyebilir/çıkarabilir");
define("UCSLAN_33", "Açılır listelerde bu sınıfı hangi kullanıcıların görebileceğini belirler");
define("UCSLAN_36", "Ağacın tepesi 'Kimse' ise, izinler ağacın tepesine doğru artar<br />Ağacın tepesi 'Herkes' ise, ağaçtan aşağı inildikçe izinler artar");
define("UCSLAN_37", "Sınıf için bir ad girmelisiniz");
define("UCSLAN_38", "İlk kullanıcı sınıfı");
define("UCSLAN_39", "Ayarlanabilecek sınıf yok");
define("UCSLAN_40", "İlk sınıfları ayarla");
define("UCSLAN_41", "Ayarlar güncellendi");
define("UCSLAN_43", "Mevcut sınıflar:");
define("UCSLAN_45", "Sınıfların ayarlandığı nokta:");
define("UCSLAN_46", "(doğrulama yoksa dikkate alınmaz)");
define("UCSLAN_47", "İlk Kayıt");
define("UCSLAN_48", "E-posta veya yönetici tarafından doğrulama");
define("UCSLAN_49", "Bu sınıflar, yeni kaydolan herhangi bir kullanıcı için, hemen veya site üyelikleri doğrulandıktan sonra ayarlanır");
define("UCSLAN_53", "Dikkat! Bu seçenekleri yalnızca destek tarafından talep edildiğinde kullanın.");
define("UCSLAN_54", "Varsayılan bir kullanıcı hiyerarşisi belirleyin");
define("UCSLAN_55", "Kullanıcı hiyerarşisini temizle");
define("UCSLAN_56", "(bu, 'tekdüze' bir kullanıcı sınıfı yapısı oluşturur)");
define("UCSLAN_57", "(hiyerarşi daha sonra değiştirilebilir)");
define("UCSLAN_58", "Yürüt");
define("UCSLAN_62", "Varsayılan sınıf ağacı oluştur:");
define("UCSLAN_63", "Bu sınıf adı zaten var - Lütfen başka bir ad seçin");
define("UCSLAN_64", "tamamlandı");
define("UCSLAN_65", "Kullanıcı sınıfı hiyerarşisini tekdüze yapın:");
define("UCSLAN_69", "Sınıfla ilişkili isteğe bağlı simge - dizin");
define("UCSLAN_70", "Sınıf hiyerarşisini yeniden oluştur:");
define("UCSLAN_71", "Kullanıcı sınıfı bakımı");
define("UCSLAN_72", "Sınıf hiyerarşisi yeniden oluştur");
define("UCSLAN_73", "(Veritabanı bozulması meydana gelirse bu gerekli olabilir)");
define("UCSLAN_74", "Yöneticiler ve Moderatörler");
define("UCSLAN_75", "Kayıtlı ve giriş yapmış üyeler");
define("UCSLAN_76", "Site Yöneticileri");
define("UCSLAN_77", "Ana Site Yöneticileri");
define("UCSLAN_78", "Forumlar ve diğer alanlar için moderatörler");
define("UCSLAN_80", "Standart");
define("UCSLAN_81", "Grup");
define("UCSLAN_82", "Bir grup birkaç bireysel sınıfı bir araya getirir");
define("UCSLAN_83", "Gruptaki sınıflar");
define("UCSLAN_85", "Mevcut tüm sınıfları atadınız; lütfen kullanılmayan birini tekrar atayın");
define("UCSLAN_86", "Yönetici sınıfları için bazı ayarlara izin verilmez - bunlar varsayılan olarak ayarlanmıştır.");
define("UCSLAN_87", "Son katılan kullanıcılar");
define("UCSLAN_88", "Tanımlanmış arama botları");
define("UCSLAN_89", "Kontrol edilen sınıflar grubun üyeleridir");
define("UCSLAN_90", "Belirli sistem kullanıcı sınıflarını düzenleyemezsiniz!");
define("UCSLAN_91", "Sınıf Yapısı");
