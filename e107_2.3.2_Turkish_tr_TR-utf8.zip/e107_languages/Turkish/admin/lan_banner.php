<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_banner.php,v $
|     $Revision: 1.10 $
|     $Date: 2005/06/22 22:21:37 $
|     $Author: sweetas $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com)$
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("BNRLAN_1", "Banner silindi.");
define("BNRLAN_2", "Lütfen bu banner ı silmek istediğinizi onaylayın - silindiğinde tekrar geri getirilemez");
define("BNRLAN_5", "Banner Silmeyi Onayla");
define("BNRLAN_6", "Silme İptal Edildi.");
define("BNRLAN_7", "Varonal Bannerlar");
define("BNRLAN_8", "Banner ID");
define("BNRLAN_9", "Müşteri");
define("BNRLAN_10", "Reklam Bağlantısı");
define("BNRLAN_11", "Tıkla %");
define("BNRLAN_12", "Nüshalar");
define("BNRLAN_13", "Nüsha kaldı");
define("BNRLAN_15", "Þu an Banner yok.");
define("BNRLAN_16", "Sınırsız");
define("BNRLAN_17", "Hiçbiri");
define("BNRLAN_21", "Bitiş");
define("BNRLAN_22", "Banner Güncelle");
define("BNRLAN_23", "Yeni Banner Ekle");
define("BNRLAN_24", "Kampanya");
define("BNRLAN_25", "Varolan kampanya Seç");
define("BNRLAN_26", "Yeni Kampanya Gir");
define("BNRLAN_27", "Müşteri");
define("BNRLAN_28", "Varolan Müşteriyi Seç");
define("BNRLAN_29", "Yeni Müşteri Gir");
define("BNRLAN_30", "Müşteri Girişi");
define("BNRLAN_31", "Müşteri Parolası");
define("BNRLAN_32", "Banner Resmi");
define("BNRLAN_33", "Tıklama URL");
define("BNRLAN_34", "Satın alınan nüshalar");
define("BNRLAN_35", "sınırsız");
define("BNRLAN_36", "Başlangıç Tarihi");
define("BNRLAN_37", "Bitiş Tarihi");
define("BNRLAN_38", "boş = sınırsız");
define("BNRLAN_39", "görünebilirlik sınıfı");
define("BNRLAN_40", "Banner Güncelle");
define("BNRLAN_41", "Yeni Banner Ekle");
define("BNRLAN_42", "Banner Rotasyon Sistemi");
define("BNRLAN_43", "Banner resmi seç");
define("BNRLAN_45", "Başlangıcı");
define("BNRLAN_46", "Kod");
define("BNRLAN_58", "banner önsayfası");
define("BNRLAN_59", "Yeni Banner Oluştur");
define("BNRLAN_60", "kampanyalar");
define("BNRLAN_61", "banner menüsü ");
define("BNRLAN_62", "banner seçenekleri");
define("BNRLAN_63", "Banner Oluşturuldu");
define("BNRLAN_64", "Banner Güncellendi");
define("BANNER_MENU_L1", "Reklam");
define("BANNER_MENU_L2", "Banner menü ayarı kaydedildi");
define("BANNER_MENU_L3", "Başlık");
define("BANNER_MENU_L5", "Banner Ayarı");
define("BANNER_MENU_L6", "menüde gösterilecek kampanyaları seçin");
define("BANNER_MENU_L7", "mümkün kampanyalar");
define("BANNER_MENU_L8", "seçili kampanyalar");
define("BANNER_MENU_L9", "seçimi kaldır");
define("BANNER_MENU_L10", "Gösterim Tipi");
define("BANNER_MENU_L18", "Menü ayarlarını güncelle");
define("BANNER_MENU_L19", "reklamların gösterim numarası:<br/>bunu sadece çoklu kampanyalar seçiliyse kullanın");


?>