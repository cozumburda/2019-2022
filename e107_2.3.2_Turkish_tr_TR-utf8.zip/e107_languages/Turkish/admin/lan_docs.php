<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/10/17 16:20:30
|
|        $Author: admin $
+---------------------------------------------------------------+
*/
define("LAN_DOCS", "Sistem Dokümanları");
define("LAN_DOCS_SECTIONS", "Bölümler");
define("LAN_DOCS_GOTOP", "En üstte git");
define("LAN_DOCS_ANSWER", "Cevap");
define("LAN_DOCS_QUESTION", "Soru");
