<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_menus.php,v $
|     $Revision: 1.9 $
|     $Date: 2005/11/24 15:03:58 $
|     $Author: sweetas $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("MENLAN_7", "Şunun için görünürlük ayarları düzenle");
define("MENLAN_10", "Yeni Menü yüklendi");
define("MENLAN_11", "Menü Kaldırıldı");
define("MENLAN_13", "Alanda Etkin Kıl");
define("MENLAN_14", "Alan");
define("MENLAN_15", "Kapat");
define("MENLAN_17", "Yukarı Taşı");
define("MENLAN_18", "Aşağı Taşı");
define("MENLAN_19", "Alana Taşı");
define("MENLAN_22", "Etkin Olmayan Menüler");
define("MENLAN_23", "En Alta Taşı");
define("MENLAN_24", "En Üste Taşı");
define("MENLAN_25", "Aksiyon...");
define("MENLAN_26", "Bu menü sadece aşağıdaki sayfalarda [b]GÖSTERİLİR[/b]");
define("MENLAN_27", "Bu menü sadece aşağıdaki sayfalarda [b]GİZLİ OLUR[/b]");
define("MENLAN_28", "URL'yi düzgün bir şekilde ayırt etmeye yetecek kadar her satıra bir sayfa girin. URL'nin sonunun tam olarak eşleşmesi gerekiyorsa, sayfa adının sonundabir ! koyun. Örneğin: [b]sayfa.php?1![/b]");
define("MENLAN_30", "Özel görünümler için menü alanları ve pozisyonlarını görmek isterseniz, buradan özel görünüm seçebilirsiniz:");
define("MENLAN_31", "Varsayılan Görünüm");
define("MENLAN_33", "Özel Görünüm");
define("MENLAN_34", "Gömülü");
define("MENLAN_36", "Etkinleştirmek için menü(leri) seç");
define("MENLAN_37", "ve onları nerede etkinleştireceğiniz.");
define("MENLAN_39", "Ön Ayar Alanı");
define("MENLAN_40", "Menü Ön Ayarlarını Kullan");
define("MENLAN_41", "Bu düzen için tüm menülerinizin konumu kaybolacak. Hala devam etmek istiyor musunuz?");
define("MENLAN_43", "Menü Ön Ayarı Etkinleştirildi");
define("MENLAN_44", "Menü parametreleri");
define("MENLAN_45", "Parametreler (sorgu dizesi biçimi):");
define("MENLAN_46", "[x] nesne bulunamadı. Araçlar > Veritabanı'nda eklenti dizinlerini yeniden taramayı deneyin.");
define("MENLAN_47", "Ayarlanmış Alan Yok");
define("MENLAN_48", "Menü yüklenemedi");
define("MENLAN_49", "Menüleriniz");
define("MENLAN_50", "Eklenti Menüleri");
define("MENLAN_51", "Bu düzen herhangi bir dinamik {MENU} alanı İÇERMEZ.");
define("MENLAN_52", "Aşağıdaki özel menüleri içerir:");
define("MENLAN_53", "Özel Menü Alanına Git");
define("MENLAN_54", "Tema düzeni");
define("MENLAN_55", "Menü düzeni");
define("MENLAN_56", "Özel sayfalar");
define("MENLAN_57", "Sürükle ve bırak menüler");
define("MENLAN_58", "Menü Yöneticisi, menülerinizi tema şablonunuza yerleştirmenize ve düzenlemenize olanak tanır. Mevcut menü öğelerini değiştirmek için alt alanların üzerine gelin.");
define("MENLAN_59", "Alan [x]");
define("MENLAN_60", "Bu tema kullanımdan kaldırılmış öğeler kullanıyor. Tüm [x] ÜST BİLGİ ve [x]ALT BİLGİ değişkenleri theme.php'den kaldırılmalıdır.");
