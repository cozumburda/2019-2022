<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_cpage.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/22 17:08:01 $
|     $Author: stevedunstan $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com)$
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "Genel Görünüm");
define("CUSLAN_2", "Sayfa Başlığı");
define("CUSLAN_3", "Her sayfanın simgesi");
define("CUSLAN_4", "İsteğe Bağlı Alanlar");
define("CUSLAN_5", "(Yeni Kitap)");
define("CUSLAN_9", "Metin");
define("CUSLAN_11", "Meta Tanımlama");
define("CUSLAN_12", "Sayfa/Menü Oluştur");
define("CUSLAN_29", "Hiçbir sayfa seçili değilse sayfaları listele");
define("CUSLAN_30", "Çerezler için bitiş zamanı (saniye cinsinden)");
define("CUSLAN_31", "Menü Oluştur");
define("CUSLAN_48", "Sayfa listesi");
define("CUSLAN_49", "Menü listesi");
define("CUSLAN_50", "Kitap/bölüm Listesi");
define("CUSLAN_51", "Kitap/bölüm ekle");
define("CUSLAN_52", "Kitap");
define("CUSLAN_53", "Kitap veya bölüm başlığı");
define("CUSLAN_55", "tarafından düzenlenebilir");
define("CUSLAN_56", "Üst");
define("CUSLAN_57", "Bu giriş için benzersiz bir SEF URL seçiniz.");
define("CUSLAN_58", "Bu bölümdeki sayfaları görüntüle");
define("CUSLAN_59", "Sayfa");
define("CUSLAN_60", "Sayfa seçenekleri");
define("CUSLAN_61", "Menü");
define("CUSLAN_62", "Menü seçenekleri");
define("CUSLAN_63", "Kitap/bölüm");
define("CUSLAN_64", "Menü adı");
define("CUSLAN_65", "Menü başlığı");
define("CUSLAN_66", "Menü Gövdesi");
define("CUSLAN_67", "Menü Şablonu");
define("CUSLAN_68", "Özel düğme metni");
define("CUSLAN_69", "Özel düğme URL'si");
define("CUSLAN_70", "Simge/Glyph Menüsü");
define("CUSLAN_71", "Resim/Video Menüsü");
define("CUSLAN_72", "Kitap/Bölüm Liste şablonu");
define("CUSLAN_73", "Menü Oluşturuldu");
define("CUSLAN_74", "Menü Güncellendi");
define("CUSLAN_75", "Eksik Menü Kimliği Tespit Edildi:");
define("CUSLAN_76", "# Yol numaralı menü");
define("CUSLAN_77", "Silindi");
define("CUSLAN_78", "Yolu olan menü silinemedi");
define("CUSLAN_79", "Bir sayfa başlığı veya bir menü adı girmeniz gerekir.");
define("CUSLAN_80", "Alt Başlık");
define("CUSLAN_81", "Meta Resmi");
define("CUSLAN_82", "İsteğe bağlı. Bu sayfa paylaşılırken sosyal medya tarafından kullanılır.");
