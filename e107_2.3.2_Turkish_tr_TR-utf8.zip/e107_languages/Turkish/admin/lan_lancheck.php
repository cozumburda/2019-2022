<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_lancheck.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/10 21:31:57 $
|     $Author: loloirie $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_2", "Doğrulama");
define("LAN_CHECK_3", "Doğrulaması");
define("LAN_CHECK_4", "Dosya Eksik!");
define("LAN_CHECK_5", "Cümle eksik!");
define("LAN_CHECK_15", "[x] önce veya [y] sonra geçersiz karakterler veya boşluklar bulundu");
define("LAN_CHECK_16", "Orjinal Dosya");
define("LAN_CHECK_17", "Dosya kaydedilirken yazma hatası oldu.");
define("LAN_CHECK_18", "Bu eklenti/tema için standart formattaki dil dosyaları mevcut değildir.");
define("LAN_CHECK_19", "UTF-8'e uygun olmayan karakterler bulundu!");
define("LAN_CHECK_20", "Dil Dosyası Oluştur");
define("LAN_CHECK_21", "Tekrar Doğrula");
define("LAN_CHECK_23", "Hata Bulundu");
define("LAN_CHECK_26", "Giriş");
define("LAN_CHECK_PAGE_TITLE", "Diller");
define("LAN_CHECK_27", "Bulunan dil paketi hatalarının sayısı");
define("LAN_CHECK_28", "Birebir aynı");
define("LAN_CHECK_29", "Birebir aynı dize (yalnızca uyarı)");
define("LAN_CHECK_30", "Eksik bbcodes");
define("LAN_CHECK_31", "Eksik [ and/or ] karakter(ler)");
define("LAN_CHECK_32", "Eksik HTML etiketleri");
define("LANG_LAN_23", "Dil paketi (ZIP) oluştur");
define("LANG_LAN_30", "Yayın tarihi");
define("LANG_LAN_31", "Uyumluluk");
define("LANG_LAN_35", "Aşağıdaki dil paketleri e107'nin bu sürümü için kullanılabilir.");
define("LANG_LAN_111", "Yayın tarihi");
define("LANG_LAN_112", "Uyumlu");
define("LANG_LAN_114", "Paketi İndir");
define("LANG_LAN_115", "Lütfen bir dil paketi oluşturmaya çalışmadan önce kalan [x] hatayı/hataları doğrulayın ve düzeltin.");
define("LANG_LAN_116", "Lütfen dil dosyalarınızı doğrulayın ('Doğrulayın') ve tekrar deneyin.");
define("LANG_LAN_117", "Dil paketinizi eklemeden önce kalan hataları düzeltmelisiniz.");
define("LANG_LAN_119", "Lütfen CORE_LC ve CORE_LC2'nin [x] için değerlere sahip olduğunu kontrol edin ve tekrar deneyin.");
define("LANG_LAN_120", "Lütfen e107_config.php'de varsayılan klasör adlarını kullandığınızdan emin olun (örn. e107_languages/, e107_plugins/ vb.) ve tekrar deneyin.");
define("LANG_LAN_AGR", "Not: Bu araçları kullanarak dil paket(ler)inizi e107 topluluğuyla paylaşmayı kabul etmiş olursunuz.");
