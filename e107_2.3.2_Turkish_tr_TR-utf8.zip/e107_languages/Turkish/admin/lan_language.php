<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_language.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/06/15 19:11:12 $
|     $Author: e107coders $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LANG_LAN_00", "[x] oluşturulamadı.(zaten mevcut)");
define("LANG_LAN_01", "[x] silindi(varsa) ve oluşturuldu.");
define("LANG_LAN_02", "[x] silinemedi.");
define("LANG_LAN_03", "tablolar");
define("LANG_LAN_04", "Kullanımdan kaldırılan Diller");
define("LANG_LAN_05", "Yüklü Değil");
define("LANG_LAN_06", "Tabloları Oluştur");
define("LANG_LAN_07", "Mevcut tablolar silinsin mi?");
define("LANG_LAN_08", "Mevcut tabloları yenileri ile değiştir (veriler kaybolabilir).");
define("LANG_LAN_11", "Yukarıda seçilmemiş tabloları sil (varsa).");
define("LANG_LAN_12", "Çoklu Dil Tabloları");
define("LANG_LAN_13", "Dil Tercihleri");
define("LANG_LAN_14", "Varsayılan Site Dili");
define("LANG_LAN_15", "Varsayılan dilden veri kopyalamak için tıkla.(links, news-categories için Kullanışlıdır)");
define("LANG_LAN_16", "Çoklu-Dil Veritabanı Kullanımı");
define("LANG_LAN_17", "Varsayılan Dil - Ek tablolara gerek yok.");
define("LANG_LAN_18", "Mevcut alt alan adı dilini bu alan adı dili ile aynı yap:");
define("LANG_LAN_19", "örn. fr.mydomain.com için Fransızca ayarlayın.");
define("LANG_LAN_20", "Her satıra bir alan adı girin. örn. mydomain.com vb. veya devre dışı bırakmak için boş bırakın");
define("LANG_LAN_21", "Dil-Paketleri");
define("LANG_LAN_25", "Dil-Paketi Oluşturma Durumu");
define("LANG_LAN_26", "Yalnızca geçerli dil için dil dosyaları yükle");
define("LANG_LAN_27", "Eğer seçiliyse ve gerekli bir dil bulunamazsa, bir hata olacaktır");
define("LANG_LAN_32", "Yüklü diller");
define("LANG_LAN_33", "Doğrulama sırasında yalnızca hataları görüntüle");
define("LANG_LAN_50", "Yönetici Alanı Arayüz Dili");
define("LANG_LAN_100", "[x] silindi.");
define("LANG_LAN_101", "[x] silinemedi.");
define("LANG_LAN_103", "[x] oluşturuldu.");
define("LANG_LAN_104", "[x] devre dışı ancak bozulmadan kalır.");
define("LANG_LAN_105", "[x] içeren tüm tablolar silinsin mi?");
define("LANG_LAN_106", "Etki Alanına göre Dil");
define("LANG_LAN_107", "Etki alanı sitenin dilini belirler. Etki alanını 'www.' olmadan girin");
define("LANG_LAN_121", "Yüklenemedi:");
define("LANG_LAN_124", "Tanım");
define("LANG_LAN_126", "Tüm kullanılmayanları devre dışı bırak");
define("LANG_LAN_130", "Genel şart");
define("LANG_LAN_131", "Dil dosyasında eksik");
define("LANG_LAN_132", "Genel bir terimdir.");
define("LANG_LAN_133", "Kullan");
define("LANG_LAN_134", "yerine.");
define("LANG_LAN_135", "Üzerine yazma");
define("LANG_LAN_136", "Üzerine yazılamaz");
define("LANG_LAN_137", "İşlenmiş");
define("LANG_LAN_140", "Birden fazla seçim yapmak için CTRL tuşunu basılı tutun. [br]örn. kontrol [b]lan_signup.php[/b] Seçmek istiyorsanız [b]signup_shortcodes.php[/b] ve [b]signup_template.php[/b].");
define("LANG_LAN_141", "Script (betik) Seçin...");
define("LANG_LAN_142", "Otomatik algıla");
define("LANG_LAN_143", "Özel Dil Dosyası:");
define("LANG_LAN_144", "Yeniden etkinleştirilmesi gerekir");
define("LANG_LAN_148", "Normal mod");
define("LANG_LAN_149", "Değer");
define("LANG_LAN_150", "[b] Herhangi bir dil dosyasından herhangi bir dilde yorum yapmadan önce tüm çekirdeği ara [/b]");
define("LANG_LAN_151", "Kullanılabilir");
define("LANG_LAN_152", "[e107 translations team] izniyle");
define("LANG_LAN_153", "Ön sürüm");
define("LANG_LAN_154", "Dil Paketi oluşturuldu. Artık [[here] belirtildiği gibi Github deposuna gönderebilirsiniz.");
define("LANG_LAN_155", "Ek dil paketlerinin yüklenmesini gerektirir");
