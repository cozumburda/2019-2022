<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_fla.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/06/17 07:51:40 $
|     $Author: stevedunstan $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("FLALAN_2", "Başarısız oturum açma denemesi yok");
define("FLALAN_3", "Deneme(ler) silindi
");
define("FLALAN_4", "Kullanıcı, yanlış kullanıcı adı/şifre kullanarak oturum açmaya çalıştı");
define("FLALAN_5", "IP(ler) yasaklandı");
define("FLALAN_7", "Veri");
define("FLALAN_8", "IP adresi/ Host");
define("FLALAN_10", "Sil / Seçilen girişleri yasakla");
define("FLALAN_15", "Aşağıdaki IP adres(ler)i otomatik olarak yasaklandı - kullanıcı 10'dan fazla başarısız oturum açma girişiminde bulundu");
define("FLALAN_16", "Bu oto yasak listesini sil");
define("FLALAN_17", "Oto yasak listesi silindi");
