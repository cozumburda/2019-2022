<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_banlist.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/06/17 06:49:46 $
|     $Author: stevedunstan $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com)$
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("BANLAN_5", "Giriş Yapılan IP, e-mail adresi, yada sağlayıcı");
define("BANLAN_7", "Sebep");
define("BANLAN_9", "Şu siteden e-mail, IP veya sağlayıcı adresi ile gelen kullanıcıları yasakla");
define("BANLAN_10", "IP / E-mail / Sebep");
define("BANLAN_11", "Otomatik yasak: 10 dan fazla başarısız giriş denemesi");
define("BANLAN_15", "Mesajlar/Yasak periyodu");
define("BANLAN_16", "Yasaklama");
define("BANLAN_19", "Notlar");
define("BANLAN_23", "gün");
define("BANLAN_24", "Saat");
define("BANLAN_28", "Yasak türü");
define("BANLAN_29", "Yasaklanan kullanıcıya gösterilecek mesaj");
define("BANLAN_30", "Ban süresi");
define("BANLAN_31", "(Kullanıcının boş bir ekran alması için isterseniz boş bir ileti kullanın)");
define("BANLAN_32", "Belirsiz");
define("BANLAN_34", "Süresi dolmuş");
define("BANLAN_35", "İçe Alma/Dışa Aktarma");
define("BANLAN_36", "Dışa Aktarma türü");
define("BANLAN_37", "Alan ayracı");
define("BANLAN_38", "Alıntı (Her değeri yuvarla)");
define("BANLAN_40", "Yasaklı Listesi Dışa Aktarma");
define("BANLAN_41", "Yasaklı Listesi İçe Aktarma");
define("BANLAN_42", "İçe Aktarma Seçenekleri");
define("BANLAN_43", "Var olan tüm yasaklı listesini içe aktarılanlar ile yer değiştir");
define("BANLAN_44", "İçe aktarılanlardan bitiş tarihi/saatini kullan");
define("BANLAN_46", "İçe aktarma dosyası:");
define("BANLAN_47", "Dosya karşıya yükleme hatası");
define("BANLAN_48", "Yasaklı listesi girişlerinden süresi bitmiş olanları [y] Sil");
define("BANLAN_49", "CSV içe aktarma: dengesiz tırnak içinde satır");
define("BANLAN_50", "CSV içe aktarma: yasaklı listesi yazılırken kayıt satırında hata oluştu");
define("BANLAN_51", "CSV içe aktarma: başarılı, [y] satır dosyadan içe aktarıldı.");
define("BANLAN_52", "Beyaz liste");
define("BANLAN_53", "Beyaz listeye ekle");
define("BANLAN_54", "Beyaz listede girdi yok");
define("BANLAN_55", "Giriş tarihi");
define("BANLAN_56", "IP/E-posta, Kullanıcı");
define("BANLAN_57", "Kullanıcı");
define("BANLAN_58", "Kullanıcıları beyaz listeye ekle");
define("BANLAN_59", "Mevcut beyaz liste girdisini Düzenle");
define("BANLAN_60", "Mevcut yasaklı girdisini Düzenle");
define("BANLAN_61", "Mevcut Beyaz liste girdileri");
define("BANLAN_63", "Tersine DNS kullanarak sağlayıcının yasaklamasına izin ver");
define("BANLAN_64", "Yasak eklerken ters DNS erişimleri");
define("BANLAN_65", "Bu seçenek kullanıcıları sadece IP veya email adresi ile yasaklamaya ek olarak sağlayıcı adı ile yasaklamanıza izin verir.  <br /> NOT: Bu durum bazı sağlayıcılarda sunucu cevap vermezse, sayfa yükleme zamanlarını etkileyebilir.");
define("BANLAN_66", "Yasaklama yapıldığında, bu seçenek etki alanının neden yasaklı adresine eklendiğini belirtir");
define("BANLAN_67", "Maksimum erişim oranını ayarla");
define("BANLAN_68", "Bu, 5 dakikalık bir süre içinde maksimum site erişimi sayısını belirler.");
define("BANLAN_69", "üyeler için");
define("BANLAN_70", "Konuklar için");
define("BANLAN_71", "Yasak periyodunu tekrar tetikle");
define("BANLAN_72", "Yasak seçenekleri");
define("BANLAN_73", "Yasaklı bir kullanıcı siteye erişirse yasağı yeniden başlatır");
define("BANLAN_74", "Yasaklı listesi bakımı");
define("BANLAN_75", "Süresi dolan yasaklıları listeden kaldır");
define("BANLAN_76", "Yürüt");
define("BANLAN_77", "Mesajlar/Yasak Periyodları");
define("BANLAN_78", "İsabet sayısı aşıldı (belirlenen süre içinde [x] istek)");
define("BANLAN_79", "CSV Dışa verme biçimi:");
define("BANLAN_80", "CSV içe aktarma biçimi:");
define("BANLAN_81", "Yasak eylem günlüğü");
define("BANLAN_82", "Yasak eylem günlüğünde girdi yok");
define("BANLAN_83", "Tarih/Saat");
define("BANLAN_84", "IP adresi");
define("BANLAN_85", "Ek bilgi");
define("BANLAN_86", "Yasak ile ilişkili olaylar");
define("BANLAN_87", "Listedeki Toplam [y] girişler");
define("BANLAN_88", "Yasak eylem günlüğü boş");
define("BANLAN_89", "Günlük dosyası silindi");
define("BANLAN_90", "Günlük dosyası silme hatası");
define("BANLAN_91", "yasak günlüğü için Tarih/Saat biçimi");
define("BANLAN_92", "Php.net'ten strftime fonksiyonu sayfasına bakın");
define("BANLAN_93", "-");
define("BANLAN_100", "Bilinmiyor");
define("BANLAN_101", "El ile");
define("BANLAN_102", "-Flood-");
define("BANLAN_103", "Ziyaret sayısı");
define("BANLAN_104", "Oturum açma hatası");
define("BANLAN_105", "İçe Aktarılmış");
define("BANLAN_106", "Kullanıcı");
define("BANLAN_107", "Bilinmiyor");
define("BANLAN_108", "Bilinmiyor");
define("BANLAN_109", "Eski");
define("BANLAN_110", "Büyük olasılıkla bir yasak e107 0.7.x yükseltme yapmadan önce getirildi");
define("BANLAN_111", "Bir yönetici tarafından girilen");
define("BANLAN_112", "Çok hızlı site güncelleme girişimi");
define("BANLAN_113", "Çok sık aynı adresten siteye erişilmeye çalışıldı");
define("BANLAN_114", "Aynı kullanıcı birden fazla başarısız giriş denemesi yaptı");
define("BANLAN_115", "Dış listeden eklendi");
define("BANLAN_116", "Yasaklı Kullanıcı hesabı nedeniyle yasaklı IP adresi");
define("BANLAN_117", "Zayıf neden");
define("BANLAN_118", "Zayıf neden");
define("BANLAN_119", "Bir içe aktarma hatasını gösterir - önceden içe aktarılan yasaklar");
define("BANLAN_120", "Beyaz liste girişi");
define("BANLAN_121", "Kara liste girişi");
define("BANLAN_122", "Kara liste");
define("BANLAN_123", "Kara listeye ekle");
define("BANLAN_124", "Sona eriyor");
define("BANLAN_125", "Benim IP adresimi kullanın");
define("BANLAN_126", "IP / e-posta");
define("BANLAN_127", "Tüm [x] Başarısız Oturum Açma işlemlerini veritabanından sil");
