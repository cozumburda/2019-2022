<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_check_user.php,v $
|     $Revision: 1.2 $
|     $Date: 2009/01/06 20:58:08 $
|     $Author: e107steved $
|     $T�rk�e �eviri: shadowtr (http://www.e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LAN_CKUSER_01", "Kıllanıcı veri tabanını kontrol et");
define("LAN_CKUSER_02", "potansiyel sorunların ortadan kalkması için kullnıcı veri tabanını kontrol eder.");
define("LAN_CKUSER_03", "Çok miktarda kullanıcınız varsa bu  işlem zaman alabilir zaman aşımına ugraya bilir.");
define("LAN_CKUSER_04", "işlem sürüyor");
define("LAN_CKUSER_05", "mükerrer giriş adlarını kontrol et.");
define("LAN_CKUSER_06", "yapılacakları seçiniz");
define("LAN_CKUSER_07", "mükerrer kullanıcı adları bulundu");
define("LAN_CKUSER_08", "mükerrerlik bulunamadı");
define("LAN_CKUSER_09", "kullanıcı adı");
define("LAN_CKUSER_10", "kullanıcı id");
define("LAN_CKUSER_11", "görüntü adı");
define("LAN_CKUSER_12", "Mükerrer eposta adreslerini kontrol et");
define("LAN_CKUSER_13", "Mükerrer eposta adresi bulundu");
define("LAN_CKUSER_14", "Eposta adresleri");
define("LAN_CKUSER_15", "mükerrerlik bulunamadı");
define("LAN_CKUSER_16", "başka birinin adıyla girilmiş mesajları ara");
define("LAN_CKUSER_17", "kullanıcı adı ve giriş adı eşleştiriliyor");
define("LAN_CKUSER_18", "kullanıcı A");
define("LAN_CKUSER_19", "kullanıcı B");
define("LAN_CKUSER_20", "");


?>