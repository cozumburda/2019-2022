<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_frontpage.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/06/02 06:14:20 $
|     $Author: sweetas $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("FRTLAN_13", "Şu anki Giriş Sayfası Ayarları");
define("FRTLAN_30", "Özel sayfa");
define("FRTLAN_35", "Giriş yapıldıktan Sonra gelecek sayfa");
define("FRTLAN_42", "Yeni Kural Ekle");
define("FRTLAN_43", "Sınıf");
define("FRTLAN_46", "Mevcut kuralı düzenle");
define("FRTLAN_49", "Ana sayfa");
define("FRTLAN_51", "Diğer");
define("FRTLAN_PAGE_TITLE", "Giriş Sayfası");
define("FRTLAN_56", "sınıf için yinelenen tanım:");
define("FRTLAN_57", "Yazılım hatası");
define("FRTLAN_61", "Seçim");
