<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_users_extended.php,v $
|     $Revision: 1.14 $
|     $Date: 2006/01/15 01:08:04 $
|     $Author: streaky $
|			$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("EXTLAN_1", "Ad");
define("EXTLAN_2", "Önizleme");
define("EXTLAN_3", "Değerler");
define("EXTLAN_4", "Gerekli");
define("EXTLAN_5", "Uygulanabilir");
define("EXTLAN_6", "Okuma Erişimi");
define("EXTLAN_7", "Yazma Erişimi");
define("EXTLAN_8", "Eylem");
define("EXTLAN_9", "Genişletilmiş Kullanıcı Alanları");
define("EXTLAN_10", "Alan Adı");
define("EXTLAN_11", "Bu, tabloda saklanan alanın adıdır, diğerlerinden benzersiz olmalı ve ana kullanıcı tablosunda kullanılmamalıdır.");
define("EXTLAN_12", "Alan Metni");
define("EXTLAN_13", "Bu, işlenen sayfalarda alanın görüntülenen adıdır.");
define("EXTLAN_14", "Alan Tipi");
define("EXTLAN_15", "Alan metin içerir");
define("EXTLAN_16", "Varsayılan Değer");
define("EXTLAN_17", "Her satıra olası her değeri girin <br /> VT tablosu için yardıma bakın.");
define("EXTLAN_18", "Gerekli");
define("EXTLAN_19", "Kullanıcıların ayarlarını güncellerken bu alana bir değer girmeleri istenecektir.");
define("EXTLAN_20", "Bu alanın hangi kullanıcılara uygulanacağını belirler.");
define("EXTLAN_21", "Bu, Kullanıcı ayarlarında bu alanı kimlerin göreceğini belirleyecektir.");
define("EXTLAN_22", "Bu, kullanıcı sayfasındaki değeri kimlerin görebileceğini belirler <br />NOT: Bunu 'Salt Okunur' olarak ayarlamak, yalnızca Yönetici ve üye tarafından görülebilir hale getirir.");
define("EXTLAN_23", "Genişletilmiş Alan Ekle");
define("EXTLAN_24", "Genişletilmiş Alan Güncelle");
define("EXTLAN_25", "aşağı taşı");
define("EXTLAN_26", "yukarı taşı");
define("EXTLAN_27", "Silmeyi Onayla");
define("EXTLAN_28", "Tanımlanan Genişletilmiş Alan yok");
define("EXTLAN_29", "Genişletilmiş Kullanıcı Alanları Kaydedildi.");
define("EXTLAN_30", "Genişletilmiş Alan Silindi");
define("EXTLAN_31", "Kategori etiketi");
define("EXTLAN_32", "Bu, Kullanıcı Ayarları sayfasında gösterilen alanın etiketidir. Dil sabitlerine izin verilir.");
define("EXTLAN_33", "Düzenlemeyi İptal Et");
define("EXTLAN_34", "Genişletilmiş Alanlar");
define("EXTLAN_35", "Kategoriler");
define("EXTLAN_36", "Atanmış Kategori Yok");
define("EXTLAN_37", "Tanımlanmış kategori yok");
define("EXTLAN_38", "Kategori Adı");
define("EXTLAN_39", "Kategori Ekle");
define("EXTLAN_40", "Kategori Oluşturuldu");
define("EXTLAN_41", "Kategori Silindi");
define("EXTLAN_42", "Kategori Güncelle");
define("EXTLAN_43", "Kategori Güncellendi");
define("EXTLAN_44", "Kategori");
define("EXTLAN_45", "Yeni Alan Ekle");
define("EXTLAN_46", "Yardım");
define("EXTLAN_47", "Yeni Parametre Ekle");
define("EXTLAN_48", "Yeni Değer Ekle");
define("EXTLAN_49", "Kullanıcıya Gizleyebilme özelliği ver");
define("EXTLAN_50", "Bunu evet olarak belirlemeniz kullanıcıya bu değeri yönetici olmayanlardan gizleme yeteneğini kazandıracaktır");
define("EXTLAN_51", "Herhangi geçerli bir w3c parametresi buraya girilebilir<br />örn <i><b>class='tbox' size='40' maxlength='80'</i></b>");
define("EXTLAN_52", "regex doğrulama kodu");
define("EXTLAN_53", "Geçerli bir giriş yapmak için eşleşmesi gereken regex kodunu girin <br />**regex sınırlayıcıları gereklidir**");
define("EXTLAN_54", "regex başarısızlık metni");
define("EXTLAN_55", "Regex doğrulanamadığında gösterilecek hata mesajını girin.");
define("EXTLAN_56", "Önceden Tanımlı Alanlar");
define("EXTLAN_57", "Etkinleştirildi");
define("EXTLAN_58", "Etkinleştirilmedi");
define("EXTLAN_59", "Etkinleştir");
define("EXTLAN_60", "Etkinleştirme");
define("EXTLAN_62", "Tablo");
define("EXTLAN_63", "Alan Kimliği");
define("EXTLAN_64", "Değeri Gösterimi");
define("EXTLAN_65", "Hayır - kayıt sayfasında gösterilmeyecek");
define("EXTLAN_66", "Evet - Kayıt sayfasında gösterilecek");
define("EXTLAN_67", "Hayır - Kayıt Sayfasında gösterilecek");
define("EXTLAN_68", "Alan:");
define("EXTLAN_69", "Etkinleştirildi");
define("EXTLAN_70", "HATA!! Alan:");
define("EXTLAN_71", "Etkinleştirilmedi!");
define("EXTLAN_72", "pasifleştirildi");
define("EXTLAN_73", "pasifleştirilmedi!");
define("EXTLAN_74", "ayrılmış bir alan adıdır ve kullanılamaz.");
define("EXTLAN_75", "Veritabanına alan eklenirken hata oluştu.");
define("EXTLAN_76", "Alan adında geçersiz karakterler - sadece A-Z, a-z, 0-9, '_' kullanılabilir.");
define("EXTLAN_77", "Kategori silinemedi - öncelikle kategori içindeki bu alanları silmelisiniz:");
define("EXTLAN_78", "Veri tablosu oluşturmak için gereken [x] dosyası bulunamadı");
define("EXTLAN_79", "Etiket");
define("EXTLAN_80", "Doğrulama hatası - iptal edildi.");
define("EXTLAN_81", "Özel Alan Ekle");
define("EXTLAN_82", "Değerler");
define("EXTLAN_83", "Yer tutucu");
define("EXTLAN_84", "Yardım ipucu");
define("EXTLAN_86", "Kullanıcı Genişletilmiş Sütunu tablodan silindi");
define("EXTLAN_87", "Sıralama değerleri");
define("EXTLAN_HELP_1", "<b><i>Parametreler:</i></b><br />boyut - alanın boyutu<br />maksimum uzunluk - maksimum alan uzunluğu<br /><br />sınıf - css alan sınıfı< br />style - css style string<br /><br />regex - normal ifade doğrulama kodu<br />regexfail - doğrulama başarısız metni");
define("EXTLAN_HELP_2", "'Değerler' kutusuna seçenekler için metin girin - seçenek başına bir kutu. Gerektiğinde yeni kutular ekleyin");
define("EXTLAN_HELP_3", "'Değerler' kutusuna seçenekler için metin girin - seçenek başına bir kutu. Gerektiğinde yeni kutular ekleyin");
define("EXTLAN_HELP_4", "<b><i>Değerler:</i></b><br />HER ZAMAN verilen üç değer olmalıdır:<br /><ol><li>dbtable</li><li>id içeren alan< /li><li>değer içeren alan</li></ol><br />");
define("EXTLAN_HELP_5", "Serbest biçimli metin için bir alan tanımlayın. ('Alan dahil metni' kutusundaki boyutu gerektiği gibi ayarlayın)");
define("EXTLAN_HELP_6", "Kullanıcının sayısal bir değer girmesine izin ver");
define("EXTLAN_HELP_7", "Kullanıcının bir tarih girmesini gerektir");
define("EXTLAN_HELP_8", "Kullanıcının yüklü diller arasından seçim yapmasına izin ver");
define("EXTLAN_HELP_9", "Önceden tanımlanmış bir liste belirtin. Değer alanı, liste türünü seçer - şu anda yalnızca 'saat dilimleri' geçerli bir giriştir");
