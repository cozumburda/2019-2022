<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_updateadmin.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:55 $
|     $Author: e107coders $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Hata - lütfen tekrar gönderin");
define("UDALAN_2", "Yönetici Ayarları güncellendi");
define("UDALAN_3", "Şunun için ayarlar güncellendi:");
define("UDALAN_4", "Ad");
define("UDALAN_6", "Şifrenizi yeniden yazın");
define("UDALAN_7", "Şifre Değiştir");
define("UDALAN_8", "Şunun için şifre güncellendi");
