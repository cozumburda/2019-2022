<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_emoticon.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/01/15 01:08:03 $
|     $Author: streaky $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "İfadeleri etkinleştir");
define("EMOLAN_3", "İfadeler");
define("EMOLAN_4", "İfadeleri aktif edilsin mi?");
define("EMOLAN_5", "Resim");
define("EMOLAN_6", "İfade Kodu");
define("EMOLAN_7", "birden çok girişi boşluklarla ayırın");
define("EMOLAN_11", "Paketi Etkinleştir");
define("EMOLAN_13", "Yüklenmiş Paketler");
define("EMOLAN_17", "Adında boşluklar içeren bir ifade paketiniz var! İzin verilmiyor!");
define("EMOLAN_18", "Lütfen aşağıda listelenen örnekleri boşluk içermeyecek şekilde yeniden adlandırın");
define("EMOLAN_20", "Konum");
define("EMOLAN_21", "Paketi Okuma Hatası");
define("EMOLAN_22", "Yeni ifade paketi bulundu:");
define("EMOLAN_23", "Yeni xml ifade paketi bulundu:");
define("EMOLAN_24", "Yeni ifade php paketi bulundu:");
define("EMOLAN_26", "Paketi tekrar tara");
define("EMOLAN_27", "Paket işlenirken hata oluştu");
define("EMOLAN_28", "XML Oluştur");
define("EMOLAN_29", "XML dosyası oluşturuldu");
define("EMOLAN_30", "XML dosyası yazma hatası");
define("EMOLAN_PAGE_TITLE", "İfadeler");
define("EMOLAN_31", "Toplam [x] dosya bulundu");
define("EMOLAN_32", "Bilinmeyen paket algılandı");
define("EMOLAN_33", "Desteklenmeyen XML dosya biçimi");
define("EMOLAN_34", "Paket için eksik dosyalar");
define("EMOLAN_35", "- veritabanından silinmiş");
define("EMOLAN_37", "İfade ayarlanmadı");
define("EMOLAN_38", "Boş ifade değeri");
