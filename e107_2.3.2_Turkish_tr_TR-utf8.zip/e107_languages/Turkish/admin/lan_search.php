<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_search.php,v $
|     $Revision: 1.23 $
|     $Date: 2006/01/16 15:06:30 $
|     $Author: sweetas $
|	  	$Türkçe Çeviri: MaCCoDeR_Hüseyin ASA (maccoder@hotmail.com) $
|											shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("SEALAN_1", "Arama Yapılandırması");
define("SEALAN_3", "Arama sıralama yöntemi:");
define("SEALAN_7", "Kayıtlı Üyeler");
define("SEALAN_10", "Alakalı değeri göster:");
define("SEALAN_11", "Kullanıcının Aranabilir Alanları Seçmesine İzin Ver:");
define("SEALAN_12", "Aramalar arasında izin verilen kısıtlama süresi (en fazla 5 dakika):");
define("SEALAN_13", "Her seferinde bir aramayla sınırla");
define("SEALAN_14", "saniye");
define("SEALAN_15", "Kullanıcı sınıfı tarafından erişilebilen arama sayfası");
define("SEALAN_18", "Aranabilir Yorum Alanları (yorum arama etkinleştirildiğinde)");
define("SEALAN_19", "Kullanıcıların aynı anda birden fazla alanda arama yapmasına izin ver:");
define("SEALAN_20", "Genel Ayarlar");
define("SEALAN_21", "Aranabilir Alanlar");
define("SEALAN_23", "Alternatif:");
define("SEALAN_25", "Kullanıcı Sınıfı");
define("SEALAN_26", "Ön Başlık Metni");
define("SEALAN_30", "Başvurulan sayfada anahtar kelimeleri vurgulayın:");
define("SEALAN_31", "PHP ile sınırlı");
define("SEALAN_32", "sonuçlar (sınırsız olması için boş bırakın)");
define("SEALAN_35", "Aranabilir alanlar seçim yöntemi:");
define("SEALAN_36", "Açılır");
define("SEALAN_37", "Seçim Kutusu");
define("SEALAN_38", "Radyo Buton");
define("SEALAN_39", "Özel Sayfalar");
define("SEALAN_40", "Arama Seçenekleri");
define("SEALAN_41", "Ana Sayfa");
define("SEALAN_43", "Şunun için arama seçeneklerini düzenle:");
define("SEALAN_44", "Bu alanda arama yapabilecek kullanıcı sınıfı");
define("SEALAN_45", "Sayfa başına gösterilecek sonuç sayısı");
define("SEALAN_46", "Arama sonuç özetinde gösterilecek karakter sayısı");
define("SEALAN_47", "Sadece Tüm Kelimeleri Eşle:");
define("SEALAN_48", "Bu seçenek sadece arama sıralama metodu PHP ise işe yarar. Eğer siteniz Çince ve Japonca gibi ideografik dil içeriyorsa bu grubu kapatmanız gerekir.");
define("SEALAN_49", "Eğer siteniz Çince ve Japonca gibi ideografik dil içeriyorsa PHP sıralama metodunu kullanmanız gerekir.");
