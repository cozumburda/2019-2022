<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/07/24 18:29:55
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("LAN_CRON_M_02", "Yenile");
define("LAN_CRON_2", "Fonksiyon");
define("LAN_CRON_3", "Sekme");
define("LAN_CRON_4", "Son-Çalıştırma");
define("LAN_CRON_01_1", "Test E-mail");
define("LAN_CRON_01_2", "[eml] 'ne Test maili gönder.");
define("LAN_CRON_01_3", "Zamanlama sistemini test etmek için önerilir.");
define("LAN_CRON_02_1", "Mail Kuyruğu");
define("LAN_CRON_02_2", "Mail kuyruğu işleniyor");
define("LAN_CRON_03_1", "Mail reddedme kontrolü");
define("LAN_CRON_03_2", "Reddedilen mailller kontrol ediliyor");
define("LAN_CRON_04_1", "Yasak tekrar tetikleme kontrolü");
define("LAN_CRON_04_2", "Reddetme tekrar tetikleme işleniyor.");
define("LAN_CRON_04_3", "Sadece Yasaklı tekrar tetikleme aktif ise gereklidir.");
define("LAN_CRON_05_1", "Veritabanı Yedekleme");
define("LAN_CRON_05_2", "Sistem veritabanının yedeğini");
define("LAN_CRON_06_1", "Yasak Tetikleme İşleniyor");
define("LAN_CRON_6", "Tercihler İçe Aktarılamıyor");
define("LAN_CRON_7", "Zaman Ayarları İçe Aktarılamıyor");
define("LAN_CRON_8", "İçe Aktarılan Zaman Ayarları için");
define("LAN_CRON_9", "[x] dakika ve [y] saniye önce.");
define("LAN_CRON_10", "[y] saniye önce.");
define("LAN_CRON_11", "Aktif Cronlar");
define("LAN_CRON_12", "Son yenilenen cron");
define("LAN_CRON_13", "Lütfen cron.php nin çalıştırılabilir olduğundan emin olun.");
define("LAN_CRON_14", "Lütfen /cron.php nin CHMOD (yetkisini) 755 olarak ayarlayın.");
define("LAN_CRON_15", "Gösterilen Cron komutlarını kullanın");
define("LAN_CRON_16", "Sunucunuzun kontrol panelini kullanırken (örn: cPanel, DirectAdmin, Plesk vb.) Sunucunuzun her dakika bu komutu çalıştırması için lütfen bir crontab oluşturun.");
define("LAN_CRON_20_1", "e107 Güncellemelerini kontrol et");
define("LAN_CRON_20_2", "Çekirdek Güncellemeleri için e107.org 'u kontrol et");
define("LAN_CRON_20_3", "Sistemi güncel tutmak için önerilir.");
define("LAN_CRON_20_4", "Bu Git deposunu güncelle");
define("LAN_CRON_20_5", "Bu e107 kurulumunu Github'tan en son dosyaları kullanarak güncelle.");
define("LAN_CRON_20_6", "Sadece geliştiriciler için önerilmektedir.");
define("LAN_CRON_20_8", "Site stabil [b]çalışmayabilir[/b]!");
define("LAN_CRON_30", "Her Dakika");
define("LAN_CRON_31", "Her Diğer Dakika");
define("LAN_CRON_32", "Her 5 Dakika");
define("LAN_CRON_33", "Her 10 Dakika");
define("LAN_CRON_34", "Her 15 Dakika");
define("LAN_CRON_35", "Her 30 Dakika");
define("LAN_CRON_36", "Her Saat");
define("LAN_CRON_37", "Her Diğer Saat");
define("LAN_CRON_38", "Her 3 Saat");
define("LAN_CRON_39", "Her 6 Saat");
define("LAN_CRON_40", "Her Gün");
define("LAN_CRON_41", "Her Ay");
define("LAN_CRON_42", "Her haftanın Günü");
define("LAN_CRON_50", "Dakika");
define("LAN_CRON_51", "Saat");
define("LAN_CRON_52", "Gün");
define("LAN_CRON_53", "Ay");
define("LAN_CRON_54", "Haftanın günü(günleri)");
define("LAN_CRON_55", "Veritabanı yedeklemesi başarısız");
define("LAN_CRON_56", "Veritabanı yedeklemesi tamamlandı");
define("LAN_CRON_60", "cPanel'e git");
define("LAN_CRON_61", "Yeni cron şifresi üret");
define("LAN_CRON_62", "[b][x][/b] yapılandırma fonksiyonu çalıştırılıyor");
define("LAN_CRON_63", "[b][x][/b] yapılandırma fonksiyonu bulunamadı.");
define("LAN_CRON_64", "Bir yönetici e107 görev takvimini kullanarak otomatik görevler oluşturabilir. [br] Yönetim sekmesinden görevleri düzenleyebilir, çalıştırabilir ve silebilirsiniz. [br] Görevi düzenlerken ne zaman çalıştırmak istiyorsanız dakika, saat, gün, ay veya haftanın günü olarak ayar yapabilirsiniz. Çalıştırılacak her periyot için * kullanın. Görevin 'Aktif Özellikleri Kullan' seçeneğini etkinleştirin. [br] NOT: Standart Görevleri [b]Silmemeniz[/b] Önerilir.[br]");
define("LAN_CRON_BACKUP", "Yedek");
define("LAN_CRON_LOGGING", "Kayıtlar Yazılıyor");
define("LAN_CRON_RUNNING", "Çalıştırılıyor");
define("LAN_CRON_65", "Git Tema deposu güncelleniyor");
define("LAN_CRON_66", "Git deposu bulunamadı");
define("LAN_CRON_67", "Git deposunda Tema klasörü bulunamadı");
