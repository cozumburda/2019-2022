<?php
$text = "Bununla Dizinleri organize edebilirsiniz. Şayet erişim hakkı hatası oluşursa, ozaman bu Dizin' in CHMOD haklarına bakın, Upload etmek istediğiniz dizin ayarını '777' yapın.";
$ns -> tablerender("Dosya yönetim Yardım", $text);
?>
