<?php
$caption = " Yönetici ana sayfa - yardım";
$text = "Bu sayafayı yeni  Yönetici eklemek, değiştirmek, silmek için kullanınız. Yeni Yönetici, sadece sizin verdiğiniz yetkilere ve Menülere erişebilir. Sadece yetki vermek istediğiz yerlere(checkbox) işaret koyunuz.";
$ns -> tablerender($caption, $text);
?>
