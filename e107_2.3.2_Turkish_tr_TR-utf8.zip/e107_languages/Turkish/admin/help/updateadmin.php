<?php
$text = "Şifrenizi buradan güncelleştiriniz.";
$ns -> tablerender("Admin Passwort update - Yardım", $text);
?>
