<?php
$text = "Bildiriler Makalelere benzerler, ama kendilerine ait bir Menğleri vardır.<br />
Birkaç sayfalık Bildiriler için bir sayfa mısampajı gerek, bunun için '[newpage]'Tag girin. Siz gerekirse Bildiri kategorileride uyarlayabilirsiniz. Bunun için Makale Yardım konusunu karşılaştırınız.";
$ns -> tablerender("bildiriler Yardım", $text);
?>
