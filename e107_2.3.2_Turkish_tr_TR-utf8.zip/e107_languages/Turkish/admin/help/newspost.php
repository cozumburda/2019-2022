<?php
$caption = "Haber yayınlama (posten) Yardım";
$text = "<b>Genel açıklama</b><br />
Haberin açıklaması Ana sayfada göster,  haberin detaylı görüntüsü,  kullanıcıların 'devamını oku' yazısında tıkladıklarına gözükecektir. 
<br />
<br />
<b>sadece başlığı göster</b>
<br />
Sadece başlığın haber sayfasında gözükmesi için, bu ayarı etkinleştirin. Üzerine tıklandığı taktirde tüm haber okunabilir şekilde gözükecektir.
<br /><br />
<b>etkinleştirme </b>
<br />
Başlangıc ve bitiş tarihi seçerseniz, haberleriniz sadece bu zaman zarfında gösterilecektir.";
$ns -> tablerender($caption, $text);
?>
