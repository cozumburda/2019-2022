<?php

$text = "Bu Menü ile normal bir Yeni sayfa ekliyebilirsiniz.Ana navigasyon cubuğunda bu yeni sayfa için bir Link oluşturulacaktır.Yaptığınız yeni sayfanın adını TEST olarak girerseniz (test.php  html Kodu ılede zapılmış olabilir), ozaman Ana Manü çubugundada sayfanın adı TEST olarak gözükecektir.<br />
Yeni sayfanızda Başlık kullanmak istiyorsanız, ozaman 'Sayfa başlıgı' yazan yere bir başlık giriniz.";
$ns -> tablerender("yardım  içeriği", $text);
?>
