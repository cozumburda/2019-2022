<?php
$caption = "Ana Sayfa Yardım";
$text = "Bu Menü üzeriden Giriş/Start sayafası ayarlarını yapabilirsiniz. Standat ayar 'news.php' olarak yapılmıştır. Bu ayarları  Splashscreen içinde kullanabilirsiniz. Bu sayfanın özelliği, sadece yeni üyelere ilk ziyeretlerinde gözükmesidir.";
$ns -> tablerender($caption, $text);
?>
