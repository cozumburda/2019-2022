<?php
$text = "Linklerinizi değişik kategorilere bölebilirsiniz. Böylelikle Sitenizin Navigasyonu kolaylaştırır ve görüntüyü iyileştirir.br /><br />'Main-ana' Kategorisinde yaptığınız Link ayarları, ana navigasyon menüsünde gösterilecektir.";
$ns -> tablerender("Link Kategori Yardım", $text);
?>
