<?php
$caption = "Kullancı sınıfı Yardım";
$text = "Kullanıcı sınıflarını degiştirebilirsiniz, oluşturabilirsiniz ve silebilirsiniz. <br /> Bu bölüm bağzı site Kullanıcılarınızın yetkilerini kısıtlamaya yardımcı olur. Bir tane ADMIN sınıfı yapmanız, size daima kolaylık sağlar. Bu sınıfı sadece kendiniz icin etkinleştirebilirsiniz.Bunun iyi tarafını şayet siz bildiri, haber, makale yada Content hazırlıyorsanız  mizampajı sayfada orjinal halinde görmek istiyorsanız, yada bir haberi uzun bir zaman zarfı içinde hazırlamanız gerekiyorsa göreceksiniz.<br /><br />
Aynısını belli bölümlere izin vermek icab eden üyelerede uygulayabilirsiniz.  Dikkat edeceğiniz diğer bir hususta, verdiğiniz sınıflandırmayada hangi üyelerin girebilme yetkisidir. <br /><br />
TİP:<br />
Mümkün olduğunca HİÇBİR ZAMAN, emin degilseniz bir sınıfı silmeyiniz! Birdaha silinmiş bir sınıfı geri getirme imkanınız yoktur!";
$ns -> tablerender($caption, $text);
?>
