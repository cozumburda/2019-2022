<?php
$caption = "Cache-Modus";
$text = "Şayet  Cache'yi aktifleştirirseniz, sayfa gösterimini hızlandırmış olursunuz. Birde SQL database sorgulamasıda en aya indirilmiş olur.<br />
<br /><b>ÖNEMLİ DİKKAT!!! Kendi Themanızı yaparken, mutlaka Cache Modusu kapatmalısınız.Kapatmazsanız yaptığınız değişiklikler ya tam gösterilmez yada hatalı olarak görüntü oluşturur.</b> <br />
TİP: Gerekirse Cacheyi boşaltınızkı, değişiklikleri görebilesiniz";
$ns -> tablerender($caption, $text);
?>
