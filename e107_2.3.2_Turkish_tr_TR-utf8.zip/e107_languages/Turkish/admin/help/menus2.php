<?php
$caption = "Menü Yardım";
$text .= "Buradan gösterilmesi istediğiniz Menülerin  yerini ve sıralamasını belirleyebilirsiniz. Okları aşşagı yukarı tıklayarak, Menülerle istediğiniz ayara gelinceye kadar oynuyabilirsiniz.
<br />
Ortadaki Menü ögeleri deaktif haldedir! Bunları Yerini  belirterek aktif hale getirebilirsiniz  (mesela: Bölüm  1, 2, 3 vs.).";

$ns -> tablerender("Menüler  Yardım", $text);
?>
