<?php

$text = " Yazılmış Emoticonsları (GÜLEN YÜZLER) (Emotes/Smilies) resim ile değiştirmek için, Checkbox'u aktive ediniz.<br /><br />
Daha sonra Ayarları kayıt ediniz, böylelikle son veriler güncelleşmiş olacaktır. Yeni SMILEY yüklemek icin e107_images/emoticons/ klasörünü kullanınız, ve bu smileylere gereken kısaltılmış harfleri giriniz. Bunun için aşşağıdaki bölümleri kullanınız.";
$ns -> tablerender("Emoticon/Smilies yardım", $text);
?>
