<?php
$text = "Haberlerinizi değişik  kategorilere bölebilirsiniz, böylelikle ziyaretcilerinize ilgilerini çeken haberleri ilk önce görme imkanı sağlıyabilirsiniz.<br /><br />
Haber iconlarınızı bu iki klasörlere ekliyebilirsiniz  ".e_THEME."-IhrTheme-/images/ yada  themes/shared/newsicons/";
$ns -> tablerender("Haber Kategori Yardım", $text);
?>
