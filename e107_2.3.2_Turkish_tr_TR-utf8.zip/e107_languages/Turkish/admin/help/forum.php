<?php
$caption = "Forum yardım";
$text = "<b>Genel açıklama</b><br />
Bu Menüyü Forumlarınızı değiştirmek ve yenisini olulturmak için kullanınız.<br />
<br />
<b>Ana  - Kök kategori/Forumlar</b><br />
Kök Kategori diğer Altt kategorilerin bu isim altında toplandığı bir Mekan/Başlıktır. Bunun sayesinde kullanıcılar için Navigasyon dahada kolaylaşmaktadır.
<br /><br />
<b>Erreichbarkeit</b>
<br /> 
Sadece belli sınıf üyelerin erişebileceği Forumlar oluşturabilirsiniz. Bunun için Sınflandırma yapmanız gerekmektedir. Sınıflandırma yaptığınız takdirde,  buralar sadece izin verdiginiz üyeler görebilecektir. Bu Ana ve diğer kategoriler içinde geçerlidir.
<br /><br />
<b>Moderatörler</b>
<br />
Forum Moderatörü statüsü vermek istediğiniz Yöneticilerin isimlerini seçin. Burada listede görünmeleri için Moderatörler ilk önce 'Forum Moderator' statüsünü almalılar ! Bunu Yöneticiler Menüsü üzerinden gerçekleştirmelisiniz.
<br /><br />
<b>Kullanıcı Ranking/kademe</b>
<br />
Bu Menü üzerinden ayrıca Kullanıcı Rankingde yönetebilirsiniz. Resim alanları seçildiği takdirde, resimlerde kullanılabilir. Ranking isimlerini kullanabilmek için, Ranking  Resim alanını boş bırakın.<br /> Ranking eşik değeri üyenin diğer dereceye çıkması için gereken Puandır.";
$ns -> tablerender($caption, $text);
unset($text);
?>
/WINDOWS/TEMP/SFTPDROP
