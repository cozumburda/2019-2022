<?php
$text = "Buradan bir Mesaj oluşturabilirsiniz, checkbox kutusundan deaktif edene dek görüntülenecektir. Bu Mesajı Misafirlerinize, Üyelerinize ve yöneticilerinize gösterebilirsiniz. Bu Mesajları herzaman bu Menü üzerinden değiştirebilirsiniz";
$ns -> tablerender("Hoşgeldin Mesajı - Yardım", $text);
?>
