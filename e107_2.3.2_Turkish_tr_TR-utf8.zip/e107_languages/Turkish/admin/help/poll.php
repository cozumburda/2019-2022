<?php
$text = "Anketler ve ayarlar bu Menüden yönetilir. Anketin başlığını yazın opsiyonları yapın ve sorularınızı sorun. Ön gösterim ile Anketin düzenini görebilirsiniz. Daha sonra değişiklikleri aktif hale getiriniz<br /><br />
Anketleri göstermek için, Menüden Anketi etkinleştir yerine tıklayın 'Anket Etkinleştir'.";
$ns -> tablerender("Anketler, Ayarlar", $text);
?>
