<?php
$text = "buradan üye ayarlarını yapabilirsiniz. Ayarları güncelleştirebilirsiniz, üyelere Yönetici yetkisi verebilirsiniz, ve Kullanıcı sınıfı düzenliyebilirsiniz.
";
$ns -> tablerender("Kullanıcı Yardım", $text);
unset($text);
?>
