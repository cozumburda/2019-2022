<?php
$text = "Şayet  e107 Upgrade yapıyorsanız yada siteniz bakım için kapalı ise, ozaman Admin panelinde  Bakım Menüsüne gidiniz ve 'bakım etkinleştiriniz' kutusunu aktifleştiriniz. Bu işlemi yaptıktan sonra, bakım yaptığınız süresince site ziyaretcileri sitenizin kapalı oldugu yazısını göreceklerdir. Bakım bitiminden sonra 'bakım etkinleştiriniz' kutusunu deaktif ediniz.";

$ns -> tablerender("Bakım Yardım", $text);
?>
