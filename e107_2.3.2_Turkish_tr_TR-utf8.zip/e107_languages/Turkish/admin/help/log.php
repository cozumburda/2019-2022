<?php
$text = "'LOGging' Aktivasyonunu  bu Menü ile yapınız. Şayet serverinizde kısıtlı web alanınız varsa ozaman 'sadece Domain/domain sorgula' checkboxunu aktifleştirin. Bu URL'lar için kısa  log uygular, örnek: 'http://www.waketime.com/news.php' yerine 'waketime.com'";
$ns -> tablerender("Logging Yardım", $text);
?>
