<?php
$text = "Lütfen dosyalarınızı Download Klasörüne yükleyiniz ".e_FILE."download için   Resimler  ve  Downloads klasörüne ".e_FILE."downloadimages ve Ön seyretme resimlerinin (Thumbnails) konulacağı klasör ".e_FILE."downloadthumbs.
<br /><br />
Download ayarı için, önce bir Ana kategori oluşturmalısınız ve isimlendirmelisinizö mesela: Fotoğraflarım.Sonra Alt kategori(ler) oluşturun , mesela: JPEG-Resimler, TIFF-Resimler vs. Daha sonra bu alt kategorileri 'Download oluştur' menüsünden downloada sunabilirsiniz.";
$ns -> tablerender("Download Yardım", $text);
?>
