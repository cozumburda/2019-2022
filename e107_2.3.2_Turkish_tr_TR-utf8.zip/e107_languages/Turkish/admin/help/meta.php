<?php
$text = "Buraya gireceğiniz tüm Meta-Taglar, Monitörde dogru yerde gözükecektir.";

$ns -> tablerender("Meta Tags", $text);
?>
