<?php
$text = "Sayfa Linklerinizi(bağlantı) buraya giriniz.Buraya kayıt edilen Linkler, Ana Navigasyon Menüsünde gösterilecektir. Başka Linkler için Lütfen Bağlantılar Pluginini kullanınız.
<br />
<br />
Alt Menü oluşturucusu sadece e107 DHTML-Menüleri için Mantıklıdır. (TreeMenu, UltraTreeMenu, eDynamicMenu, ypSlideMenu...)";
$ns -> tablerender("Bağlanyı Yardım", $text);
?>
