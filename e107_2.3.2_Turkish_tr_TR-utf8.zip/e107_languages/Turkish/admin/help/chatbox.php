<?php
$caption = "Chatbox Menüsü";
$text = "Chatbox Ayarlarını buradan yapabilirsiniz.<br />
Şayet  'Link değiştir' Checkbox kutusunu aktivleştirirseniz, ozaman tüm linkler text kutusuna girilen kelime ile değiştirilecektir. Satır bölme, bi satıra Maksimim kac harf girileceğini belirer (mesela 20).Bu verilen rakkamdan sonra satır bölünür ve yeni satırbaşı yapılır.";
$ns -> tablerender($caption, $text);
?>
