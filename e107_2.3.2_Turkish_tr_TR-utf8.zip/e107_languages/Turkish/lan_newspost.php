<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_newspost.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/15 01:08:03 $
|     $Author: streaky $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("NWSLAN_1", "Haberler silindi.");
define("NWSLAN_2", "Silmek istediğiniz haberlerin yanındaki kutuyu seçiniz.");
define("NWSLAN_3", "Henüz yeni haber yok.");
define("NWSLAN_4", "Varolan Haberler");
define("NWSLAN_5", "HTML Düzenleyici Aç");
define("NWSLAN_6", "Kategori");
define("NWSLAN_7", "Düzenle");
define("NWSLAN_8", "Sil");
define("NWSLAN_9", "doğrulamak için seçin");
define("NWSLAN_10", "Henüz kategori seçilmedi.");
define("NWSLAN_11", "Kategori Ekle/Düzenle");
define("NWSLAN_12", "Başlık");
define("NWSLAN_13", "Asıl Metin");
define("NWSLAN_14", "Uzatılmış");
define("NWSLAN_15", "Yorumlar");
define("NWSLAN_16", "Etkin");
define("NWSLAN_17", "Etkin Değil");
define("NWSLAN_18", "Yeni haberler için yorumlara izin ver");
define("NWSLAN_19", "Etkinleştirme");
define("NWSLAN_20", "Otomatik etkinleştirmeyi devre dışı yapmak için alanı boş bırakın");
define("NWSLAN_21", "Etkinleştirme Aralığı");
define("NWSLAN_22", "Görünürlük");
define("NWSLAN_23", "İşaretlenirse sadece seçilen kullanıcılar görebilir");
define("NWSLAN_24", "Tekrar Önizle");
define("NWSLAN_25", "Haberi veritabanında güncelle");
define("NWSLAN_26", "Haberi veritabanıyla yayımla");
define("NWSLAN_27", "Önizleme");
define("NWSLAN_28", "Yeni Makale");
define("NWSLAN_29", "Yeni Posta");
define("NWSLAN_30", "Sadece başlığı göster");


?>