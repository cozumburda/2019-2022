<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_fpw.php,v $
|     $Revision: 1.4 $
|     $Date: 02-Oca-2008 04:48 PM $
|     $Author: sweetas $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Şifre Sıfırla");
define("LAN_02", "Maalesef e-posta gönderilemiyor - lütfen ana site yöneticisiyle iletişime geçin.");
define("LAN_03", "Şifre Sıfırla");
define("LAN_05", "Şifrenizi sıfırlamak için lütfen aşağıdaki bilgileri giriniz");
define("LAN_06", "Şifre sıfırlama girişimi");
define("LAN_07", "Ip adresiyle birisi");
define("LAN_08", "Ana yönetici şifresini sıfırlamaya çalıştı.");
define("LAN_09", "Şifre sıfırlama formu");
define("LAN_213", "Bu kullanıcı adı/e-posta adresi veritabanında bulunamadı.");
define("LAN_214", "Şifre sıfırlanamıyor");
define("LAN_218", "Kullanıcı adınız:");
define("LAN_FPW1", "Kullanıcı Adı");
define("LAN_FPW4", "Bu şifreyi sıfırlamak için zaten bir istek gönderildi. E-postayı almadıysanız, lütfen yardım için site yöneticisiyle iletişime geçin.");
define("LAN_FPW5", "Şifrenizi sıfırlama isteğiniz için");
define("LAN_FPW6", "Şifrenizi sıfırlamanızı sağlayacak bir bağlantı içeren e-posta size gönderildi.");
define("LAN_FPW7", "Bu, şifrenizi sıfırlamak için geçerli bir bağlantı değil.<br />Daha fazla ayrıntı için lütfen site yöneticisiyle iletişime geçin.");
define("LAN_FPW8", "Şifreniz başarıyla değiştirildi.");
define("LAN_FPW9", "Yeni şifre:");
define("LAN_FPW10", "Lütfen");
define("LAN_FPW11", "Şimdi giriş yap");
define("LAN_FPW12", "ve güvenlik amacıyla şifrenizi hemen değiştirin.");
define("LAN_FPW13", "lütfen şifrenizi doğrulamak için e-postadaki talimatları takip edin.");
define("LAN_FPW14", "IP adresine sahip biri tarafından gönderildi");
define("LAN_FPW15", "Bu, şifrenizin henüz sıfırlandığı anlamına gelmez. Sıfırlama işlemini tamamlamak için aşağıda gösterilen bağlantıya gitmelisiniz.");
define("LAN_FPW16", "Şifrenizin sıfırlanmasını talep etmediyseniz ve sıfırlanmasını İSTEMİYORSANIZ, bu e-postayı göz ardı edebilirsiniz.");
define("LAN_FPW17", "Aşağıdaki link 10 dakika geçerli olacaktır.");
define("LAN_FPW18", "Şifre sıfırlama talep edildi");
define("LAN_FPW19", "E-posta gönderilemedi");
define("LAN_FPW20", "E-posta gönderildi");
define("LAN_FPW21", "Kullanıcı şifre sıfırlama bağlantısına tıkladı");
define("LAN_FPW22", "Email Adresi Sitede Kayıtlı");
define("LAN_FPW_100", "Şifrenizi mi unuttunuz?");
define("LAN_FPW_101", "Endişe etmeyin. Aşağıya e-posta adresinizi girin, size şifrenizi geri almanız için talimatlar içeren bir e-posta göndereceğiz.");
define("LAN_FPW_102", "Şifreyi sıfırla");
