<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/07/22 14:57:40
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("LAN_LIBRARY_MANAGER_01", "[y] kütüphanesinin bağlı olduğu [x] kütüphanesi kurulu değil.");
define("LAN_LIBRARY_MANAGER_02", "[y] kütüphanesinin [x] sürümü, [z] kütüphanesi ile uyumlu değil.");
define("LAN_LIBRARY_MANAGER_03", "[x] kütüphanesi bulunamadı.");
define("LAN_LIBRARY_MANAGER_04", "[x] kütüphanesinin sürümü tespit edilemedi.");
define("LAN_LIBRARY_MANAGER_05", "[y] kütüphanesinin kurulmuş olan [x] sürümü desteklenmemektedir.");
define("LAN_LIBRARY_MANAGER_06", "[y] kütüphanesinin [x] değişkeni bulunamadı.");
define("LAN_LIBRARY_MANAGER_07", "eksik bağımlılık");
define("LAN_LIBRARY_MANAGER_08", "uyumsuz bağımlılık");
define("LAN_LIBRARY_MANAGER_10", "tespit edilemedi");
define("LAN_LIBRARY_MANAGER_11", "desteklenmiyor");
define("LAN_LIBRARY_MANAGER_13", "Kütüphane");
define("LAN_LIBRARY_MANAGER_21", "Sağlayıcı");
define("LAN_LIBRARY_MANAGER_25", "Üçünçü-Parti Kütüphaneler");
define("LAN_LIBRARY_MANAGER_27", "Makine ismi: [x]");
define("LAN_LIBRARY_MANAGER_28", "Kütüphane yolu: [x]");
define("LAN_LIBRARY_MANAGER_29", "Kütüphane yolu");
define("LAN_LIBRARY_MANAGER_30", "CDN ayarları");
define("LAN_LIBRARY_MANAGER_31", "Çekirdek kütüphaneleri için CDN kullan");
define("LAN_LIBRARY_MANAGER_32", "CDN sağlayıcı");
