<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_membersonly.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/06 18:11:26 $
|     $Author: mcfly_e107 $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Sadece Üyeler");
define("LAN_MEMBERS_0", "kısıtlı alan");
define("LAN_MEMBERS_1", "Bu, sınırlı bir alandır.");
define("LAN_MEMBERS_2", "Erişim için lütfen [oturum açın]");
define("LAN_MEMBERS_3", "veya üye olarak [kaydolun].");
define("LAN_MEMBERS_4", "Giriş sayfasına dönmek için buraya tıklayın");
