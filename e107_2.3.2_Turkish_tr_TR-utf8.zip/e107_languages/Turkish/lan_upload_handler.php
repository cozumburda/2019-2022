<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_upload_handler.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/05 06:58:21 $
|     $Author: sweetas $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "Dosya türü");
define("LANUPLOAD_2", "onaylanmadı ve silindi.");
define("LANUPLOAD_3", "Yükleme başarılı");
define("LANUPLOAD_4", "Hedef klasör yok veya yazılabilir değil. (chmod 777)");
define("LANUPLOAD_5", "Yüklenen dosya, php.ini'deki upload_max_filesize yönergesini aşıyor.");
define("LANUPLOAD_6", "Yüklenen dosya, html formunda belirtilen MAX_FILE_SIZE yönergesini aşıyor.");
define("LANUPLOAD_7", "Yüklemenizin sadece bazı parçaları yüklendi.");
define("LANUPLOAD_8", "Hiçbir dosya yüklenmedi.");
define("LANUPLOAD_9", "Yüklenen dosya boyutu 0 bytes");
define("LANUPLOAD_10", "Yükleme başarısız [Duplicate filename] - Bu isme sahip bir dosya zaten var.");
define("LANUPLOAD_11", "Dosya yüklenmedi. Dosya adı:");
define("LANUPLOAD_13", "Geçici klasör eksik");
define("LANUPLOAD_14", "Dosya yazma başarısız oldu");
define("LANUPLOAD_15", "Yüklemeye izin verilmiyor");
define("LANUPLOAD_16", "Blinmeyen Hata");
define("LANUPLOAD_17", "Yüklenen dosya için geçersiz isim");
define("LANUPLOAD_18", "Yüklenen dosya izin verilen dosya boyutunu aşıyor.");
define("LANUPLOAD_19", "Çok fazla dosya yüklendi - fazla olanlar silindi.");
