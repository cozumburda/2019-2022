<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2023/07/22 13:54:57
|
|        $Author: Abbas $
+---------------------------------------------------------------+
*/
define("LAN_EFORM_001", "Değiştirmek için avatar'a tıklayın");
define("LAN_EFORM_002", "Avatar seçin");
define("LAN_EFORM_003", "VEYA");
define("LAN_EFORM_004", "Bu avatar'ı seçin");
define("LAN_EFORM_005", "Kullanılabilir Avatar yok");
define("LAN_EFORM_006", "Yalnızca Yönetici Bildirimi:[br][b][x][/b] klasörü boş.[br]Kullanıcıların içinden avatar seçmesi için birkaç varsayılan avatar resmini bu klasöre yükleyin.");
define("LAN_EFORM_007", "Medya Yöneticisi");
define("LAN_EFORM_008", "Görüntülenecek kolonları seçin");
define("LAN_EFORM_009", "Kolonları Görüntüle");
define("LAN_EFORM_010", "Hızlı Görünüm");
define("LAN_EFORM_011", "Kullanıcı Profiline Git");
define("LAN_EFORM_012", "Çoklu-Dil Alanı");
define("LAN_EFORM_013", "listeye git");
define("LAN_EFORM_014", "başka bir tane oluştur");
define("LAN_EFORM_015", "Mevcudu Düzenle");
define("LAN_EFORM_016", "Gönderdikten sonra:");
