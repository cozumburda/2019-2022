<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_notify.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/11 01:43:42 $
|     $Author: mcfly_e107 $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("NT_LAN_US_1", "Kullanıcı Kaydı");
define("NT_LAN_UV_1", "Kullanıcı Kaydı Doğrulandı");
define("NT_LAN_UV_2", "Kullanıcı kimliği:");
define("NT_LAN_UV_3", "Kullanıcı Giriş Adı:");
define("NT_LAN_UV_4", "Kullanıcı IP:");
define("NT_LAN_LI_1", "Kullanıcı Giriş Yaptı");
define("NT_LAN_LO_1", "Kullanıcı Oturumu Kapattı");
define("NT_LAN_LO_2", "siteden çıkış yaptı");
define("NT_LAN_FL_1", "Flood Yasağı");
define("NT_LAN_FL_2", "Flood nedeniyle IP adresi yasaklandı");
define("NT_LAN_SN_1", "Haber Öğesi Gönderildi");
define("NT_LAN_ML_1", "Toplu e-posta gönderimi tamamlandı");
define("NT_LAN_NU_1", "Güncellendi");
define("NT_LAN_ND_1", "Haber Öğesi Silindi");
define("NT_LAN_ND_2", "Silinen haber öğesi kimliği");
