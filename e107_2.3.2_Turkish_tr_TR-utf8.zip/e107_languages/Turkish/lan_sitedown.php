<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_sitedown.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Site geçici olarak kapalı");
define("LAN_SITEDOWN_00", "geçici olarak kapalıdır");
define("LAN_SITEDOWN_01", "Bazı temel bakımlar için siteyi geçici olarak kapattık. Bu çok uzun sürmeyecek - lütfen daha sonra tekrar kontrol edin. Bu rahatsızlıktan dolayı özür dileriz.");
