<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_error.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/28 12:10:30 $
|     $Author: streaky $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Hata");
define("LAN_ERROR_TITLE", "Oops.!");
define("LAN_ERROR_1", "Hata 401 - Kimlik Doğrulama Başarısız");
define("LAN_ERROR_2", "Ulaşmaya çalıştığınız URL, bir kullanıcı adı ve şifre gerektiriyor. Ya yanlış girdiniz ya da tarayıcınız bu özelliği desteklemiyor.");
define("LAN_ERROR_3", "Bu hata sayfasının yanlışlıkla gösterildiğini düşünüyorsanız, lütfen yönlendiren sayfanın yöneticisini bilgilendirin.");
define("LAN_ERROR_4", "Hata 403 - Erişim yasaklandı");
define("LAN_ERROR_5", "İstediğiniz belgeyi veya sayfayı görüntülemenize izin verilmiyor.");
define("LAN_ERROR_6", "Bu hata sayfasının yanlışlıkla gösterildiğini düşünüyorsanız, lütfen yönlendiren sayfanın yöneticisini bilgilendirin.");
define("LAN_ERROR_7", "Hata 404 - Belge Bulunamadı");
define("LAN_ERROR_9", "Bu hata mesajının yanlışlıkla gösterildiğini düşünüyorsanız lütfen yönlendiren sayfanın yöneticisini bilgilendirin.");
define("LAN_ERROR_10", "Hata 500 - iç sunucu hatası");
define("LAN_ERROR_11", "Sunucu, dahili bir hatayla veya yanlış yapılandırmayla karşılaştı ve isteğinizi tamamlayamadı");
define("LAN_ERROR_12", "Bu hata mesajının yanlışlıkla gösterildiğini düşünüyorsanız lütfen yönlendiren sayfanın yöneticisini bilgilendirin.");
define("LAN_ERROR_13", "Bilinmeyen - Hata");
define("LAN_ERROR_14", "Sunucu bir hatayla karşılaştı");
define("LAN_ERROR_15", "Bu hata mesajının yanlışlıkla gösterildiğini düşünüyorsanız lütfen yönlendiren sayfanın yöneticisini bilgilendirin.");
define("LAN_ERROR_16", "Bağlantı girişiminiz başarısız");
define("LAN_ERROR_17", "kaydedildi.");
define("LAN_ERROR_18", "Görünüşe göre, buraya şu kişi tarafından yönlendirildiniz:");
define("LAN_ERROR_19", "Ne yazık ki, o adreste eski bir bağlantı var.");
define("LAN_ERROR_20", "Bu sitenin ana sayfasına gitmek için lütfen buraya tıklayın");
define("LAN_ERROR_21", "İstenen URL bu sunucuda bulunamadı. İzlediğiniz bağlantı muhtemelen güncel değil.");
define("LAN_ERROR_22", "Bu sitenin arama sayfasına gitmek için lütfen buraya tıklayın");
define("LAN_ERROR_23", "Bağlanmaya çalışıyorsunuz :");
define("LAN_ERROR_24", "başarısızdı.");
define("LAN_ERROR_25", "[1]: Temel ayarlar veri tabanından okunamıyor - Çekirdek ayarlar mevcut ancak çalıştırılabilir hale getirilemiyor. Çekirdek yedeği geri yüklenmeye çalışılıyor...");
define("LAN_ERROR_26", "[2]: Çekirdek ayarlar veritabanından okunamadı - çekirdek ayarlar yok.");
define("LAN_ERROR_27", "[3]: Çekirdek ayarlar kaydedildi - yedekleme aktif.");
define("LAN_ERROR_28", "[4]: Çekirdek yedekleme bulunamadı. Veritabanınızın geçerli içeriğe sahip olup olmadığını kontrol edin.");
define("LAN_ERROR_29", "[5]: Alan(lar) boş bırakılmış. Lütfen gerekli alanları doldurun ve formu yeniden gönderin.");
define("LAN_ERROR_30", "[6]: MySQL ile geçerli bir bağlantı kurulamıyor. Lütfen e107_config.php dosyanızın doğru bilgileri içerdiğini kontrol edin.");
define("LAN_ERROR_31", "[7]: mySQL çalışıyor ancak [x] veritabanına bağlanılamadı.<br />Lütfen veritabanının var olduğunu ve yapılandırma dosyanızın doğru bilgileri içerdiğini kontrol edin.");
define("LAN_ERROR_32", "Yükseltmeyi tamamlamak için aşağıdaki metni e107_config.php dosyanıza kopyalayın:");
define("LAN_ERROR_33", "İşlem hatası! Ana sayfaya yönlendirileceksiniz.");
define("LAN_ERROR_34", "Bilinmeyen hata! Lütfen site yöneticisini bununla ilgili bilgilendirin:");
define("LAN_ERROR_35", "Hata 400 - Hatalı İstek");
define("LAN_ERROR_36", "Erişmeye çalıştığınız URL'de biçimlendirme hatası var.");
define("LAN_ERROR_37", "Hata Simgesi");
define("LAN_ERROR_38", "Maalesef site geçici bir arıza nedeniyle kullanılamıyor");
define("LAN_ERROR_39", "Lütfen birkaç dakika sonra tekrar deneyin");
define("LAN_ERROR_40", "Sorun devam ederse lütfen site yöneticisi ile iletişime geçiniz.");
define("LAN_ERROR_41", "Bildirilen hata şudur:");
define("LAN_ERROR_42", "Ek hata bilgileri:");
define("LAN_ERROR_43", "Sitesi geçici olarak kullanılamıyor");
define("LAN_ERROR_44", "Site logosu");
define("LAN_ERROR_45", "Şimdi ne yapabilirsin?");
define("LAN_ERROR_46", "Ayrıntılar için günlüğü kontrol edin.");
define("LAN_ERROR_47", "Doğrulama hatası: Haber başlığı boş olamaz!");
define("LAN_ERROR_48", "Doğrulama hatası: Haber SEF URL gerekli alandır ve boş olamaz!");
define("LAN_ERROR_49", "Doğrulama hatası: Haber SEF URL tekil alandır - girmiş olduğunuz değer daha önce kullanılmış! Lütfen farklı bir SEF URL değeri seçin.");
define("LAN_ERROR_50", "Doğrulama hatası: Haber kategorisi boş olamaz!");
