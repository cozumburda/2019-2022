<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_user_extended.php,v $
|     $Revision: 1.10 $
|     $Date: 2006/04/29 06:45:38 $
|     $Author: e107coders $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "Metin Kutusu");
define("UE_LAN_2", "Radyo Buton");
define("UE_LAN_3", "Açılır-Kapanır Menü");
define("UE_LAN_4", "VT Tablo Alanı");
define("UE_LAN_5", "Metin Alanı");
define("UE_LAN_6", "Tamsayı");
define("UE_LAN_8", "Dil");
define("UE_LAN_9", "Öntanımlı Liste");
define("UE_LAN_10", "İşaret kutuları");
define("UE_LAN_13", "Ülke");
define("UE_LAN_14", "Zengin Metin Alanı (WYSIWYG)");
define("UE_LAN_21", "Ad");
define("UE_LAN_22", "Türü");
define("UE_LAN_23", "Kullanım");
define("UE_LAN_HIDE", "Kullanıcılardan gizle");
define("UE_LAN_LOCATION", "Konum");
define("UE_LAN_LOCATION_DESC", "Kullanıcı Konumu");
define("UE_LAN_AIM", "AIM Adresi");
define("UE_LAN_AIM_DESC", "AIM Adresi");
define("UE_LAN_ICQ", "ICQ Numarası");
define("UE_LAN_ICQ_DESC", "ICQ Numarası");
define("UE_LAN_YAHOO", "Yahoo! Adresi");
define("UE_LAN_YAHOO_DESC", "Yahoo! Adresi");
define("UE_LAN_MSN", "-MSN-");
define("UE_LAN_MSN_DESC", "MSN Adresi");
define("UE_LAN_HOMEPAGE", "Anasayfa");
define("UE_LAN_HOMEPAGE_DESC", "Kullanıcı anasayfası (url)");
define("UE_LAN_BIRTHDAY", "Doğum Tarihi");
define("UE_LAN_BIRTHDAY_DESC", "Doğum Tarihi");
define("UE_LAN_LANGUAGE", "Dil");
define("UE_LAN_LANGUAGE_DESC", "Kullanıcı Dili");
define("UE_LAN_COUNTRY", "Ülke");
define("UE_LAN_COUNTRY_DESC", "Kullanıcının Ülkesi");
define("UE_LAN_TIMEZONE", "Zaman Dilimi");
define("UE_LAN_TIMEZONE_DESC", "Kullanıcı Zaman Dilimi (önceden tanımlanmış listeden)");
define("LAN_UE_FAIL_HOMEPAGE", "Anasayfa ayarı için geçersiz giriş");
define("UE_LAN_SKYPE", "-Skype-");
define("UE_LAN_SKYPE_DESC", "Skype adresi");
define("UE_LAN_GENDER", "Cinsiyet");
define("UE_LAN_GENDER_DESC", "Cinsiyet");
define("UE_LAN_MALE", "Erkek");
define("UE_LAN_FEMALE", "Kadın");
define("UE_LAN_COMMENT", "Yorumlar");
define("UE_LAN_COMMENT_DESC", "Yorum kutusu");
