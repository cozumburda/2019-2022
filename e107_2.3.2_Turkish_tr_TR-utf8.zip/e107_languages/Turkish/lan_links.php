<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_links.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Bağlantılar");
define("LAN_61", "Bağlantı kategorileri");
define("LAN_62", "Kategoriler");
define("LAN_63", "Kategori");
define("LAN_64", "bu kategoride");
define("LAN_65", "bağlantı");
define("LAN_66", "bağlantılar");
define("LAN_67", "Bütün Bağlantıları Göster");
define("LAN_68", "düzenle");
define("LAN_69", "sil");
define("LAN_86", "Kategori:");
define("LAN_88", "Referanslar:");
define("LAN_89", "Yönetici: ");
define("LAN_90", "bu kategoriye yeni bağlantı ekle");
define("LAN_91", "yeni kategori ekle");
define("LAN_92", "Bir bağlantı gönder");
define("LAN_93", "Bağlantınız site yöneticileri tarafından incelenip onaylandıktan sonra bağlantılar sayfasında görüntülenecektir..");
define("LAN_94", "Bağlantı Adı:");
define("LAN_95", "Bağlantı Yolu (URL):");
define("LAN_96", "Bağlantı Açıklaması:");
define("LAN_97", "URL bağlantı butonu:");
define("LAN_98", "Bağlantı gönder");
define("LAN_99", "Teşekkürler");
define("LAN_100", "Bağlantınız kaydedildi ve site yöneticisi tarafından gözden geçirilecek.");
define("LAN_101", "Bağlantıya gitmek için tıklayın");
define("LAN_102", "Mevcut");
define("LAN_103", ".");
define("LAN_104", ".");
define("LAN_105", "toplam");
define("LAN_106", "Altı çizili alanların girilmesi zorunludur.");
define("LAN_Links_1", "Toplam Bağlantı");
define("LAN_Links_2", "Toplam Etkin Bağlantı");
define("LAN_LINKS_3", "Anonim");


?>