<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_date.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/24 11:23:45 $
|     $Author: mcfly_e107 $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LANDT_01", "yıl");
define("LANDT_02", "ay");
define("LANDT_03", "hafta");
define("LANDT_04", "gün");
define("LANDT_05", "saat");
define("LANDT_06", "dakika");
define("LANDT_07", "saniye");
define("LANDT_01s", "yıl");
define("LANDT_02s", "ay");
define("LANDT_03s", "hafta");
define("LANDT_04s", "gün");
define("LANDT_05s", "saat");
define("LANDT_06s", "dakika");
define("LANDT_07s", "saniye");
define("LANDT_08", "dk.");
define("LANDT_08s", "dk.");
define("LANDT_09", "sn.");
define("LANDT_09s", "sn.");
define("LANDT_AGO", "önce");
define("LANDT_IN", "içinde");
define("LANDT_10", "Sadece şimdi");
define("LANDT_XAGO", "[x] önce");
define("LANDT_INX", "içinde [x]");
