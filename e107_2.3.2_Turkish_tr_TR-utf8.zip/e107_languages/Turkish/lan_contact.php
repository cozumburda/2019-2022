<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_contact.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/25 18:01:18 $
|     $Author: e107coders $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LAN_CONTACT_00", "Bize Ulaşın");
define("LAN_CONTACT_01", "İletişim Detayları");
define("LAN_CONTACT_02", "İletişim Formu");
define("LAN_CONTACT_03", "İsminizi Giriniz");
define("LAN_CONTACT_04", "Mail Adresinizi Giriniz");
define("LAN_CONTACT_05", "Mesaj Konusu");
define("LAN_CONTACT_06", "Mesaj");
define("LAN_CONTACT_07", "Bu mesajın bir kopyasını kendi adresinize e-posta ile gönderin");
define("LAN_CONTACT_08", "Gönder");
define("LAN_CONTACT_09", "Mesajınız gönderildi.");
define("LAN_CONTACT_10", "Mesajınız gönderilirken bir sorun oluştu.");
define("LAN_CONTACT_11", "Lütfen e-posta adresinizi kontrol edin ve iletişim formunu tekrar gönderin.");
define("LAN_CONTACT_12", "Mesajınız çok kısa.");
define("LAN_CONTACT_13", "Lütfen bir konu yazın.");
define("LAN_CONTACT_14", "Mesajı gönder");
define("LAN_CONTACT_15", "Yanlış kod girildi");
define("LAN_CONTACT_16", "Bu formu kullanmak için [kayıtlı] olmanız ve oturum açmış olmanız gerekir.");
define("LAN_CONTACT_17", "Lütfen İsminizi Girin.");
define("LAN_CONTACT_18", "Lütfen e-mail Adresinizi Girin.");
define("LAN_CONTACT_19", "Lütfen e-mailiniz için bir konu girin.");
define("LAN_CONTACT_20", "Lütfen bizim için mesajınızı giriniz.");
define("LAN_CONTACT_21", "Paylaştığım bilgilerin işlenmesi için bu web sitesine gönderdiğim bilgilerimi saklamasına izin veriyorum.");
define("LAN_CONTACT_22", "Gizlilik Politikası");
define("LAN_CONTACT_23", "Gizlilik İlkelerimize buradan ulaşabilirsiniz: [x]");
define("LAN_CONTACT_24", "KVKK-GDPR Sözleşmesi");
