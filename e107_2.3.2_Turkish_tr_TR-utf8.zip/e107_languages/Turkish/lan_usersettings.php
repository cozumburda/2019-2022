<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_usersettings.php,v $
|     $Revision: 1.9 $
|     $Date: 2005/12/29 20:00:56 $
|     $Author: mcfly_e107 $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Kullanıcı Ayarları");
define("MAX_AVWIDTH", "Avatar boyutu en fazla (gen. x yük.) :");
define("MAX_AVHEIGHT", "x");
define("LAN_USET_1", "Avatarınız çok geniş");
define("LAN_USET_2", "İzin verilen maksimum genişlik");
define("LAN_USET_3", "Avatarınız çok yüksek");
define("LAN_USET_4", "İzin verilen maksimum yükseklik");
define("LAN_USET_7", "Çeşitli");
define("LAN_USET_8", "Kullanıcı imzası");
define("LAN_USET_9", "Gerekli alanlardan bazıları (* ile işaretlenmiş) ayarlarınızda eksik.");
define("LAN_USET_10", "Devam etmek için lütfen ayarlarınızı şimdi güncelleyin.");
define("LAN_USET_11", "Bu kullanıcı adı kabul edilmiyor, lütfen farklı bir kullanıcı adı seçin");
define("LAN_USET_12", "Bu görünen ad çok kısa. Lütfen başka bir tane seçin");
define("LAN_USET_13", "Kullanıcı adında geçersiz karakterler var. Lütfen başka bir tane seçin");
define("LAN_USET_14", "Giriş adı çok uzun. Lütfen başka bir tane seçin");
define("LAN_USET_15", "Görünen adı çok uzun. Lütfen başka bir tane seçin");
define("LAN_USET_16", "Başka bir fotoğraf yüklemeden mevcut fotoğrafı silmek için kutuyu seçin");
define("LAN_USET_17", "Görünen ad kullanılıyor. Lütfen başka bir tane seçin");
define("LAN_USET_18", "Yönetici tarafından kullanıcı bilgileri değiştirildi: [x], oturum açma adı: [y]");
define("LAN_USET_20", "Kullanıcının oturum açma adını veya e-posta adresini değiştiriyorsanız, kullanıcının şifresini de değiştirmeniz gerekir.");
define("LAN_USET_21", "Lütfen şifrenizi tekrar girerek değişiklikleri doğrulayın:");
define("LAN_USET_23", "Mevcut şifreyi kullanmak için boş bırakın");
define("LAN_USET_24", "Yeni şifre:");
define("LAN_USET_25", "Yeni şifreyi yeniden yazın:");
define("LAN_USET_26", "Avatarınızı yükleyin");
define("LAN_USET_27", "Fotoğrafınızı yükleyin");
define("LAN_USET_28", "Bu, profil sayfanızda gösterilecek");
define("LAN_USET_30", "Bu nedir?");
define("LAN_USET_31", "Kayıt bilgileri");
define("LAN_USET_32", "Lütfen dikkat: Bu sunucuya yüklenen ve yöneticiler tarafından uygun görülmeyen resimler derhal silinecektir.");
define("LAN_USET_33", "Sitede saklanan avatarı seçin");
define("LAN_USET_34", "Dışarıdan avatar kullan");
define("LAN_USET_35", "Lütfen resmin tam adresini yazın");
define("LAN_USET_36", "Bu sitede saklanan avatarları görmek için butona tıklatın");
define("LAN_USET_37", "Ayarları Kaydet");
define("LAN_USET_38", "Avatar seçin");
define("LAN_USET_39", "Kullanıcı ayarlarını güncelleştir");
define("LAN_USET_40", "İki şifre eşleşmiyor");
define("LAN_USET_41", "Ayarlar güncellendi ve veritabanına kaydedildi.");
define("LAN_USET_42", "Doğrulama anahtarında uyumsuzluk");
define("LAN_USET_43", "Kullanıcı verileri güncelleştirilirken hata oluştu");
define("LAN_USET_5", "Abone olunan");
define("LAN_USET_6", "Posta listemize/listelerimize ve/veya bu sitenin bölümlerine abone olun.");
define("LAN_USET_50", "Hesabı Sil");
define("LAN_USET_51", "Emin misiniz? Bu işlem geri alınamaz! Tamamlandıktan sonra bu site ile paylaştığınız kişisel bilgileriniz ve hesabınız kalıcı olarak silinecek ve artık giriş yapamayacaksınız.");
define("LAN_USET_52", "[x] adresine bir onay e-postası gönderildi. Hesabınızı kalıcı olarak silmek için lütfen e-postadaki linke tıklayın.");
define("LAN_USET_53", "Hesap Silme Onayı");
define("LAN_USET_54", "Doğrulama Maili Gönderildi");
define("LAN_USET_55", "Hesabınızın silinmesini tamamlamak için lütfen aşağıdaki linke tıklayın.");
define("LAN_USET_56", "Hesabınız başarılı şekilde silindi.");
