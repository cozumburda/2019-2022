<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_userposts.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/11/30 19:36:50 $
|     $Author: sweetas $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Kullanıcı Gönderileri");
define("UP_LAN_0", "[x] İçin Tüm Forum Gönderileri");
define("UP_LAN_1", "[x] İçin Tüm Yorumlar");
define("UP_LAN_2", "Konu");
define("UP_LAN_3", "Görüntüleme");
define("UP_LAN_4", "Cevaplar");
define("UP_LAN_5", "Son Mesaj");
define("UP_LAN_6", "Konular");
define("UP_LAN_7", "Yorum Yok");
define("UP_LAN_8", "Gönderi Yok");
define("UP_LAN_9", "-on-");
define("UP_LAN_10", "Yanıt");
define("UP_LAN_11", "Gönderen");
define("UP_LAN_12", "Ara");
define("UP_LAN_14", "Forum Gönderileri");
define("UP_LAN_15", "Yanıt");
define("UP_LAN_16", "IP Adresi");
