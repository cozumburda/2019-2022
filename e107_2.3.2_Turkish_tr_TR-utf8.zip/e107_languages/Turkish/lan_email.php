<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_email.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/02/17 23:49:04 $
|     $Author: lisa_ $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LAN_EMAIL_1", "Kimden:");
define("LAN_EMAIL_2", "Gönderenin IP adresi:");
define("LAN_EMAIL_3", "E-postayla gönderilen öğe");
define("LAN_EMAIL_4", "Epostayı Gönder");
define("LAN_EMAIL_5", "Öğeyi bir arkadaşına e-postayla gönder");
define("LAN_EMAIL_6", "Bu öğeyle ilgilenebileceğini düşündüm");
define("LAN_EMAIL_7", "birine eposta gönder");
define("LAN_EMAIL_8", "Yorum");
define("LAN_EMAIL_9", "Üzgünüm - eposta gönderilemedi");
define("LAN_EMAIL_10", "Mail gönderildi");
define("LAN_EMAIL_11", "Eposta gönderildi");
define("LAN_EMAIL_13", "Makaleyi bir arkadaşına e-posta ile gönder");
define("LAN_EMAIL_14", "Haber öğesini bir arkadaşınıza e-posta ile gönderin");
define("LAN_EMAIL_15", "Kullanıcı Adı:");
define("LAN_EMAIL_106", "Bu geçerli bir e-posta adresi gibi görünmüyor");
define("LAN_EMAIL_185", "Makaleyi Gönder");
define("LAN_EMAIL_186", "Haberi Gönder");
define("LAN_EMAIL_187", "Gönderilecek eposta adresi");
define("LAN_EMAIL_188", "Bu haberin ilginizi çekebileceğini düşündüm.");
define("LAN_EMAIL_189", "Bu makalenin ilginizi çekebileceğini düşündüm.");
define("LAN_EMAIL_190", "Görünen Kodu girin");
define("LAN_SOCIAL_LINK_CHK", "Bu bağlantıyı kontrol edin:");
