﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_request.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/09 15:38:12 $
|     $Author: e107coders $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/

define("LAN_dl_61", "İndirme Hatası");
define("LAN_dl_62", "Bu dosyayı indirmeniz engellendi, indirme kotasını aşmışsınız.");
define("LAN_dl_63", "Bu dosyayı indirmek için gerekli izne sahip değilsiniz.");
define("LAN_dl_64", "Geri");
define("LAN_dl_65", "Dosya Bulunamadı");

?>
