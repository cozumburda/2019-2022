<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_search.php,v $
|     $Revision: 1.12 $
|     $Date: 2005/09/19 22:09:06 $
|     $Author: sweetas $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Ara");
define("LAN_140", "Üyeler");
define("LAN_192", "Bütün kategoriler");
define("LAN_193", "Etkinlik Takvimi");
define("LAN_194", "Bütün kategoriler");
define("LAN_195", "Aranıyor");
define("LAN_196", "eşleşenler");
define("LAN_197", "İndirmeler");
define("LAN_198", "Eşleşme bulunamadı");
define("LAN_199", "Ara:");
define("LAN_416", "Bu sayfaya erişim için giriş yapmalısınız");
define("LAN_417", "Arama terimleri en az [x] karakter olmalıdır.");
define("LAN_418", "Diğer Sayfalar");
define("LAN_SEARCH_1", "Hepsini Seç");
define("LAN_SEARCH_2", "Hepsini Bırak");
define("LAN_SEARCH_3", "Gönderilen :");
define("LAN_SEARCH_4", "Haber başlığında bulunan eşleşme");
define("LAN_SEARCH_5", "Haber metninde bulunan eşleşme");
define("LAN_SEARCH_6", "Genişletilmiş haber metninde bulunan eşleşme");
define("LAN_SEARCH_7", "Tarafından Gönderildi");
define("LAN_SEARCH_8", "-on-");
define("LAN_SEARCH_9", "Başlıksız");
define("LAN_SEARCH_11", "Sonuçlar");
define("LAN_SEARCH_12", "-of-");
define("LAN_SEARCH_13", "-in-");
define("LAN_SEARCH_14", "Kategori:");
define("LAN_SEARCH_15", "Yazar:");
define("LAN_SEARCH_17", "Üzgünüz, arama her seferinde bir aramayla sınırlıdır.");
define("LAN_SEARCH_18", " saniye.");
define("LAN_SEARCH_19", "Burada Ara:");
define("LAN_SEARCH_20", "Yetkilendirme Gerekli");
define("LAN_SEARCH_21", "Bu sayfayı görüntüleme yetkiniz yok.");
define("LAN_SEARCH_22", "Bütün Alanlar");
define("LAN_SEARCH_23", "Gelişmiş Sorgu Formu");
define("LAN_SEARCH_24", "Kelime(ler) içermelidir");
define("LAN_SEARCH_25", "Kelime(ler) içermemelidir");
define("LAN_SEARCH_26", "Tam tabiri");
define("LAN_SEARCH_27", "ile başlayan kelime(ler)");
define("LAN_SEARCH_28", "Hiçbirinde Gelişmiş Arama Yok");
define("LAN_SEARCH_29", "Temel");
define("LAN_SEARCH_30", "Gelişmiş");
define("LAN_SEARCH_31", "Gelişmiş Arama Yok");
define("LAN_SEARCH_32", "Aşağıdaki kelimeler arama dışında bırakıldı");
define("LAN_SEARCH_33", "Aşağıdaki kelimeler arama dışında bırakıldı");
define("LAN_SEARCH_34", "Daha Yeniler");
define("LAN_SEARCH_35", "Daha Eskiler");
define("LAN_SEARCH_36", "Herhangi bir zaman");
define("LAN_SEARCH_37", "Bir gün");
define("LAN_SEARCH_38", "İki gün");
define("LAN_SEARCH_39", "Üç gün");
define("LAN_SEARCH_40", "Bir hafta");
define("LAN_SEARCH_41", "İki hafta");
define("LAN_SEARCH_42", "Üç Hafta");
define("LAN_SEARCH_43", "Bir ay");
define("LAN_SEARCH_44", "İki ay");
define("LAN_SEARCH_45", "Üç ay");
define("LAN_SEARCH_46", "Yarım yıl");
define("LAN_SEARCH_47", "Bir yıl");
define("LAN_SEARCH_48", "İki yıl");
define("LAN_SEARCH_49", "Üç yıl");
define("LAN_SEARCH_50", "Yayınlanma tarihi");
define("LAN_SEARCH_51", "Bütün kategoriler");
define("LAN_SEARCH_52", "Eşleştir");
define("LAN_SEARCH_53", "Tüm Öğe");
define("LAN_SEARCH_54", "Sadece Başlık");
define("LAN_SEARCH_55", "Haber kategorilerinde ara");
define("LAN_SEARCH_56", "Bütün Haber Kategorileri");
define("LAN_SEARCH_57", "Yorumlar şuraya gönderildi:");
define("LAN_SEARCH_58", "Tüm Alanlar");
define("LAN_SEARCH_59", "Tüm Yorumlar");
define("LAN_SEARCH_60", "Yorumlar şuraya gönderildi:");
define("LAN_SEARCH_61", "Yazar tarafından");
define("LAN_SEARCH_62", "Katılma tarihi");
define("LAN_SEARCH_63", "Kategoride ara");
define("LAN_SEARCH_64", "Tüm İndirme Kategorileri");
define("LAN_SEARCH_65", "İndirmeler");
define("LAN_SEARCH_66", "Eklenme tarihi");
define("LAN_SEARCH_67", "Tüm indirme ayrıntıları");
define("LAN_SEARCH_69", "İlişki");
define("LAN_SEARCH_70", "İndirme öğesi gönderildi");
define("LAN_SEARCH_71", "Habere cevap olarak gönderildi");
define("LAN_SEARCH_72", "İmza");
define("LAN_SEARCH_73", "İmza yok.");
define("LAN_SEARCH_74", "Katıldı");
define("LAN_SEARCH_75", "Arama tipi");
define("LAN_SEARCH_76", "Sayfaya Gönderilen");
define("LAN_SEARCH_77", "Profil sayfasında yayınlandı");
define("LAN_SEARCH_98", "Haberler");
define("LAN_SEARCH_201", "Lütfen arama sorgunuzu yeniden tanımlayın");
define("LAN_SEARCH_202", "Gelişmiş Moda Geç");
