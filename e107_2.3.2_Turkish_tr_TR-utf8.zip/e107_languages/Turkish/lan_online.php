<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_online.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("ONLINE_EL1", "Misafirler:");
define("ONLINE_EL2", "Üyeler:");
define("ONLINE_EL3", "Bu sayfada:");
define("ONLINE_EL4", "Çevrimiçi");
define("ONLINE_EL5", "Üyeler");
define("ONLINE_EL6", "En yeni üye");
define("ONLINE_EL7", "görüntüleniyor");
define("ONLINE_EL8", "En Çok Çevrimiçi Olan:");
define("ONLINE_EL9", "-on-");
define("ONLINE_EL10", "Üye Adı");
define("ONLINE_EL11", "Görüntülenen Sayfa");
define("ONLINE_EL12", "Yanıtla");
define("ONLINE_EL13", "-Forum-");
define("ONLINE_EL14", "Konu");
define("ONLINE_EL15", "Sayfa");
define("ONLINE_EL16", "Bilgi yok");
define("CLASSRESTRICTED", "Sınıf Kısıtlı Sayfa");
define("CHAT", "Sohbet");
define("DOWNLOAD", "İndirmeler");
define("EMAIL", "email.php");
define("FORUM", "Ana Forum İndeksi");
define("LINKS", "Bağlantılar");
define("NEWS", "Haberler");
define("OLDPOLLS", "Eski Anketler");
define("POLLCOMMENT", "Anket");
define("PRINTPAGE", "Yazdır");
define("LOGIN", "Giriş");
define("SEARCH", "Aranıyor");
define("STATS", "Site İstatistikleri");
define("SUBMITNEWS", "Haber Gönder");
define("UPLOAD", "Yüklemeler");
define("USERPAGE", "Kullanıcı Profilleri");
define("USERSETTINGS", "Kullanıcı Ayarları");
define("ONLINE", "Çevrimiçi Kullanıcılar");
define("LISTNEW", "Yeni Öğeleri Listele");
define("USERPOSTS", "Kullanıcı Gönderileri");
define("SUBCONTENT", "İçerik Gönder");
define("TOP", "En İyi Posterler/En Aktif Konular");
define("ADMINAREA", "Yönetici Paneli");
define("BUGTRACKER", "Hata takipçisi");
define("EVENT", "Etkinlik Listesi");
define("CALENDAR", "Etkinlik Takvimi");
define("FAQ", "SSS");
define("PM", "Özel Mesajlaşma");
define("SURVEY", "Anket");
define("ARTICLE", "Makale");
define("CONTENT", "İçerik Sayfası");
define("REVIEW", "Gözden Geçir");
define("OTHER", "Diğer sayfa:");
