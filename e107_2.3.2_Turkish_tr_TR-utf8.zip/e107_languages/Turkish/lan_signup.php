<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_signup.php,v $
|     $Revision: 1.17 $
|     $Date: 02-Oca-2008 04:50 PM $
|     $Author: e107coders $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Kayıt");
define("LAN_EMAIL_01", "Sevgili");
define("LAN_EMAIL_04", "Lütfen bu e-postayı kendi bilgileriniz için saklayın.");
define("LAN_EMAIL_05", "Parolanız şifrelenmiştir ve yanlış saklarsanız veya unutursanız geri alınamaz. Böyle bir durumda yeni bir şifre talep edebilirsiniz.");
define("LAN_EMAIL_06", "Kayıt için teşekkür ederiz.");
define("LAN_SIGNUP_1", "Minimum");
define("LAN_SIGNUP_2", "karakter");
define("LAN_SIGNUP_3", "Kod doğrulaması hatalı.");
define("LAN_SIGNUP_4", "Parolanız en az");
define("LAN_SIGNUP_5", " karakter uzunluğunda");
define("LAN_SIGNUP_8", "Teşekkürler!");
define("LAN_SIGNUP_9", "Devam edilemiyor.");
define("LAN_SIGNUP_11", "..");
define("LAN_SIGNUP_12", "Kaybetmeniz durumunda geri alınamayacakları için lütfen kullanıcı adınızı ve şifrenizi güvenli bir yerde yazılı olarak saklayın.");
define("LAN_SIGNUP_13", "Artık Oturum Aç kutusundan veya [buradan] oturum açabilirsiniz.");
define("LAN_SIGNUP_14", "buradan");
define("LAN_SIGNUP_15", "Lütfen ana site yöneticisiyle iletişime geçin");
define("LAN_SIGNUP_16", "Yardıma ihtiyacınız varsa.");
define("LAN_SIGNUP_17", "Lütfen 13 yaşında veya daha büyük olduğunuzu onaylayın.");
define("LAN_SIGNUP_18", "Kaydınız alındı ve aşağıdaki giriş bilgileriyle oluşturuldu:");
define("LAN_SIGNUP_21", "Hesabınız şu anda etkin değil. Hesabınızı etkinleştirmek için lütfen aşağıdaki bağlantıya gidin:");
define("LAN_SIGNUP_22", "buraya tıklayın");
define("LAN_SIGNUP_23", "giriş yapın.");
define("LAN_SIGNUP_24", "Kayıt olduğunuz için teşekkür ederiz");
define("LAN_SIGNUP_25", "Avatarını yükle");
define("LAN_SIGNUP_26", "Fotoğrafını yükle");
define("LAN_SIGNUP_30", "E-posta adresinizin bu sitede görüntülenmesini istemiyorsanız, lütfen 'E-posta adresi gizlensin mi?' için seçeneklerden 'Evet'i seçin.");
define("LAN_SIGNUP_34", "Lütfen dikkat: Bu sunucuya yüklenen ve yöneticiler tarafından uygun görülmeyen görseller derhal silinecektir.");
define("LAN_SIGNUP_36", "Kullanıcı bilgileriniz oluşturulurken bir hata oluştu, lütfen site yöneticisi ile iletişime geçin.");
define("LAN_SIGNUP_37", "Bu kayıt aşaması tamamlandı. Site yöneticisinin üyeliğinizi onaylaması gerekecektir. Bu yapıldıktan sonra, üyeliğinizin onaylandığını bildiren bir onay e-postası alacaksınız.");
define("LAN_SIGNUP_38", "İki farklı e-posta adresi girdiniz. Lütfen iki alana da geçerli aynı e-posta adresi girin");
define("LAN_SIGNUP_39", "Email Adresinizi tekrar yazın:");
define("LAN_SIGNUP_40", "Aktivasyon gerekli değil");
define("LAN_SIGNUP_41", "Hesabınız zaten aktif.");
define("LAN_SIGNUP_42", "Bir sorun oluştu, kayıt maili gönderilemedi, lütfen site yöneticisi ile iletişime geçin.");
define("LAN_SIGNUP_43", "Eposta gönderildi");
define("LAN_SIGNUP_44", "Aktivasyon epostası gönderildi :");
define("LAN_SIGNUP_45", "Lütfen gelen kutunuzu kontrol edin.");
define("LAN_SIGNUP_47", "Aktivasyon epostasını yeniden yolla");
define("LAN_SIGNUP_48", "Kullanıcı adı veya Eposta");
define("LAN_SIGNUP_49", "Yanlış e-posta adresiyle kaydolduysanız ve yukarıdaki kutuyu doldurursanız, buraya yeni bir e-posta adresi ve şifrenizi yazın:");
define("LAN_SIGNUP_50", "Yeni Eposta");
define("LAN_SIGNUP_51", "Eski Şifre");
define("LAN_SIGNUP_53", "doğrulama testini geçemeyen alan");
define("LAN_SIGNUP_54", "Bilgilerinizi doldurup kayıt olmak için buraya tıklayın");
define("LAN_SIGNUP_58", "Kayıt Önizlemesi");
define("LAN_SIGNUP_59", "**** Bağlantı çalışmıyorsa, lütfen bir kısmının bir sonraki satıra taşmadığını kontrol edin. ****");
define("LAN_SIGNUP_60", "Kayıt e-postasının yeniden gönderilmesi istendi");
define("LAN_SIGNUP_61", "Gönderme başarılı");
define("LAN_SIGNUP_62", "Gönderme başarısız");
define("LAN_SIGNUP_63", "Şifre sıfırlama e-postasının yeniden gönderilmesi istendi");
define("LAN_SIGNUP_64", "Bu geçerli bir kullanıcı bilgisi gibi görünmüyor");
define("LAN_SIGNUP_65", "Aşağıdaki oturum açma adı size atandı");
define("LAN_SIGNUP_66", "Lütfen bunu bir yere not edin.");
define("LAN_SIGNUP_67", "Bu, kayıttan sonra sistem tarafından atanacaktır.");
define("LAN_SIGNUP_71", "Hesap kayıtları için site sınırına ulaştınız. Lütfen diğer hesaplarınızdan birini kullanarak giriş yapın.");
define("LAN_SIGNUP_72", "[sitename]'na kaydolduğunuz için teşekkürler! Az önce size [email] adresine bir onay e-postası gönderdik. Kaydınızı tamamlamak ve hesabınızı etkinleştirmek için lütfen e-postanızdaki onay bağlantısına tıklayın.");
define("LAN_SIGNUP_73", "Teşekkür ederiz!");
define("LAN_SIGNUP_74", "Hesabınız şimdi etkinleştirildi, lütfen");
define("LAN_SIGNUP_75", "Kayıt etkinleştirildi");
define("LAN_SIGNUP_76", "Teşekkür ederiz! Artık kayıtlı bir üyesiniz");
define("LAN_SIGNUP_77", "Bu site, 1998 tarihli Çocukların Çevrimiçi Gizliliğini Koruma Yasası'na (COPPA) uygundur ve bu nedenle, ebeveynlerinden veya velilerinden yazılı bir izin belgesi olmadan 13 yaşın altındaki kullanıcıların kayıtlarını kabul edemez. Daha fazla bilgi için mevzuatı okuyabilirsiniz.");
define("LAN_SIGNUP_78", "Kayıt");
define("LAN_SIGNUP_79", "Üye ol");
define("LAN_SIGNUP_80", "Lütfen bilgilerinizi aşağıya giriniz.");
define("LAN_SIGNUP_81", "Kullanıcı adı:");
define("LAN_SIGNUP_82", "oturum açmak için kullandığınız ad");
define("LAN_SIGNUP_83", "Şifre:");
define("LAN_SIGNUP_84", "Şifreyi yeniden yazın:");
define("LAN_SIGNUP_85", "Kullanıcı adları ve parolalar büyük/küçük harfe duyarlıdır.");
define("LAN_SIGNUP_89", "Görünen ad:");
define("LAN_SIGNUP_90", "sitede gösterilecek isim");
define("LAN_SIGNUP_91", "Gerçek ad:");
define("LAN_SIGNUP_93", "İmza:");
define("LAN_SIGNUP_94", "Avatar-:");
define("LAN_SIGNUP_95", "Resimde görünen kodunu girin");
define("LAN_SIGNUP_96", "Kayıt detayları için");
define("LAN_SIGNUP_97", "Hoş geldiniz");
define("LAN_SIGNUP_98", "Email adresinizi doğrulayın");
define("LAN_SIGNUP_99", "Karşılaşılan Problem");
define("LAN_SIGNUP_100", "Yönetici Onayı Bekliyor");
define("LAN_SIGNUP_101", "Kayıtların güncellenmesi başarısız oldu - lütfen site yöneticisiyle iletişime geçin");
define("LAN_SIGNUP_103", "Şu anda IP adresini kullanan çok fazla kullanıcı var:");
define("LAN_SIGNUP_105", "İsteğiniz gerçekleştirilemiyor - lütfen site yöneticisiyle iletişime geçin");
define("LAN_SIGNUP_106", "İsteğinizle ilgili işlem yapılamıyor - Sitede daha önce bir hesabınız var mıydı?");
define("LAN_LOGINNAME", "Kullanıcı Adı");
define("LAN_USERNAME", "Görünen Ad");
define("LAN_SIGNUP_107", "Parola en az [x] karakter olmalı ve en az bir BÜYÜK HARF ve bir rakam içermelidir");
define("LAN_SIGNUP_108", "Geçerli bir e-posta adresi olmalı");
define("LAN_SIGNUP_109", "Büyük/küçük harf duyarlıdır ve boşluk içermemelidir.");
define("LAN_SIGNUP_110", "Tam adınız");
define("LAN_SIGNUP_111", "Resme bir URL girin veya mevcut bir avatar seçin.");
define("LAN_SIGNUP_112", "Şu anda Ana Yönetici olarak oturum açtınız.");
define("LAN_SIGNUP_113", "Abonelik(ler)");
define("LAN_SIGNUP_114", "Kullanıcı kaydı şu anda devre dışı.");
define("LAN_SIGNUP_115", "Etkinleştirme E-postasını Gözden geçir");
define("LAN_SIGNUP_116", "Formu Gönderdikten Sonra Gözden geçir");
define("LAN_SIGNUP_117", "Test Aktivasyonu Gönder");
define("LAN_SIGNUP_118", "[x]'e");
define("LAN_SIGNUP_119", "E-posta gönderme");
define("LAN_SIGNUP_120", "-OR-");
define("LAN_SIGNUP_121", "Farklı e-posta adresini kullanın");
define("LAN_SIGNUP_122", "Gizlilik Politikası");
define("LAN_SIGNUP_123", "Şartlar ve koşullar");
define("LAN_SIGNUP_124", "Kaydolarak [x] ve [y] hükümlerimizi kabul etmiş olursunuz.");
define("LAN_SIGNUP_125", "Minimum [x] karakter.");
