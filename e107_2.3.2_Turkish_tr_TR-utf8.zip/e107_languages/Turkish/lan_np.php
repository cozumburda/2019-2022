<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_np.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("NP_1", "Önceki sayfa");
define("NP_2", "Sonraki sayfa");
define("LAN_NP_FIRST", "ilk");
define("LAN_NP_URLFIRST", "İlk sayfaya git");
define("LAN_NP_PREVIOUS", "önceki");
define("LAN_NP_URLPREVIOUS", "Önceki sayfaya git");
define("LAN_NP_NEXT", "Sonraki");
define("LAN_NP_URLNEXT", "Sonraki sayfaya git");
define("LAN_NP_LAST", "son");
define("LAN_NP_URLLAST", "Son sayfaya git");
define("LAN_NP_GOTO", "[x] sayfasına git");
define("LAN_NP_URLCURRENT", "Şu anda görüntüleniyor");
define("NP_CAPTION", "[y] nin [x] sayfası");
