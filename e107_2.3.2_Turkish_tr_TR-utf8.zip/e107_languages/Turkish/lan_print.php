<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_print.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/02/17 23:49:04 $
|     $Author: lisa_ $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LAN_PRINT_303", "Bu haber öğesinden");
define("LAN_PRINT_307", "Sayfayı yazdır");
define("LAN_PRINT_1", "yazıcı dostu");
