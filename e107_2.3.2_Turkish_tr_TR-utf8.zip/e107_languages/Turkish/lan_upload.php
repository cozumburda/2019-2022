<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_upload.php,v $
|     $Revision: 1.1 $
|     $Date: 02-Oca-2008 04:53 PM $
|     $Author: e107coders $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Yükleme");
define("LAN_UL_001", "Geçersiz eposta adresi");
define("LAN_UL_002", "Dosyaları bu sunucuya yüklemek için gerekli izinlere sahip değilsiniz.");
define("LAN_UL_020", "Hata");
define("LAN_UL_021", "Yükleme Başarısız");
define("LAN_UL_022", "Dosya türüne göre değişebilir");
define("LAN_UL_023", "Türü");
define("LAN_UL_024", "En büyük boyut");
define("LAN_UL_025", "Yüklemelere izin verilmiyor");
define("LAN_UL_026", "-");
define("LAN_UL_027", "-");
define("LAN_UL_032", "Bir Kategori Seçmelisiniz");
define("LAN_UL_033", "Geçerli bir email adresi girmelisiniz");
define("LAN_UL_034", "Dosya ismini belirtmelisiniz");
define("LAN_UL_035", "Bir açıklama girmelisiniz");
define("LAN_UL_036", "Yüklenecek dosyayı belirtmelisiniz");
define("LAN_UL_037", "Bir Kategori belirtmelisiniz");
define("LAN_UL_038", "-");
define("LAN_61", "Adınız:");
define("LAN_112", "Email Adresiniz:");
define("LAN_144", "Web site Adresiniz:");
define("LAN_402", "Bu sunucuya dosya yüklemek için kayıtlı üye olmalısınız.");
define("LAN_404", "Yüklemeniz bir yönetici tarafından incelenecek ve uygunsa sitede yayınlanacaktır.");
define("LAN_406", "Lütfen not edin");
define("LAN_407", "Yüklenen diğer tüm dosya türleri anında silinecek.");
define("LAN_408", "altı çizili");
define("LAN_409", "Dosyanın Adı");
define("LAN_410", "Versiyon");
define("LAN_411", "Dosya");
define("LAN_413", "Açıklama");
define("LAN_414", "Çalışan demo");
define("LAN_415", "Demonun görüleceği sitenin adresini girin");
define("LAN_418", "Maksimum dosya boyutu:");
define("LAN_419", "İzin verilen dosya tipi");
define("LAN_420", "Gerekli Alanlar");
define("LAN_UL_039", "Onayla ve Gönder");
define("LAN_UL_040", "Dosya Yükle");
