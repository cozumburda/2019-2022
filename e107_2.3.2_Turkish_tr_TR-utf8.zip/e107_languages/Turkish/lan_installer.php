<?php
/*
+---------------------------------------------------------------+
|        e107 website system Turkish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../e107_languages/Turkish/lan_installer.php $
|        $Revision: 1.0 $
|        $Date: 2007/01/13 16:12:56 $
|	$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+---------------------------------------------------------------+
*/
define("LANINS_001", "e107 Kurulumu");
define("LANINS_002", "Adım");
define("LANINS_003", "1-");
define("LANINS_004", "Dil Seçimi");
define("LANINS_005", "Lütfen kurulum işlemi boyunca kullanacağınız dili seçiniz");
define("LANINS_007", "4-");
define("LANINS_008", "PHP & MySQL Versiyon Kontrolü / Dosya İzinleri Kontrol Ediliyor");
define("LANINS_009", "Dosya İzinlerini Yeniden Test Edin");
define("LANINS_010", "Dosya yazılabilir değil:");
define("LANINS_010a", "Klasör yazılabilir değil:");
define("LANINS_012", "MySQL İşlevleri mevcut görünmüyor. Bu muhtemelen MySQL PHP Uzantısının kurulu olmadığı veya PHP kurulumunuzun MySQL desteği ile derlenmediği anlamına gelir.");
define("LANINS_013", "MySQL sürüm numaranız belirlenemedi. Bu ölümcül olmayan bir hatadır, bu nedenle lütfen yüklemeye devam edin, ancak e107'nin düzgün çalışması için MySQL >= 3.23 gerektirdiğini unutmayın.");
define("LANINS_014", "Dosya İzinleri");
define("LANINS_015", "PHP Versiyonu");
define("LANINS_017", "GEÇTİ");
define("LANINS_018", "Listede bulunan dosyaların sunucuda yazılabilir olduğundan emin olun. Bu normalde CHMOD ayarlarını 777 yaptığınız takdirde gerçekleşir, ama farklı durumlarda olabilir - her hangi bir problem olursa sunucu firmanızla irtibata geçin.");
define("LANINS_019", "Sunucunuzda kurulu PHP sürümü e107'yi çalıştıramaz. e107, sağlıklı çalışması için en az ".MIN_PHP_VERSION." PHP sürümünü gerektirir. Ya PHP sürümünüzü yükseltin ya da yükseltme için sunucu firmanız iletişime geçin.");
define("LANINS_021", "2-");
define("LANINS_022", "MySQL Sunucu Detayları");
define("LANINS_023", "Lütfen MySQL ayarlarınızı buraya girin. Kök izinleriniz varsa, bu kutuyu işaretleyerek yeni bir veritabanı oluşturabilirsiniz, yoksa bir veritabanı oluşturmanız veya önceden var olan bir veritabanını kullanmanız gerekir. Yalnızca bir veritabanınız varsa, diğer komut dosyalarının aynı veritabanını paylaşabilmesi için bir önek kullanın. MySQL ayrıntılarınızı bilmiyorsanız, web sağlayıcınız ile iletişime geçin.");
define("LANINS_024", "MySQL Sunucu:");
define("LANINS_025", "MySQL Kullanıcı Adı:");
define("LANINS_026", "MySQL Şifre:");
define("LANINS_027", "MySQL Veritabanı:");
define("LANINS_028", "Veritabanı Oluştur?");
define("LANINS_029", "Tablo Öneki:");
define("LANINS_030", "e107'nin kullanmasını istediğiniz MySQL sunucusu. Ayrıca bir bağlantı noktası numarası da içerebilir. Örneğin. 'hostname:port' veya yerel bir dizine giden yol, örn. Yerel ana bilgisayar için \":/path/to/socket\".");
define("LANINS_031", "Bu kullanıcı adı e107 MySQL sunucunuza bağlanmak için kullanır");
define("LANINS_032", "Az önce girdiğiniz kullanıcı için Şifre. Tek veya çift tırnak içermemelidir.");
define("LANINS_033", "e107'nin içinde bulunmasını istediğiniz MySQL veritabanı, bazen şema olarak anılır. Bir harfle başlamalıdır. Kullanıcının veritabanı oluşturma izinleri varsa veritabanını otomatik olarak oluşturmayı seçebilirsiniz. Veritabanı oluşturma izinleri yoksa varolan bir veritabanını kullanabilirsiniz.");
define("LANINS_034", "e107 tablolarını oluştururken e107'nin kullanmasını istediğiniz önek. Bir veritabanı şemasında birden fazla e107 kurulumu için kullanışlıdır.");
define("LANINS_036", "3-");
define("LANINS_037", "MySQL Bağlantı Doğrulaması");
define("LANINS_038", " ve Veritabanı Oluşturuluyor");
define("LANINS_039", "Lütfen tüm alanları, en önemlisi MySQL Sunucusu, MySQL Kullanıcı Adı ve MySQL Veritabanını doldurduğunuzdan emin olun (Bunlar her zaman MySQL Sunucusu tarafından gereklidir)");
define("LANINS_040", "Hatalar");
define("LANINS_041", "e107, girdiğiniz bilgileri kullanarak MySQL sunucusuyla bağlantı kuramadı. Lütfen son sayfaya geri dönün ve bilgilerin doğru olduğundan emin olun.");
define("LANINS_042", "MySQL sunucusuna bağlantı kuruldu ve doğrulandı.");
define("LANINS_043", "Veritabanı oluşturulamıyor, lütfen sunucunuzda veritabanı oluşturmak için doğru izinlere sahip olduğunuzdan emin olun.");
define("LANINS_044", "Veritabanı başarıyla oluşturuldu.");
define("LANINS_045", "Bir sonraki aşamaya geçmek için lütfen butona tıklayın.");
define("LANINS_046", "5-");
define("LANINS_047", "Yönetici Detayları");
define("LANINS_048", "EXIF uzantısı");
define("LANINS_049", "Girdiğiniz iki şifre aynı değil. Lütfen geri dönün ve tekrar deneyin.");
define("LANINS_050", "XML uzantısı");
define("LANINS_051", "Kurulu");
define("LANINS_052", "Kurulamadı");
define("LANINS_055", "Yükleme Onayı");
define("LANINS_056", "6-");
define("LANINS_057", "e107 artık kurulumu tamamlamak için ihtiyaç duyduğu tüm bilgilere sahiptir. Veritabanı tablolarını oluşturmak ve tüm ayarlarınızı kaydetmek için lütfen butona tıklayın.");
define("LANINS_058", "7-");
define("LANINS_060", "sql veri dosyası okunamıyor Lütfen [b]core_sql.php[/b] dosyasının [b]/e107_core/sql[/b] dizininde bulunduğundan emin olun.");
define("LANINS_061", "e107 gerekli veritabanı tablolarını oluşturamadı. Lütfen veritabanınızı temizleyin ve tekrar denemeden önce problemleri düzeltin.");
define("LANINS_069", "e107 başarıyla kuruldu! Güvenlik nedeniyle, şimdi [b]e107_config.php[/b] dosyasındaki dosya izinlerini tekrar 644'e ayarlamalısınız. Ayrıca lütfen aşağıdaki butona tıkladıktan sonra install.php'yi sunucunuzdan silin.");
define("LANINS_070", "e107, ana yapılandırma dosyasını sunucunuza kaydedemedi. Lütfen [b]e107_config.php[/b] dosyasının doğru izinlere sahip olduğundan emin olun");
define("LANINS_071", "Kurulum Tamamlandı");
define("LANINS_072", "Yönetici Kullanıcı Adı");
define("LANINS_073", "Bu, siteye giriş yapmak için kullanacağınız isimdir. Bunu görünen adınız olarak da kullanmak isterseniz");
define("LANINS_074", "Yönetici Görünen Adı");
define("LANINS_076", "Yönetici Şifresi");
define("LANINS_077", "Lütfen buraya kullanmak istediğiniz yönetici şifresini yazınız.");
define("LANINS_078", "Yönetici Parolası Onayı");
define("LANINS_079", "Lütfen onay için yönetici şifresini tekrar yazın");
define("LANINS_080", "Yönetici Eposta");
define("LANINS_081", "Eposta adresinizi girin");
define("LANINS_083", "MySQL Raporlanan Hata:");
define("LANINS_084", "Kurulum veritabanıyla bağlantı kuramadı");
define("LANINS_085", "Kurulum bu veritabanını seçemedi:");
define("LANINS_086", "Yönetici Kullanıcı Adı, Yönetici Şifresi ve Yönetici E-postası zorunlu alanlardır. Lütfen son sayfaya dönün ve bilgilerin doğru girildiğinden emin olun.");
define("LANINS_105", "Bazı rakamlarla başlayan ve ardından 'e' veya 'E' gelen bir veritabanı adı veya öneki kabul edilemez");
define("LANINS_106", "UYARI - e107, listelenen dizinlere ve/veya dosyalara yazamaz. Bu, e107'nin yüklenmesini durdurmasa da, belirli özelliklerin kullanılamadığı anlamına gelir. Bu özellikleri kullanmak için dosya izinlerini değiştirmeniz gerekir");
define("LANINS_107", "Web Site İsmi");
define("LANINS_108", "Web Sitem");
define("LANINS_109", "Web Site Teması");
define("LANINS_111", "İçeriği/Yapılandırmayı Dahil Et");
define("LANINS_112", "Tema önizlemesinin veya demosunun görünümünü hızla yeniden oluştur. (Mümkün ise)");
define("LANINS_113", "Bir Web Site adı girin");
define("LANINS_114", "Lütfen bir tema seçin");
define("LANINS_115", "Tema adı");
define("LANINS_116", "Tema türü");
define("LANINS_117", "Web Sitesi tercihleri");
define("LANINS_118", "Eklenti yükle");
define("LANINS_119", "Temanın gerektirebileceği tüm eklentileri yükleyin.");
define("LANINS_120", "8-");
define("LANINS_121", "e107_config.php boş dosya olamaz.");
define("LANINS_122", "Mevcut bir kurulumunuz olabilir");
define("LANINS_123", "İsteğe bağlı: Gerçek adınız veya takma adınız. Kullanıcı adını kullanmak için boş bırakın");
define("LANINS_124", "Lütfen en az 8 karakter olacak şekilde şifre oluşturunuz");
define("LANINS_125", "e107 başarıyla kuruldu!");
define("LANINS_126", "Güvenlik nedenleriyle şimdi e107_config.php dosya izinlerini 644 olarak ayarlamalısınız.");
define("LANINS_127", "[x] veritabanı zaten var. Üzerine yazılsın mı? (mevcut veriler kaybolacak)");
define("LANINS_128", "Üzerine yaz");
define("LANINS_129", "Veritabanı bulunamadı.");
define("LANINS_134", "Kurulum");
define("LANINS_135", "-den");
define("LANINS_136", "Mevcut veritabanı silindi");
define("LANINS_137", "Mevcut veritabanı bulundu");
define("LANINS_141", "Lütfen MySQL bilgilerinizle aşağıdaki formu doldurun. Bu bilgiyi bilmiyorsanız, lütfen sunucu firmanız ile iletişime geçin. Ek bilgi için her alanın üzerine gelebilirsiniz.");
define("LANINS_142", "Önemli: Lütfen e107.htaccess dosyasını .htaccess olarak yeniden adlandırın");
define("LANINS_144", "Önemli: Lütfen [b]e107.htaccess[/b] içeriğini  kopyalayıp [b] [/ b] .htaccess dosyanıza yapıştırınız. Lütfen içinde bulunan verileri tekrar üzerine yazmayın.");
define("LANINS_145", "e107 v2.x, PHP [x]'in yüklenmesini gerektirir. Devam etmeden önce lütfen sunucu firmanız ile iletişime geçin veya [y] adresindeki bilgileri okuyun.");
define("LANINS_146", "Yönetici-Alanı Görünüm");
define("LANINS_147", "Yönetim");
