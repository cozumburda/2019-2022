<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_login.php,v $
|     $Revision: 1.12 $
|     $Date: 2006/03/02 02:29:17 $
|     $Author: e107coders $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LAN_LOGIN_1", "Kullanıcı adı");
define("LAN_LOGIN_2", "kullanıcı şifresi");
define("LAN_LOGIN_3", "Korumalı sunucu");
define("LAN_LOGIN_4", "Lütfen giriş yapın.");
define("LAN_LOGIN_5", "Kaydolmak için buraya tıklayın");
define("LAN_LOGIN_6", "Şu anda yeni üye kabul edilmiyor");
define("LAN_LOGIN_7", "Görünen kodu girin");
define("LAN_LOGIN_8", "Beni Hatırla");
define("LAN_LOGIN_9", "Giriş yap");
define("LAN_LOGIN_10", "Giriş için buraya tıklayın");
define("LAN_LOGIN_11", "Yeni Kullanıcı Olarak Kaydolun");
define("LAN_LOGIN_12", "Şifremi unuttum");
define("LAN_LOGIN_13", "Lütfen Resimdeki kodu yazınız");
define("LAN_LOGIN_14", "Kullanıcı, tanınmayan kullanıcı adıyla oturum açmaya çalıştı");
define("LAN_LOGIN_15", "Kullanıcı yanlış şifre ile giriş yapmaya çalıştı");
define("LAN_LOGIN_16", "Kullanıcı, zaten kullanımda olan kullanıcı adı/şifre kombinasyonuyla oturum açmaya çalıştı");
define("LAN_LOGIN_17", "Kullanıcı şifresi (karma)");
define("LAN_LOGIN_18", "Otomatik yasaklama: [x] adetten fazla başarısız giriş denemesi");
define("LAN_LOGIN_19", "> 10 başarısız giriş denemesi");
define("LAN_LOGIN_20", "Gerekli alanları boş bıraktınız");
define("LAN_LOGIN_21", "Oturum açma bilgileriniz hiçbir kayıtlı kullanıcıyla eşleşmiyor. Bu sitedeki oturumlar büyük/küçük harfe duyarlı olduğundan, CAPS-LOCK düğmesinin açık olup olmadığını kontrol edin.");
define("LAN_LOGIN_22", "Hesabınızı etkinleştirmediniz. Bunun nasıl yapılacağına ilişkin talimatları içeren bir e-posta almış olmalısınız. E-posta almadıysanız lütfen [buraya] tıklayınız.");
define("LAN_LOGIN_23", "Yanlış kod girildi.");
define("LAN_LOGIN_24", "Bu kullanıcı zaten oturum açmış durumda ve başka bir oturum açamaz.");
define("LAN_LOGIN_25", "Engellenen kullanıcı oturum açmaya çalıştı");
define("LAN_LOGIN_26", "Giriş başarısız - nedeni bilinmiyor");
define("LAN_LOGIN_27", "Kullanıcı onay e-postasını yanıtlamadan oturum açmaya çalıştı");
define("LAN_LOGIN_28", "E-posta");
define("LAN_LOGIN_29", "Kullanıcı adı veya e-posta");
define("LAN_LOGIN_30", "DB'ye yeni alt_auth kullanıcısı eklenirken hata oluştu");
define("LAN_LOGIN_31", "Kimlik bilgileriniz sisteme eklenemedi");
define("LAN_LOGIN_32", "Şu anda Ana Yönetici olarak oturum açtığınız için bu mesajı görüyorsunuz.");
define("LAN_LOGIN_33", "[Ana sayfaya dön]");
define("LAN_LOGIN_34", "Kullanıcı kaydı ve/veya oturum açma şu anda devre dışı.");
define("LAN_LOGIN_35", "[Etkinleştir]");
define("LAN_LOGIN_36", "E-mailiniz [x] geçerli değil. Lütfen [Mail adresinizi doğru giriniz].");
define("LAN_LOGIN_37", "Hesabınız henüz site yöneticisi tarafından onaylanmadı.");
