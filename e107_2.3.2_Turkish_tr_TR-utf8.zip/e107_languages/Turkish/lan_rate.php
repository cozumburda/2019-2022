<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_rate.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/27 11:45:50 $
|     $Author: lisa_ $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("RATELAN_0", "Oy");
define("RATELAN_1", "Oylar");
define("RATELAN_2", "Bu öğeyi nasıl değerlendirirsiniz?");
define("RATELAN_3", "Oy verdiğiniz için teşekkürler!");
define("RATELAN_4", "Oylanmamış");
define("RATELAN_5", "Bunu oyla:");
define("RATELAN_6", "Bunu değerlendirmek için lütfen giriş yapın.");
define("RATELAN_7", "Beğen");
define("RATELAN_8", "Beğenme");
define("RATELAN_9", "Zaten Oyladınız");
define("RATELAN_10", "Değerlendirmenin öğe kimliği yok");
define("RATELAN_11", "Değerlendirme başarısız oldu");
define("RATELAN_POOR", "Zayıf");
define("RATELAN_FAIR", "Orta");
define("RATELAN_GOOD", "İyi");
define("RATELAN_VERYGOOD", "Çok iyi");
define("RATELAN_EXCELLENT", "Mükemmel");
