<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_mail_handler.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "e107 website sistemi tarafından üretilmiştir");
define("LANMAILH_2", "Bu, MIME formatında çok parçalı bir mesajdır.");
define("LANMAILH_3", "düzgün biçimlendirilmemiş");
define("LANMAILH_4", "Sunucu adresi geri çevirdi");
define("LANMAILH_5", "Sunucudan yanıt yok");
define("LANMAILH_6", "E-posta sunucusu bulunamadı.");
define("LANMAILH_7", " geçerli gözüküyor.");
