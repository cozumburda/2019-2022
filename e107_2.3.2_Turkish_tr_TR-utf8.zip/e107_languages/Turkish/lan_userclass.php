<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/05/13 01:03:35 $
|     $Author: mcfly_e107 $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Herkes (herkese açık)");
define("UC_LAN_1", "Misafirler");
define("UC_LAN_2", "Hiç Kimse (etkin değil)");
define("UC_LAN_3", "Üyeler");
define("UC_LAN_4", "Salt okunur");
define("UC_LAN_5", "Yönetici");
define("UC_LAN_6", "Ana Yönetici");
define("UC_LAN_7", "Forum Yöneticileri");
define("UC_LAN_8", "Yöneticiler ve Mods");
define("UC_LAN_9", "Yeni kullanıcılar");
define("UC_LAN_10", "Arama botları");
define("UC_LAN_INVERT", "-Not- [x]");
define("UC_LAN_INVERTLABEL", "Herkes ama...");
