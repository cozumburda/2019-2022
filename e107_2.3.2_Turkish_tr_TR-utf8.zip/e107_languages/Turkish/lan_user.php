<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_user.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/04/06 03:53:00 $
|     $Author: mcfly_e107 $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LAN_USER_01", "Görünen ad");
define("LAN_USER_02", "Oturum açma adı");
define("LAN_USER_03", "Gerçek adı");
define("LAN_USER_04", "Özel başlık");
define("LAN_USER_06", "Fotoğraf");
define("LAN_USER_07", "-Avatar-");
define("LAN_USER_09", "İmza");
define("LAN_USER_10", "E-posta gizle");
define("LAN_USER_12", "Kullanıcı sınıfı");
define("LAN_USER_13", "KİMLİĞİ");
define("LAN_USER_14", "Üye olma tarihi");
define("LAN_USER_15", "Son ziyaret");
define("LAN_USER_16", "Geçerli ziyaret");
define("LAN_USER_18", "IP adresi");
define("LAN_USER_19", "Yasak");
define("LAN_USER_20", "Tercihler");
define("LAN_USER_21", "Ziyaretler");
define("LAN_USER_22", "Yönetici");
define("LAN_USER_23", "İzinler");
define("LAN_USER_24", "Şifre Değiştir");
define("LAN_USER_31", "Ana site yöneticisi");
define("LAN_USER_32", "Site Yöneticisi");
define("LAN_USER_33", "bilgi yok");
define("LAN_USER_34", "önce");
define("LAN_USER_35", "[isteğiyle gizli]");
define("LAN_USER_36", "Kullanıcı Yorumlarını Görmek İçin Buraya Tıklayın");
define("LAN_USER_37", "Forum Gönderilerini Görüntülemek İçin Tıklayınız");
define("LAN_USER_38", "Bilgilerinizi güncellemek için buraya tıklayın");
define("LAN_USER_39", "Bu kullanıcının bilgilerini düzenlemek için burayı tıklatın");
define("LAN_USER_40", "önceki üye");
define("LAN_USER_41", "Sonraki üye");
define("LAN_USER_42", "fotoğraf yok");
define("LAN_USER_43", "fotoğraf sil");
define("LAN_USER_44", "Çeşitli");
define("LAN_USER_45", "Azalan");
define("LAN_USER_46", "Artan");
define("LAN_USER_49", "Kullanıcı ile ilgili bilgi yok, kayıtlı görünmüyor");
define("LAN_USER_50", "Üye profili");
define("LAN_USER_51", "Bu geçerli bir kullanıcı değil.");
define("LAN_USER_52", "Kayıtlı üyeler");
define("LAN_USER_53", "Henüz kayıtlı üye yok.");
define("LAN_USER_54", "Düzey");
define("LAN_USER_55", "Bu sayfayı görüntülemek için yetkiniz yok.");
define("LAN_USER_56", "Kayıtlı üyeler:");
define("LAN_USER_57", "İstek:");
define("LAN_USER_58", "Üye");
define("LAN_USER_59", "Katıldı");
define("LAN_USER_60", "E-posta adresi:");
define("LAN_USER_62", "Özel Mesaj Gönder");
define("LAN_USER_63", "Gerçek adı:");
define("LAN_USER_64", "Site istatistikleri");
define("LAN_USER_65", "Son ziyaret");
define("LAN_USER_66", "Kayıttan bu yana siteye yapılan ziyaretler");
define("LAN_USER_67", "Sohbet kutusu gönderileri");
define("LAN_USER_68", "Gönderilen Yorumlar");
define("LAN_USER_69", "Forum Gönderileri");
define("LAN_USER_71", "İmza:");
define("LAN_USER_72", "-Avatar-:");
define("LAN_USER_73", "İçerik/Posta listeleri seçimi");
define("LAN_USER_74", "Özel başlık");
define("LAN_USER_75", "[x]'iniz gerekli");
define("LAN_USER_76", "Abone olunan");
define("LAN_USER_77", "Parolanız en az [x] karakter uzunluğunda olmalıdır.");
define("LAN_USER_78", "Minimum");
define("LAN_USER_79", "Karakter");
define("LAN_USER_80", "sitede görüntülenen adı");
define("LAN_USER_81", "Kullanıcı adı:");
define("LAN_USER_82", "siteye giriş yapmak için kullandığınız isim");
define("LAN_USER_83", "E-posta adresini gizlemek ister misin?:");
define("LAN_USER_84", "Bu, e-posta adresinizin sitede görüntülenmesini engelleyecektir.");
define("LAN_USER_85", "Kullanıcı adınızı değiştirmek istiyorsanız, bir site yöneticisine sormalısınız.");
define("LAN_USER_86", "Maksimum avatar boyutu [x]- x [y] pikseldir");
define("LAN_USER_87", "Bu kullanıcıya oy vermek için giriş yapın!");
define("LAN_XUP_ERRM_01", "Kayıt başarısız oldu! Bu özellik devre dışı bırakıldı.");
define("LAN_XUP_ERRM_02", "Kayıt başarısız oldu! Yanlış sağlayıcı.");
define("LAN_XUP_ERRM_03", "Giriş başarısız oldu! Yanlış sağlayıcı.");
define("LAN_XUP_ERRM_04", "Kayıt başarısız oldu! Kullanıcı zaten oturum açmış.");
define("LAN_XUP_ERRM_05", "Kayıt başarısız oldu! Kullanıcı zaten var. Lütfen bunun yerine 'giriş' seçeneğini kullanın.");
define("LAN_XUP_ERRM_06", "Kayıt başarısız oldu! Kullanıcı e-postasına erişilemiyor - e-posta olmadan kayıt yapılamaz.");
define("LAN_XUP_ERRM_07", "Sosyal Giriş Testi");
define("LAN_XUP_ERRM_08", "Kullanıcı oturum açma/kayıt prosedürünü test etmeden önce lütfen e107'den çıkış yapın.");
define("LAN_XUP_ERRM_10", "[x] ile kaydolmayı/oturum açmayı test edin");
define("LAN_XUP_ERRM_11", "Giriş:");
define("LAN_XUP_ERRM_12", "Oturumu kapatma testi");
