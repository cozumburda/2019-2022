<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_banner.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: lisa_ $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Reklam");
define("BANNERLAN_16", "Kullanıcı Adı:");
define("BANNERLAN_17", "Parola :");
define("BANNERLAN_18", "Devam");
define("BANNERLAN_19", "Lütfen müşteri adınızı ve parolanızı girerek devam ediniz");
define("BANNERLAN_20", "Üzgünüm, bu bilgiler veritabanında yok. Lütfen ayrıntılı bilgi için site yöneticisiyle irtibat geçin.");
define("BANNERLAN_21", "Reklam İstatistikleri");
define("BANNERLAN_22", "Müşteri");
define("BANNERLAN_23", "Reklam ID");
define("BANNERLAN_24", "Tıklanma");
define("BANNERLAN_25", "Tıklanma Yüzdesi");
define("BANNERLAN_26", "Etkiler");
define("BANNERLAN_27", "Alınan Etki");
define("BANNERLAN_28", "Kalan Etki");
define("BANNERLAN_29", "Reklam yok");
define("BANNERLAN_30", "Sınırsız");
define("BANNERLAN_31", "Uygun değil");
define("BANNERLAN_32", "Evet");
define("BANNERLAN_33", "Hayır");
define("BANNERLAN_34", "Bitiş:");
define("BANNERLAN_35", "Tıklayan IP Adresleri");
define("BANNERLAN_36", "Aktif:");
define("BANNERLAN_37", "Başlangıç:");
define("BANNERLAN_38", "Hata");


?>