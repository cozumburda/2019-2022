<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_page.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/02/28 23:02:59 $
|     $Author: whoisrich $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LAN_PAGE_1", "Sayfa listelemesi kapalı");
define("LAN_PAGE_2", "Sayfa yok");
define("LAN_PAGE_3", "İstenilen sayfa mevcut değil");
define("LAN_PAGE_4", "Bu sayfayı oyla");
define("LAN_PAGE_5", "Sayfayı oyladığınız için teşekkür ederiz");
define("LAN_PAGE_6", "Bu sayfayı görmek için izniniz yok");
define("LAN_PAGE_8", "Parola Korumalı Sayfa");
define("LAN_PAGE_11", "Sayfa Listesi");
define("LAN_PAGE_12", "Geçersiz Sayfa");
define("LAN_PAGE_13", "Sayfa");
define("LAN_PAGE_14", "Diğer makaleler");
define("LAN_PAGE_15", "Makaleler");
define("LAN_PAGE_16", "Bu kitapta bölüm yok");
define("LAN_PAGE_17", "Bu sayfa yorumlara kapalı.");
