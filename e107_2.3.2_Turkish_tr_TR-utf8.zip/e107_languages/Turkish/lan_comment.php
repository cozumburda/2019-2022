<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Turkish/lan_comment.php,v $
|     $Revision: 1.12 $
|     $Date: 02-Oca-2008 04:47 PM $
|     $Author: mcfly_e107 $
|			$Türkçe Çeviri : shadowtr (www.e107turkiye.com) $
+----------------------------------------------------------------------------+
*/
define("COMLAN_0", "[yönetici tarafından engellendi]");
define("COMLAN_1", "Engeli kaldır");
define("COMLAN_2", "Engelle");
define("COMLAN_4", "Bilgi");
define("COMLAN_5", "Yorumlar ...");
define("COMLAN_6", "Bu sitede yorum yapmak için giriş yapmalısınız - lütfen giriş yapın veya kayıtlı değilseniz buraya tıklayın");
define("COMLAN_7", "Ana site yöneticisi");
define("COMLAN_8", "Yorum");
define("COMLAN_9", "Yorum gönder");
define("COMLAN_10", "Yönetici");
define("COMLAN_11", "Yorumunuz veri tabanına girilemedi - lütfen standart olmayan karakterleri kullanmadan yeniden yazın.");
define("COMLAN_12", "Kullanıcı");
define("COMLAN_16", "Kullanıcı adı:");
define("COMLAN_100", "Haberler");
define("COMLAN_101", "Anket");
define("COMLAN_102", "Yanıtla:");
define("COMLAN_103", "Makale");
define("COMLAN_104", "Gözden geçir");
define("COMLAN_105", "İçerik");
define("COMLAN_106", "İndirme");
define("COMLAN_145", "Kayıtlı:");
define("COMLAN_194", "Misafir");
define("COMLAN_195", "Kayıtlı üye");
define("COMLAN_310", "Bu kullanıcı adı kayıtlı olduğundan mesajınız kabul edilmedi - kullanıcı adı size aitse lütfen giriş yapın.");
define("COMLAN_312", "Yinelenen gönderi - kabul edilemiyor.");
define("COMLAN_313", "Konum");
define("COMLAN_314", "yorumları yönet");
define("COMLAN_318", "Yorumu düzenle");
define("COMLAN_319", "düzenlendi");
define("COMLAN_320", "Yorumu güncelle");
define("COMLAN_321", "buraya");
define("COMLAN_322", "kayıt için");
define("COMLAN_323", "Hata!");
define("COMLAN_324", "Konu");
define("COMLAN_325", "Cevap :");
define("COMLAN_326", "Cevapla");
define("COMLAN_328", "Yorumlar kilitli");
define("COMLAN_329", "Yetkisiz");
define("COMLAN_330", "IP :");
define("COMLAN_331", "Onay Bekleniyor");
define("COMLAN_332", "Yorum silinemedi");
define("COMLAN_333", "Yorum onaylandı");
define("COMLAN_334", "Yorum onaylanamadı");
define("COMLAN_335", "Onaylı");
define("COMLAN_336", "Lütfen önce bir şeyler yazın.");
define("COMLAN_337", "Başarıyla güncelleştirildi.");
define("COMLAN_400", "onaylandı");
define("COMLAN_401", "engellendi");
define("COMLAN_402", "Bekliyor");
define("COMLAN_403", "Bir Mesaj bırakın...");
define("COMLAN_404", "Onayla");
define("COMLAN_TYPE_1", "haberler");
define("COMLAN_TYPE_2", "indirme");
define("COMLAN_TYPE_3", "sss");
define("COMLAN_TYPE_4", "anket");
define("COMLAN_TYPE_5", "dökümanlar");
define("COMLAN_TYPE_6", "hata izleme");
define("COMLAN_TYPE_7", "düşünceler");
define("COMLAN_TYPE_8", "kullanıcı profili");
define("COMLAN_TYPE_PAGE", "İçerik");
define("COMLAN_500", "Yorum bırakmak için lütfen [giriş yapın].");
define("COMLAN_501", "Henüz kayıtlı değilseniz, [kayıt olmak için burayı tıklayın].");
