<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_ren_help.php,v $
|     $Revision: 1.8 $
|     $Date: 2006/04/13 23:43:16 $
|     $Author: sweetas $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LANHELP_1", "Siyah");
define("LANHELP_2", "Mavi");
define("LANHELP_3", "Kahverengi");
define("LANHELP_4", "Camgöbeği");
define("LANHELP_5", "Lacivert");
define("LANHELP_6", "Koyu Kırmızı");
define("LANHELP_7", "Yeşil");
define("LANHELP_8", "Çivit Mavi");
define("LANHELP_9", "Zeytin Yeşili");
define("LANHELP_10", "Turuncu");
define("LANHELP_11", "Kırmızı");
define("LANHELP_12", "Mor");
define("LANHELP_13", "Beyaz");
define("LANHELP_14", "Sarı");
define("LANHELP_15", "Çok Küçük");
define("LANHELP_16", "Küçük");
define("LANHELP_17", "Orta");
define("LANHELP_18", "Büyük");
define("LANHELP_19", "Daha büyük");
define("LANHELP_20", "Çok Büyük");
define("LANHELP_21", "Renk menüsü için tıkla ...");
define("LANHELP_22", "Boyut menüsü için tıkla ...");
define("LANHELP_23", "Bağlantı ekle: \n[link]http://mysite.com[/link] or [link=http://yoursite.com]Sitemi Ziyaret Edin[/link]");
define("LANHELP_24", "Kalın metin:\n[b]Bu metin kalın olacaktır[/b]");
define("LANHELP_25", "İtalik metin:\n[i]Bu metin italik olarak yazılacaktır[/i]");
define("LANHELP_26", "Altı çizili metin:\n[u]Bu metnin altı çizili olacak[/u]");
define("LANHELP_27", "Resim ekle:\n[img]resmim.jpg[/img]");
define("LANHELP_28", "Ortaya hizala:\n[center]Bu metin ortalanacak[/center]");
define("LANHELP_29", "Sola hizala:\n[left]Bu metin sola hizalanacak[/left]");
define("LANHELP_30", "Sağa hizala:\n[right]Bu metin sağa hizalanacak[/right]");
define("LANHELP_31", "Blok alıntı metni: [blockquote]Bu metin blok alıntı olacak (girintili)[/blockquote]");
define("LANHELP_32", "Kod - önceden biçimlendirilmiş metin: [code]\$foo = bah;[/code]");
define("LANHELP_33", "HTML - metindeki satır sonlarını kaldırır: [html]&lt;table&gt;&lt;tr&gt;&lt;td&gt; vb[/html]");
define("LANHELP_34", "[newpage] veya [newpage=title] Yeni sayfa etiketi ekle, makaleyi birden fazla sayfaya böler");
define("LANHELP_35", "köprü url'si");
define("LANHELP_36", "Sırasız: [list]satır1*satır2*satır3[/list] Sıralı: [list=type]satır1*satır2*satır3[/list]");
define("LANHELP_37", "e107_images/newspost_images/ dizininden resim ekleyin");
define("LANHELP_38", "Resmin orjinali için Link oluşturulacak");
define("LANHELP_39", "Mevcut indirmelerden indirme bağlantısı ekle");
define("LANHELP_40", "Şu anda mevcut indirme yok");
define("LANHELP_41", "Yazıtipi Boyutu ...");
define("LANHELP_42", "Resim Seç ...");
define("LANHELP_43", "Dosya Seç...");
define("LANHELP_44", "İfade iletişim kutusunu açmak/kapatmak için tıklayın...");
define("LANHELP_45", "Medya-Yöneticisinden resim ekle");
define("LANHELP_46", "* Şu konumda dosya bulunamadı:");
define("LANHELP_47", "Flash öğesi ekle: [flash=width,height]http://www.ornek.com/dosya.swf[/flash]");
define("LANHELP_48", "YouTube videosu: [youtube=tiny | small | medium | big | huge | width,height]6kYjxJmk0wc[/youtube]");
define("LANHELP_49", "Paragraf: [p=class name]Paragraf metni[/p]");
define("LANHELP_50", "Başlık: H2 için [h]Başlık metni[/h] veya [h=2]Başlık metni[/h]");
define("LANHELP_51", "Ekteki metin için HTML yeni satırlarını devre dışı bırakın: [nobr]metin[/nobr]");
define("LANHELP_52", "Yeni satır (HTML): [br]");
define("LANHELP_53", "İki Yana Yasla:\n[justify]Bu metin iki yana yaslanacak[/justify]");
define("LANHELP_54", "HTML bloğu (div etiketi): [blok]İçeriğiniz[/block]");
define("LANHELP_55", "Biçim");
define("LANHELP_56", "Tablo Ekle");
define("LANHELP_57", "Başlık");
define("LANHELP_58", "Blok");
define("LANHELP_59", "Alıntı");
define("LANHELP_60", "Kod Bloğu");
define("LANHELP_61", "Kode Satırı");
define("LANHELP_62", "Paragraf");
define("LANHELP_63", "Medya Yöneticisinden Resim Ekle");
define("LANHELP_64", "Medya Yöneticisinden Dosya Ekle");
define("LANHELP_65", "Boyut");
