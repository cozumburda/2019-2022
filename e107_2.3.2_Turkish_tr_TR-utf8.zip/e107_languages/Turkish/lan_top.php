<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_top.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("TOP_LAN_0", "En çok mesaj gönderen");
define("TOP_LAN_1", "Kullanıcı adı");
define("TOP_LAN_2", "Mesajları");
define("TOP_LAN_3", "En çok yorum yapan");
define("TOP_LAN_5", "En çok sohbet eden");
define("TOP_LAN_6", "Site Değerlendirmesi");
define("LAN_1", "Konu");
define("LAN_2", "Yollayan");
define("LAN_3", "Görüntülemeler");
define("LAN_4", "Cevaplar");
define("LAN_5", "Son Mesaj");
define("LAN_6", "Konular");
define("LAN_7", "En Aktif Konular");
define("LAN_8", "En çok mesaj gönderen");
