<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_news.php,v $
|     $Revision: 1.9 $
|     $Date: 2006/04/18 01:33:36 $
|     $Author: sweetas $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LAN_NEWS_1", "Sadece belirli üyeler için haberler");
define("LAN_NEWS_2", "Bu haberi görmenize izin verilmiyor");
define("LAN_NEWS_9", "Başlığı sadece - <b>sadece haber başlığı gözükecek</b><br />şekilde ayarla");
define("LAN_NEWS_10", "Bu haber gönderisi <b>etkin değil</b> (Ana sayfada gösterilmeyecek).");
define("LAN_NEWS_11", "Bu haber gönderisi <b>etkin</b> (Ana sayfada gösterilecek).");
define("LAN_NEWS_12", "Yorumlar <b>açık</b>.");
define("LAN_NEWS_13", "Yorumlar <b>kapalı</b>.");
define("LAN_NEWS_14", "<br/>Aktivasyon periyodu:");
define("LAN_NEWS_15", "Gövde  Metni Uzunluğu:");
define("LAN_NEWS_16", "b. Genişletilmiş Metin Uzunluğu:");
define("LAN_NEWS_17", "b-");
define("LAN_NEWS_18", "Bilgi:");
define("LAN_NEWS_19", "Şimdi");
define("LAN_NEWS_23", "Haber Kategorileri");
define("LAN_NEWS_24", "bu haberin pdf'sini oluştur");
define("LAN_NEWS_31", "Yapışkan haber öğesi");
define("LAN_NEWS_82", "Haberler - Kategori");
define("LAN_NEWS_83", "Şu anda haber yok - lütfen daha sonra tekrar kontrol edin.");
define("LAN_NEWS_84", "Haber özetlerine geri dön");
define("LAN_NEWS_85", "Kategori özetlerine geri dön");
define("LAN_NEWS_86", "Eski haberler");
define("LAN_NEWS_87", "Yeni haberler");
define("LAN_NEWS_462", "Belirtilen ay için haber yok");
define("LAN_NEWS_463", "Belirtilen kategori için haber yok - lütfen daha sonra tekrar kontrol edin.");
define("LAN_NEWS_464", "Belirtilen gün için haber yok");
define("LAN_NEWS_300", "Açık");
define("LAN_NEWS_307", "Bu kategorideki tüm gönderiler:");
define("LAN_NEWS_308", "Belki de aşağıdaki haberlerden birini arıyorsunuz?");
define("LAN_NEWS_309", "Etiket");
