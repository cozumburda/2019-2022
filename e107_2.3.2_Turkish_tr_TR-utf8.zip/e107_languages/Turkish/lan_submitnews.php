<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_submitnews.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Haber Gönder");
define("LAN_134", "Öğeniz site yöneticilerine incelenmek üzere gönderildi.");
define("LAN_135", "Haber Öğesi:");
define("LAN_136", "Haber Öğesi Gönder");
define("NWSLAN_10", "Haber kategorisi yok");
define("NWSLAN_11", "Bu alana erişiminiz yok veya şu anda oturum açmamışsınız.");
define("NWSLAN_12", "Erişim Engellendi.");
define("SUBNEWSLAN_1", "Başlık içermeli.\\n");
define("SUBNEWSLAN_2", "Haber öğesi bir takım yazılar içermeli.\\n");
define("SUBNEWSLAN_3", "Eklenti jpg, gif veya png dosyası olmalı");
define("SUBNEWSLAN_4", "Dosya boyutu çok büyük");
define("SUBNEWSLAN_5", "Resim Dosyası");
define("SUBNEWSLAN_6", "(jpg, gif veya png)");
define("SUBNEWSLAN_7", "İsminiz ve email adresinizi girmelisiniz");
define("SUBNEWSLAN_8", "Resim yüklenirken hata oluştu");
define("SUBNEWSLAN_9", "Anahtar kelimeler");
define("SUBNEWSLAN_11", "Meta açıklaması");
define("SUBNEWSLAN_12", "Facebook vb tarafından kullanılan.");
define("SUBNEWSLAN_13", "Medya URL'leri");
