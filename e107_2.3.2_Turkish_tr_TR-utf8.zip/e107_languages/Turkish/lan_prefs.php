<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_prefs.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/04 23:13:42 $
|     $Author: mcfly_e107 $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("LAN_PREF_1", "e107 Tabanlı Website");
define("LAN_PREF_2", "e107 Website Sistemi");
define("LAN_PREF_3", "Bu site <a href="http://e107.org/" rel="external">e107</a> cms kullanarak yapılmıştır, ve <a href="http://www.gnu.org/" rel="external">GNU</a> Genel Kamu Lisansı ile korunmaktadır.");
define("LAN_PREF_4", "sansür");
define("LAN_PREF_5", "Forumlar");


?>