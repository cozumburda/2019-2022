﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_subcontent.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/09 03:32:07 $
|     $Author: chavo $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("ARLAN_0", "Teşekkürler, makaleniz site yöneticileri tarafından incelenmek üzere gönderildi.");
define("ARLAN_1", "Alanları boş bırakmayın.");
define("ARLAN_2", "Teşekkürler, araştırmanız site yöneticileri tarafından incelenmek üzere gönderildi.");
define("ARLAN_15", "Makale Yolla");
define("ARLAN_17", "Başlık");
define("ARLAN_18", "Alt Başlık");
define("ARLAN_19", "Özet");
define("ARLAN_20", "Makale");
define("ARLAN_21", "Yorum yazılsın mı?");
define("ARLAN_22", "Evet");
define("ARLAN_23", "Hayır");
define("ARLAN_24", "Email/yazıcı ikonu eklensin mi?");
define("ARLAN_25", "Evet");
define("ARLAN_26", "Hayır");
define("ARLAN_27", "Makale Yolla");
define("ARLAN_28", "Önizleme");
define("ARLAN_55", "Görünürlük");
define("ARLAN_73", "HTML Düzenleyiciyi Aç");
define("ARLAN_74", "Kategori");
define("ARLAN_75", "Yok");
define("ARLAN_82", "Yazar Detayları");
define("ARLAN_84", "yazarın adı");
define("ARLAN_85", "yazarın email adresi");
define("ARLAN_86", "Araştırma");
define("ARLAN_87", "Değer");
define("ARLAN_88", "Lütfen değer seçiniz");
define("ARLAN_89", "Araştırma Gönder");

define("ARLAN_90", "Boş alanlar var, lütfen tarayıcınızın geri butonuna basarak tüm alanları doldurun.");
define("ARLAN_91", "Tekrar Önizle");
define("ARLAN_92", "Lütfen ad/eposta adresi girin");


define("ARLAN_93", "makale");
define("ARLAN_94", "gözden geçir");
define("ARLAN_95", "Kullanıcılar için makale gönderimi kapalı");
define("ARLAN_96", "Kullanıcılar için araştırma gönderimi kapalı");
define("ARLAN_97", "Makale gönderebilme yetkisine sahip değilsiniz");
define("ARLAN_98", "Araştırma gönderebilme yetkisine sahip değilsiniz");


define("ARLAN_99", "Ne yollayabilirim?");
define("ARLAN_100", "Haber");
define("ARLAN_101", "Olay");
define("ARLAN_102", "Makale");
define("ARLAN_103", "Araştırma");
define("ARLAN_104", "Bağlantı");
define("ARLAN_105", "Dosya");
define("ARLAN_106", "Gönder");

?>
