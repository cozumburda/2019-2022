<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_user_select.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/09 20:59:02 $
|     $Author: mcfly_e107 $
|			$Türkçe Çeviri: shadowtr (http://e107turkiye.com)
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Kullanıcı seç");
define("US_LAN_2", "Kullanıcı sınıfı seç");
define("US_LAN_3", "Tüm Kullanıcılar");
define("US_LAN_4", "Kullanıcı adı ara");
define("US_LAN_5", "Kullanıcı(lar) bulundu");
define("US_LAN_6", "Ara");
