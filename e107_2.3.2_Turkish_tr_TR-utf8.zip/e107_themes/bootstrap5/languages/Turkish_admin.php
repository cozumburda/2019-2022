<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - 
|
+----------------------------------------------------------------------------+
*/

define("LAN_THEMEPREF_01", "Bootswatch Stilleri:");
define("LAN_THEMEPREF_02", "Kart görünümlü standart menüyü görüntüleyin");
define("LAN_THEMEPREF_03", "Oturum Açma Sayfasını standart sayfa olarak görüntüle");