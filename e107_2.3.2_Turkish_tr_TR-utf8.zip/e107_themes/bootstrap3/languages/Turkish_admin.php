<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - 
|

+----------------------------------------------------------------------------+
*/
define("LAN_THEMEPREF_00", "Markalama:");
define("LAN_THEMEPREF_01", "Gezinme Çubuğu Hizalaması:");
define("LAN_THEMEPREF_02", "Kayıt/Giriş Yerleşimi:");
define("LAN_THEMEPREF_03", "Bootswatch Stilleri:");
define("LAN_THEMEPREF_04", "Site Adı");
define("LAN_THEMEPREF_05", "-Logo-");
define("LAN_THEMEPREF_06", "Logo &amp; Site Adı");
define("LAN_THEMEPREF_07", "sol");
define("LAN_THEMEPREF_08", "sağ");
define("LAN_THEMEPREF_09", "üst");
define("LAN_THEMEPREF_10", "alt");
